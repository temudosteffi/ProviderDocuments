# Target State — [MODULE NAME] ([MODULE CODE])

**Program:** Provider Plus Modernization
**Template version:** 2.1 (2026-11-01). Review with `target-state-review-checklist-v2.md` (v2.1). Change from 2.0: a fifth section status, **Not started**, and rules for using each status (authoring rule 1).

> **Purpose of this template.** A target state document defines what a Provider Plus module must do and how it is built. It is the main input to spec-driven development (SDD): an agent combines it with the legacy knowledge graph (KG), the ARB and the ADRs to generate specifications, and from those, code. Anything this document leaves vague, the agent will guess. Replace every bracketed prompt. Delete the guidance text (in *italics* and `>` quotes) once a section is written.

---

## Read First: Authoring Rules

1. **Keep this numbering and every heading.** Never delete a section silently. Give each section a status line (see 0.7) with one of five statuses:

   | Status | Use when | Write |
   |---|---|---|
   | **Complete** | The section meets its items in the review checklist | `Status: Complete` |
   | **Partial** | Content is present but incomplete | `Status: Partial — <what is missing>`. Name the gap, not where the content came from ("migrated from v4" is not a reason) |
   | **Not started** | The heading is kept but there is no content yet. A section holding only "TBD", or only a pointer to an empty appendix, is Not started | `Status: Not started — <owner or Q-xx>` |
   | **N/A** | The section does not apply to this module | `Status: N/A — <why it does not apply>`. Never use N/A for "not written yet" |
   | **Inherited** | A sub-module's parent already covers it (rule 2) | `Status: Inherited — <parent document> §<n>` |

   Mark a section Complete only when it passes its checklist items. The section status index (0.7) repeats every status line.
2. **Sub-modules may inherit.** A sub-module can write `Status: Inherited — <parent document> §<n>` for a section the parent already covers. Only inherit what really is identical; state any local difference.
3. **State which source wins.** Fill in the source precedence table in 0.4 before writing anything else.
4. **Label what is not fact.** Use these inline labels and give each an ID that appears in §16 or §18:
   - `**Decision (ADR-xxx / DD-xx):**` a ratified enterprise ADR or a domain decision
   - `**Assumption (AS-xx):**` believed true, not confirmed
   - `**Proposal (PR-xx):**` recommended, awaiting approval
   - `**Open (Q-xx):**` an unresolved question
   - Plain text is fact, and should cite its source (legacy file, ARB section, ADR, stakeholder decision).
5. **Never invent enterprise standards.** Cite the ADR or ARB section. If the module deviates, record it in §16.3 with an owner and approval path. The current platform baseline is in Appendix P of the review checklist.
6. **Say what is preserved, changed, retired or new.** Use these four words consistently (the "disposition") for capabilities, rules, screens, interfaces and data.
7. **Trace everything.** Legacy source → requirement or rule ID → target component → API, event or table → test.
8. **Draw, don't just describe.** Each "Required diagram" must be present, in Mermaid (or another text format an agent can read). Diagram labels must match the names used in contracts and tables.
9. **Be implementable.** No "secure", "scalable" or "appropriate" without the mechanism and a measurable criterion.
10. **Make every requirement testable.** NFRs need a metric, target, scope and measurement method. Rules need acceptance criteria.
11. **Make every integration explicit.** Producer, consumer, mechanism, contract, authentication, timeout, retry, idempotency, failure behaviour, owner.
12. **Make data ownership explicit.** System of record, owning service, schema, migration, retention, access boundary, classification.
13. **Use synthetic data only.** No production PII, credentials, tokens or secrets, including in examples copied from legacy tests.
14. **Link, don't copy.** Contracts, schemas and inventories live as version-controlled files beside this document. Link to the authoritative file; don't paste stale copies of enterprise ADRs or other modules' contracts.
15. **Don't claim "complete", "final" or "ARB ready" without evidence.** §20 must show the evidence, and §18 must show no open Blockers.
16. **One file, one source.** Retire or mark superseded any other copy of this document.

---

# 0. Document Control

## 0.1 Document Information

| Field | Value |
|---|---|
| Module name and code | [e.g. Module name (CM-XX)] |
| Module type | [Main / Supporting / Sub-module of <parent>] |
| Parent document | [Parent target state and version, or N/A] |
| Version | [0.1] |
| Status | [Draft / In Review / SA Approved / ARB Candidate / Approved] |
| Date | [YYYY-MM-DD] |
| Owner | [Name, role] |
| Reviewers and approvers | [Solution Architect; business lead; QA lead; security; data; operations] |
| Classification | [Confidential / Internal] |
| Supersedes | [Prior document and version, or N/A] |
| Contract and schema files | [Repository path to `api-specification/`, AsyncAPI, DDL or migrations] |

## 0.2 Revision History

| Version | Date | Author | Change summary | Sections | Approver |
|---|---|---|---|---|---|
| 0.1 | [Date] | [Name] | Initial draft | All | [Pending] |

## 0.3 Governing Inputs

*Record the exact versions this document was written against. When any of them change, review this document.*

| Input | Version / date / commit | Location | Used for |
|---|---|---|---|
| ARB Provider Plus Modernization | [v2.x] | [Link] | Platform architecture |
| ADR Live Document | [As of date] | [Link] | Ratified decisions |
| Legacy repositories | [Repo names and commit or tag] | [Link] | Business behaviour |
| Legacy knowledge graph | [Build date] | [Link] | Legacy structure and inventories |
| KT session outputs (ADR-033) | [Session, date, approval] | [Link] | Approved legacy understanding |
| Parent target state (sub-modules) | [Version] | [Link] | Inherited sections |
| Neighbouring module target states | [Module and version] | [Link] | Event and ownership agreements |
| Reference screens / UX designs | [Version] | [Link] | Screen specs |

## 0.4 How to Use This Document

**Role of this document:** [Input to specification generation, solution design, code generation and testing for <module>.]

**Source precedence.** When sources disagree, the higher row wins for that concern:

| Concern | Authoritative source | Notes |
|---|---|---|
| Business behaviour (rules, calculations, validations, data kept) | [e.g. Legacy code, except where §2 states a rule] | [Where this document is silent, legacy behaviour applies unchanged] |
| Interfaces and technology | [This document] | [Legacy interfaces are not reproduced] |
| API request and response shapes | [Appendix B and C contract files] | |
| Event shapes | [Appendix E] | |
| Tables and columns | [Appendix D] | |
| Platform standards | [ADRs and ARB, except approved exceptions in §16.3] | |

**Disposition terms:** Preserve (same behaviour), Change (intentional difference, listed in Appendix M), Retire (removed), New (no legacy equivalent).

**Change management:** [How changes are proposed and approved; how legacy changes from the Current State Delta Log (ADR-034) are assessed against this document.]

## 0.5 Decision Status

| Category | Open / Partial / Closed | Decision and question IDs | Applied in sections |
|---|---|---|---|
| Business | | | |
| Workflow | | | |
| Integration and eventing | | | |
| Architecture | | | |
| Security and authorization | | | |
| Data | | | |
| Platform and infrastructure | | | |
| Legacy transition | | | |
| Governance | | | |

## 0.6 Target-State Summary

| Dimension | Target position |
|---|---|
| Business capability and scope | [One or two lines] |
| Modernization strategy | [Preserve / change / retire / new, in summary] |
| Architecture classification | [e.g. CRUD or CQRS (cite ADR), outbox, workflow] |
| Frontend | [Target] |
| BFF and API entry | [Target] |
| Domain services | [Target] |
| Data and persistence | [Target] |
| Eventing and integration | [Target] |
| Runtime and hosting | [Target] |
| Security and identity | [Target] |
| Observability | [Target] |
| Legacy transition | [e.g. Strangler fig by tenant] |
| Open business decisions | [Count and IDs] |
| Open architecture decisions | [Count and IDs] |
| Approved exceptions to platform standards | [Count and IDs] |
| Known functional gaps | [Count and IDs] |
| SDD readiness | [Ready / Ready with conditions / Not ready, with the review report reference] |
| ARB / stakeholder sign-off | [Status] |

## 0.7 Section Status Index

| Section | Status (Complete / Partial / Not started / N/A / Inherited) | Gap, reason or reference | Section owner |
|---|---|---|---|
| 1 Business Scope | | | |
| 2 Business Logic | | | |
| ... | | | |
| Appendix N | | | |

---

# PART I — BUSINESS

# 1. Business Scope and Capabilities

## 1.1 Purpose

[What the module is for, in business terms, in a short paragraph.]

## 1.2 Capabilities

| ID | Capability | Description | Disposition | Phase |
|---|---|---|---|---|
| CAP-01 | [Capability] | [Description] | [Preserve / Change / New / Retire] | [Phase] |

## 1.3 Ownership Boundary

*Who writes which data. This is the most common source of cross-module drift.*

| This module owns (writes) | Neighbouring module owns (this module only reads or receives events) | Owner |
|---|---|---|
| [Data or capability] | [Data or capability] | [Module] |

**Required diagram:** domain boundary or context map with neighbouring modules.

## 1.4 Out of Scope

- [Item, and where it is handled instead]

## 1.5 Actors and Roles

| Actor | Type (internal user / public or anonymous / external user / machine caller) | What they do | Role(s) |
|---|---|---|---|
| [Actor] | [Type] | [Actions] | [Role names, defined in Appendix G] |

## 1.6 Business Objects

| Object | System of record | Purpose | Key identifiers |
|---|---|---|---|
| [Object] | [This module / other module / external system] | [Purpose] | [IDs] |

**Required diagram:** business object relationship diagram.

# 2. Business Logic

## 2.1 Business Rules Catalogue

*One row per rule. Every rule has exactly one owning component, and its ID appears in code comments and test names.*

| Rule ID | Rule (plain language) | Source / evidence | Disposition | Enforced in | Outcome when violated (status, error type, field) | Acceptance ref |
|---|---|---|---|---|---|---|
| BR-001 | [Rule] | [Legacy file / requirement / decision] | [Preserve / Change / New] | [Service / component] | [e.g. 400, field `x`] | [AC-xx] |

Flag conflicts between legacy code, business documents and stakeholder decisions as `Open (Q-xx)`.

## 2.2 Calculations and Decision Logic

*For each calculation, precedence, eligibility or matching algorithm: inputs, every branch or level, tie-breaks, data source for every level, and worked examples including boundary cases.*

| Logic ID | Name | Inputs | Algorithm / steps | Data source per step | Worked examples |
|---|---|---|---|---|---|

## 2.3 Workflow and Lifecycle

*Status: N/A if the module has no workflow-governed records.*

**Records governed by the workflow:** [List. Name any record types explicitly not governed.]

| Status | Actor | Allowed actions | Meaning |
|---|---|---|---|

| From status | Action / event | Trigger (user / event / time) | Actor and policy | Guard / validation | To status | Side effects (history, events, notifications) |
|---|---|---|---|---|---|---|

- Segregation of duties: [e.g. approver is not the creator]
- Mandatory comments or justifications: [Actions]
- Versioning on change: [Rule]
- Bulk actions: [How many records created by imports go through the workflow]

**Required diagram:** state machine.

## 2.4 Time-Based Behaviour

*Anything that happens because a date or time passes, not because a user or event acts.*

| Behaviour | Owning component | Schedule | Time zone source | Catch-up after missed runs | Events published | Monitoring |
|---|---|---|---|---|---|---|

## 2.5 Rules Engine Integration

*If the module does not use the rules engine (InRule, ADR-018), say so and why.*

| Rule set | Invoked at | Input facts (fields, types) | Outputs (messages, computed values) | Timeout and retry | Fail open / fail closed | Cache and invalidation |
|---|---|---|---|---|---|---|

Mapping of rule outputs to API errors: [e.g. Error severity → 400 field error; unavailable → 503 fail closed].

## 2.6 Validation and Error Handling

| Validation ID | Trigger | Condition | Outcome / error | Enforcement layer (UI / BFF / service / database) | Source |
|---|---|---|---|---|---|

## 2.7 Audit, History and Versioning

[What is recorded for every change (who, what, when, before and after, comment); effective dating; version history; correction and rollback; how history is retrieved; retention (link §9.7).]

## 2.8 Tenant-Variable Behaviour

*Everything that differs between states. Behaviour varies by configuration only, never by tenant-specific code (ADR-018).*

| Behaviour | Varies how | Configuration key (Appendix J) | Default |
|---|---|---|---|

## 2.9 Notifications

| Trigger | Recipient | Channel (in-app queue / email / letter) | Mechanism (e.g. Correspondence Service, ADR-039) | Template |
|---|---|---|---|---|

## 2.10 Acceptance Criteria

*Given/When/Then for every workflow and for each rule's edge cases. Use synthetic values.*

```gherkin
# AC-01 (BR-xxx)
Given [state]
When [action]
Then [outcome]
```

## 2.11 Business Behaviour Parity

[How preserved behaviour is shown to match legacy; which behaviour is intentionally changed (every Change and New item goes in Appendix M, the known-difference register); who signs off. Thresholds per ADR-029.]

---

# PART II — TECHNICAL

# 3. Architecture Overview

## 3.1 Architecture Classification and Patterns

[Pattern(s) used, each with its ADR, e.g. persistence pattern, transactional outbox, workflow, effective dating. Any deviation from the platform goes in §16.3.]

## 3.2 System Context (C1)

**Required diagram:** the module, every actor and role, every external system, every shared platform service, every other Provider Plus module it exchanges data with. Label each edge with what flows and whether it is sync or async.

| Actor / system | Direction | Interaction | Sync / async | Detail in |
|---|---|---|---|---|

## 3.3 Containers and Components (C2)

**Required diagram:** every deployable and store: frontend, API Gateway, BFF, each service, consumers, outbox relay, scheduled jobs, batch jobs, databases and schemas, caches, object storage, Event Backbone. Label edges with the protocol.

| Container / component | Technology | Responsibility | Runtime | Owner |
|---|---|---|---|---|

## 3.4 Technology Stack

| Layer | Technology and version | Hosting | Decision reference (ADR / DD / exception) |
|---|---|---|---|
| Frontend | | | |
| API entry | | | |
| BFF | | | |
| Domain services | | | |
| Data access | | | |
| Schema migrations | | | |
| Database | | | |
| Cache | | | |
| Messaging / events | | | |
| Batch | | | |
| Runtime / orchestration | | | |
| Identity | | | |
| Observability | | | |
| CI/CD and IaC | | | |

## 3.5 End-to-End Request Flow

**Required diagram:** browser → CDN → API Gateway → BFF → domain service → database and outbox → Event Backbone. Show where authentication, tenant resolution and authorization happen at each hop.

## 3.6 Component Interaction Matrix

| From | To | Mechanism (REST / SigV4 REST / event / SQL / S3 / SDK) | Sync / async | Authentication | Purpose |
|---|---|---|---|---|---|

## 3.7 Deployment and Runtime View

**Required diagram:** accounts, clusters or namespaces, Lambda, Glue and MWAA, network zones, ingress, regions and DR.

## 3.8 Key Sequence Diagrams

*Required at minimum, where they apply. Use the same endpoint, event and table names as the contracts.*

| Flow | Diagram reference |
|---|---|
| Main create or update flow | |
| Main workflow flow (submit, approve, activate) | |
| Each consumed-event handler | |
| Import / batch flow | |
| Outbox publication | |
| Each time-based job | |
| Each external system call | |

# 4. Frontend

## 4.1 Architecture Overview

[Relationship to the shell, micro frontend composition, entry points, deployment model, per-tenant versioning (ADR-011).]

**Required diagram:** browser, shell, this module's micro frontend, BFF.

## 4.2 Technology Stack

| Concern | Technology / version | Standard / rationale |
|---|---|---|
| Framework and language | | |
| Component library | | |
| Server state | | |
| Forms and validation | | |
| Routing / module federation | | |
| Testing | | |
| Build | | |
| Telemetry | | |

## 4.3 Screen Inventory

| Screen ID | Screen | Legacy source | Route | Disposition | Roles | Backing BFF endpoint(s) | Spec (Appendix H) |
|---|---|---|---|---|---|---|---|

## 4.4 Navigation and Shell Integration

[Route map inside the module; menu entries; shell events sent and received; deep links.]

## 4.5 Tenant Customization

[What is configurable at runtime (feature flags, fields, labels, DataLists) and what must never be forked per tenant.]

## 4.6 API Communication

[Entry point (API Gateway path), headers, token or session handling, CSRF if used, correlation ID, error handling (400 / 403 / 409 / 5xx), retries, client caching.]

## 4.7 Hosting, Security, Observability and Accessibility

[Static hosting and CDN; remote versioning; security headers (CSP, HSTS, X-Frame-Options, Referrer-Policy, SRI; ADR-031); telemetry; error boundaries; PII handling in the browser; WCAG 2.2 AA and Section 508 with CI gates (ADR-032).]

## 4.8 Public or Anonymous Flows

*N/A if all users are authenticated.* [Token type, allowed operations, save-and-resume, abuse protection.]

# 5. BFF (Backend for Frontend)

## 5.1 Purpose and Responsibilities

| Responsibility | Target behaviour | Component |
|---|---|---|
| Authentication / session | | |
| Authorization enforcement | | |
| Tenant context | | |
| Aggregation | | |
| View-model shaping | | |
| Orchestration | | |
| File / import initiation | | |
| Errors and correlation | | |

**The BFF must not own:** [e.g. business rules, direct database access].

## 5.2 Routes

| BFF route | Methods | Type (pass-through / composed) | Downstream operation(s) | Scope | Contract (Appendix C) |
|---|---|---|---|---|---|

## 5.3 Composed Endpoints

| Endpoint | Downstream calls in order | Partial-failure handling | Cache (key, TTL) | Response view model |
|---|---|---|---|---|

## 5.4 Session and Token Model

[Where tokens are held, refresh, logout, CSRF, and how this fits API Gateway JWT validation (ADR-008).]

## 5.5 Contract Governance

[Contract-first; generated clients; breaking-change checks; consumer-driven contract tests.]

## 5.6 Technology and Resilience

[Framework and version (cite decision); timeouts; retries; circuit breakers; rate limits; telemetry.]

# 6. Domain Services

## 6.1 Service Pattern and Boundaries

[Architectural style (cite ADR); service boundaries; data ownership; deployment independence.]

## 6.2 Service Catalog

*One card per service.*

| Attribute | Value |
|---|---|
| Service | [Name] |
| Business responsibility | [What it owns] |
| Runtime / compute | [Technology, hosting] |
| API base path(s) | [Paths] |
| Data owned | [Schemas, tables] |
| Events published | [Names] |
| Events consumed | [Names] |
| Key writes | [Operations] |
| Key reads | [Operations] |
| Rules owned | [BR IDs] |
| Legacy source | [Projects, services] |
| Owning team | [Team] |

## 6.3 Legacy API Surface Mapping

| Legacy surface (WCF / SOAP / Web API / OData / internal) | Legacy location | Target API, event or job | Target route / operationId | Disposition | Legacy consumers | Rationale |
|---|---|---|---|---|---|---|

## 6.4 API Design Standards

[Summary; detail in Appendix A.]

## 6.5 Synchronous Communication

| Caller | Callee | Protocol and auth | Purpose | Timeout / retry / circuit breaker | Constraints |
|---|---|---|---|---|---|

*No synchronous calls to another domain's services (ADR-002) unless an approved exception exists.*

## 6.6 Persistence Pattern and Transactions

[Repository or ORM approach; unit of work; transaction boundaries; outbox; concurrency control; tenant routing.]

## 6.7 Resiliency

| Pattern | Implementation |
|---|---|
| Idempotency | |
| Optimistic concurrency | |
| Retry and circuit breaker | |
| Fail closed | |
| Dead-letter | |
| Health checks | |

# 7. Eventing

## 7.1 Event Backbone Strategy

[Event Adapter, transport configuration, envelope, schema registry, topic naming; cite ADR-002, ADR-002a, ADR-037.]

**Required diagram:** producers → outbox relay → Event Adapter → topics → consumers (including other modules, the integration adapter, correspondence) and DLQs.

## 7.2 Event Types

*Classify every event.*

| Type | Meaning |
|---|---|
| Domain event | A state change of this module's own data |
| Outbound integration event | Published for other modules or external systems |
| Inbound integration event | Received from another module or from an external system via the integration adapter |
| Platform / technical event | e.g. import completed, rule set deployed, cache invalidation |
| Failure event / DLQ | Dead-letter and failure notifications |

## 7.3 Published Events

| Event name and version | Type | Producing component | Trigger | Topic | Consumers (named) | Ordering key | Schema (Appendix E) |
|---|---|---|---|---|---|---|---|

*Every event names at least one consumer, or says "no known consumer" with a reason.*

## 7.4 Consumed Events

| Event name and version | Type | Producing module | Topic | Consuming component | Handler: checks (version, tenant, duplicate, stale) | Writes (tables) | Events emitted | Failure path |
|---|---|---|---|---|---|---|---|---|

## 7.5 Producer–Consumer Matrix

| Event | This module | [Module A] | [Module B] | Integration adapter | Correspondence | Other |
|---|---|---|---|---|---|---|
| [Event] | P | C | | C | | |

## 7.6 Topics and Channels

| Logical topic | Transport name(s) | Partition / ordering key | Retention | DLQ |
|---|---|---|---|---|

## 7.7 Delivery Guarantees

[Outbox design including how the relay covers every tenant database; envelope columns; idempotency key and deduplication store; ordering and stale-event rule; retry; replay; DLQ redrive.]

## 7.8 Schema Governance

[Versioning rules; compatibility mode; registry; breaking-change process; contract tests with consumers.]

# 8. External Interactions and Shared Services

## 8.1 Inventory

| System / service | Type (external system / shared platform service / other module) | Purpose | Direction | Sync / async | Owner | Contract status (agreed / draft / unknown) |
|---|---|---|---|---|---|---|

**Required diagram:** external interaction view (may be combined with C1 if it shows mechanism and direction).

## 8.2 Interface Specifications

*One spec per entry in 8.1, detailed in Appendix F.* Minimum per spec: mechanism (REST, event, file, SDK); contract reference; authentication and credential store; data exchanged; frequency and volume; timeout and retry; fail open or closed; SLA; endpoint configuration key; test approach (stub, contract test).

## 8.3 Inbound Access

[Which external callers may call this module, with which scopes and flows (e.g. client credentials), or "None".]

## 8.4 Shared Platform Service Usage

| Service | Used? | How | Reference |
|---|---|---|---|
| Tenant Registry and feature flags | | | |
| Rules engine (InRule) | | | §2.5 |
| Correspondence | | | §2.9 |
| Reporting (SSRS replacement, ADR-019) | | | |
| Address validation | | | |
| Screening | | | |
| Outbound file delivery (S3 + MoveIt, ADR-003) | | | |
| Workflow engine (Appian, ADR-017) | | | |
| Integration adapter (outbound to state systems) | | | |

## 8.5 Reports

| Legacy report | Target (on-demand service / batch job / retired) | Format | Users | Disposition |
|---|---|---|---|---|

# 9. Data Architecture and Persistence

## 9.1 Overview

[Stores, system of record per data set, tenant boundaries, data flows.]

**Required diagram:** data architecture or data flow.

## 9.2 Data Model

| Entity / table | Purpose | Owning service | Key attributes | Relationships | Classification |
|---|---|---|---|---|---|

**Required diagram:** ERD for the core model.

## 9.3 Data Ownership

| Store / schema / table | Writing component(s) | Readers | Shared or tenant |
|---|---|---|---|

## 9.4 Database and Schema Design

[Database per tenant and schema ownership (ADR-012); shared reference data (ADR-020); naming; keys; effective dating; constraints; indexes; connection routing.]

## 9.5 Legacy-to-Target Data Mapping

[Summary; table- and column-level detail in Appendix L.]

## 9.6 Data Classification and Privacy

| Table.column | Classification (provider PII / non-sensitive / other) | Masking / encryption | Allowed in events, logs, errors? |
|---|---|---|---|

*The platform holds provider PII only; no PHI or beneficiary data (ADR-006).*

## 9.7 Lifecycle and Retention

[Create, update, end-date, archive, delete or never-delete, retention periods, legal hold, purge.]

## 9.8 Data Migration and Reconciliation

[Sources per tenant; extraction; transformation; load order; delta capture; reconciliation checks with tolerances; sign-off. Detail in Appendix L.]

## 9.9 Schema Migrations

[Tool (ADR-007); per-tenant application; expand-then-contract; failure handling; CI checks.]

## 9.10 Legacy History and Archive

[Whether legacy history is migrated, archived read-only or retired; how it is retrieved.]

## 9.11 Data Volumes

| Table / data set | Rows per tenant (now) | Growth per year | Largest file / batch |
|---|---|---|---|

# 10. Security, Identity and Tenancy

## 10.1 Entry Point and Trust Boundaries

**Required diagram:** trust boundaries and token flows for users, public flows, machine callers and service-to-service calls; WAF placement; where secrets are held.

## 10.2 Identity and Authentication

| Flow | Mechanism | Token contents | Reference |
|---|---|---|---|
| Authenticated users | | | ADR-014 |
| Public / anonymous | | | |
| Machine-to-machine | | | |
| Service-to-service | | | ADR-009 |

## 10.3 Authorization

[Roles and scopes; where each is enforced (gateway, BFF, service); segregation of duties. Matrix in Appendix G.]

## 10.4 Tenant Context and Isolation

[Tenant comes only from the token, never from request data. List each isolation boundary (ADR-023) and its negative test.]

| Boundary | Mechanism | Negative test |
|---|---|---|

## 10.5 Data Protection

[Encryption at rest (KMS key per tenant) and in transit (TLS version); PII masking in logs; PII never in errors, query strings or headers.]

## 10.6 Audit and Security Monitoring

[Audit records; CloudTrail and database audit; alerts on cross-tenant attempts; penetration testing.]

# 11. Batch and File Processing

*N/A if the module has no batch or file processing.*

| Job / feed | Source → destination | Trigger / schedule | Format (Appendix I) | Component | Outputs and events | SLA | Legacy loader |
|---|---|---|---|---|---|---|---|

[Import flow: upload, start, status, row-level errors, idempotency, reconciliation. How imported records enter the workflow.]

# 12. Infrastructure, Delivery and Operations

## 12.1 Compute and Scaling

| Component | Runtime / hosting | Scaling trigger | Ingress / network | Configuration and secrets |
|---|---|---|---|---|

## 12.2 Network and Ingress

[API Gateway, private networking, network policies, egress.]

## 12.3 Delivery

| Concern | Tool | Decision reference |
|---|---|---|

[Release strategy per component type (Lambda, EKS, frontend, batch); rollback.]

## 12.4 CI Quality Gates

[Full list; cite ARB and ADR-015.]

## 12.5 Observability

| Concern | Standard | Dashboard | Alert and threshold | Runbook |
|---|---|---|---|---|

## 12.6 Runbooks

[DLQ redrive; failed publication; failed tenant migration; failed batch; failover.]

## 12.7 Disaster Recovery

[Per runtime the module uses; RTO and RPO; failover steps.]

# 13. Non-Functional Requirements

| Metric | Target | Workload / assumption | Applies to | Measurement method |
|---|---|---|---|---|

[Response time percentiles, write latency, throughput, page load, event propagation, batch SLA, availability, RTO / RPO, retention, accessibility. Start from the program baseline; add module-specific targets.]

# 14. Testing and Quality Strategy

## 14.1 Test Levels

| Level | Scope | Tooling | Gate | Owner |
|---|---|---|---|---|
| Unit | | | | |
| Repository / data | | | | |
| API and event contract | | | | |
| Tenant isolation | | | | |
| Integration | | | | |
| UI and accessibility | | | | |
| Batch | | | | |
| Security | | | | |
| Performance | | | | |
| Migration and reconciliation | | | | |
| Legacy parity | | | | |
| Resilience / DR | | | | |

## 14.2 Golden Data Sets

[Synthetic data sets for calculations, workflows and imports, and where they live.]

## 14.3 Generated Test Artifacts

[How generated tests are reviewed before running in CI (ADR-028).]

## 14.4 Traceability Matrix

| Rule / requirement | Endpoint(s) / event(s) | Screen(s) | Test(s) |
|---|---|---|---|

# 15. Legacy Transition and Retirement

*N/A for modules with no legacy equivalent (state so).* Cite ADR-022 (strangler fig, legacy WCF retired at Gate 3) and ADR-029 (parity).

## 15.1 Transition Pattern

[Strangler fig granularity: by tenant or by capability, and why. Must be consistent with the data migration approach: by capability needs a data sync design.]

## 15.2 Coexistence

**Required diagram:** legacy and target side by side; how inputs reach both during the parallel run; the parity comparison; system of record.

## 15.3 Phases

| Phase | System of record | Legacy endpoints | Target | Exit criteria |
|---|---|---|---|---|
| Build | | | | |
| Parity / parallel run | | | | |
| Dress rehearsals | | | | |
| Cutover | | | | |
| Hypercare | | | | |
| Retirement | | | | |

## 15.4 Legacy Consumer Switch-Over

| Legacy endpoint | Legacy consumers | Switch method | Temporary compatibility component (owner, removal date) | Retire at |
|---|---|---|---|---|

## 15.5 Rollback

[Until when a tenant can roll back; what happens to data written in the target after cutover.]

## 15.6 Retirement Criteria

[Per legacy endpoint: all tenants cut over; consumers switched; no traffic for an agreed period; parity met; Operations Lead approval.]

## 15.7 Legacy Changes During Transition

[How Current State Delta Log changes (ADR-034) update this document and the parity baseline.]

# 16. Architecture Decisions

## 16.1 Decision Register

*Cite enterprise ADRs by ID; don't copy their text.*

| ID | Area | Status (Proposed / Accepted / Superseded) | Summary as applied to this module | Sections |
|---|---|---|---|---|

## 16.2 Domain Decisions

*Full detail only for decisions made for this module (DD-xx).*

- **ID / title:**
- **Status:**
- **Context:**
- **Decision:**
- **Alternatives considered:**
- **Rationale:**
- **Consequences:**
- **Owner / date:**

## 16.3 Alignment with Platform Standards

*One row per ADR in the ADR log, plus relevant ARB sections.*

| ADR / standard | Module position | Alignment (Aligned / Exception / N/A) | Rationale or exception approval (owner, status) |
|---|---|---|---|

# 17. Anti-Pattern Analysis

*Current-state problems this design removes. Each needs evidence and a verification.*

| ID | Category | Current anti-pattern | Evidence | Risk | Target remediation | Verified by (test / gate) |
|---|---|---|---|---|---|---|

Assess at least: security and identity; tenant isolation; service boundaries; data ownership; integration; performance; operations; delivery; legacy dependencies.

# 18. Risks, Assumptions and Open Questions

## 18.1 Risks

| ID | Category | Description | Probability | Impact | Mitigation | Owner | Status |
|---|---|---|---|---|---|---|---|

## 18.2 Assumptions

| ID | Assumption | Impact if wrong | Owner | Confirm by |
|---|---|---|---|---|

## 18.3 Open Questions and Conflicts

| ID | Topic | Question or conflict | Current position in this document | Proposed resolution | Owner | Due | Severity | Status |
|---|---|---|---|---|---|---|---|---|

# 19. Repository Structure and Build Plan

## 19.1 Repository Layout

```text
[repository-root]/
├── components/
│   └── [module]/
│       ├── ux/
│       ├── bff/
│       ├── services/
│       ├── api-specification/
│       ├── db/
│       ├── batch/
│       └── tests/
├── shared-libs/
└── iac/
```

## 19.2 Module and Service Structure

[Actual folders, projects, packages, contract files, migrations, jobs, tests, deployment files.]

## 19.3 Legacy Capability to Layout Mapping

| Legacy capability / flow | Screen | BFF route | Service | Data / event / job | Rule IDs |
|---|---|---|---|---|---|

## 19.4 Slice Catalog and Build Order

| Order | Slice | Depends on | Rules | Endpoints | Events | Tables | Screens | Jobs | Legacy sources |
|---|---|---|---|---|---|---|---|---|---|

**Definition of done per slice:** [e.g. acceptance tests pass; contracts published; screens accessible; isolation suite green; generated spec approved by SA].

# 20. Readiness

| Item | Status | Evidence |
|---|---|---|
| Business scope agreed | | |
| Legacy inventory complete (Appendix K) | | |
| Business rules and acceptance criteria complete | | |
| HLD diagrams complete | | |
| Frontend, BFF and service designs complete | | |
| API, BFF and event contracts complete | | |
| Data model, DDL and migration approach complete | | |
| External interface specs complete | | |
| Security and isolation defined | | |
| Platform alignment complete; exceptions approved | | |
| NFRs measurable | | |
| Legacy transition defined | | |
| Risks and questions owned; no open Blockers | | |
| Review report (checklist v2) | | |
| SA / ARB / business sign-off | | |

---

# APPENDICES — LOW-LEVEL DESIGN

*Give each appendix a status line like any section (Complete, Partial, Not started, N/A with reason, or Inherited with parent reference). If its content is maintained in a separate controlled file, give the path and version.*

## Appendix A — API Standards

Base paths and versioning; authentication, tenant and user context; correlation and idempotency headers; error model (RFC 7807) and validation errors; concurrency (version field and 409); workflow action endpoints; paging, filtering and sorting; JSON naming policy; scopes in the contract; breaking-change policy.

## Appendix B — Domain OpenAPI Contracts

One OpenAPI 3.x file per service or area. Every operation has: request and response schemas (responses are not copies of requests); error responses; security with scopes; idempotency header on state changes; version field on updates; request, response and error examples. Readable schema names (no generator hashes); one casing policy. Legacy operation names kept for traceability (e.g. `operationId` or `x-legacy-*`).

| File | Base route | Service | Version |
|---|---|---|---|

## Appendix C — BFF Contracts

OpenAPI for every composed BFF endpoint; routing table for pass-through routes; view models.

## Appendix D — Database Schema

ERD; DDL for every table (or a pointer to a named legacy entity); keys, constraints (including overlap and status), indexes; database and schema placement; audit and history columns; migration file references. The DDL must run on an empty database of the target engine version.

## Appendix E — Event Contracts

AsyncAPI document: channels, envelope, one message per published and consumed event, payload schema and example for each.

## Appendix F — External Interface Specifications

One subsection per system or shared service in §8.1, with the minimum content listed in §8.2.

## Appendix G — Authorization Matrix

| Role | Scope | Operation (domain and BFF) | Conditions / segregation of duties |
|---|---|---|---|

Include machine callers and service identities.

## Appendix H — Screen Specifications and Navigation

**H.0 Navigation map.** Then one card per screen:

```markdown
#### H.x <Screen name> (SCR-xx)
| Item | Value |
|---|---|
| Route | |
| Disposition | Preserve / Change / New |
| Roles | |
| Reference screen | <file or link> |
| Legacy view | <file> |
| BFF endpoint(s) | |
| Feature flag | |

Search criteria: | Field | Control | Required | Validation | DataList |
Grid columns:    | Column | Field | Sortable | Format |
Form fields:     | Field | Control | Required | Validation (rule ID) | Editable in status |
Actions:         | Action | Visible when (status, role) | Calls | Confirmation / comment |
States: empty, loading, no results, 400, 403, 409, 5xx
Accessibility notes:
```

## Appendix I — Batch and File Formats

Per feed: file naming; source and destination; format, encoding and schema (column by column); header, trailer and control totals; validation rules (with legacy source); duplicates and idempotency; reject and error file format; schedule, retry, SLA; reconciliation; owner. Version tenant-specific templates.

## Appendix J — Configuration Catalog

| Key / flag | Type | Default | Scope (tenant / environment) | Used by | Owner |
|---|---|---|---|---|---|

## Appendix K — Legacy Inventory and Traceability

Screens and workflows; endpoints (WCF, SOAP, Web API, OData); tables and columns; batch jobs and feeds; events and downstream consumers; business rules and calculations; reports; configuration settings. Every item has a disposition and a target reference. Where this document defers to legacy, name the legacy class, file or KG node.

## Appendix L — Migration, Reconciliation and Cutover Detail

Source-to-target mapping at column level; profiling findings; transformation rules (including normalizations and status mapping); load order; reconciliation queries and tolerances; parallel-run comparison cases; cutover and rollback runbook references; decommissioning criteria.

## Appendix M — Known-Difference Register

| ID | Behaviour | Legacy | Target | Reason | Approved by (SA, customer) | Evidence |
|---|---|---|---|---|---|---|

## Appendix N — Glossary and References

| Term | Definition |
|---|---|

List all sources (documents, repositories, decisions, diagrams) with version, date and location.

---

# Author Self-Check (before requesting review)

- [ ] Every section has a status line using one of the five statuses; Partial names the gap; Not started names an owner or question; N/A says why the section does not apply; Inherited cites the parent section.
- [ ] No section marked Partial is empty, and no section marked Complete fails its checklist items.
- [ ] Source precedence is filled in (0.4).
- [ ] Every "Required diagram" is present and its names match the contracts.
- [ ] Every rule has an ID, an owner, an outcome and acceptance criteria.
- [ ] Every event has a type, producer, consumers, schema and example.
- [ ] Every external system has an interface spec.
- [ ] Every table has DDL or a legacy pointer, and the DDL runs.
- [ ] Every contract parses and has examples.
- [ ] Every ADR is in the alignment table (16.3); every exception has an owner.
- [ ] Every Assumption, Proposal and Open label has a row in §16 or §18.
- [ ] No superseded technology names (review checklist Appendix Q).
- [ ] Only synthetic data.
- [ ] Run the review checklist (`target-state-review-checklist-v2.md`) and attach the report.
