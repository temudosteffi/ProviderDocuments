# Plan Management (CM-PL) — Target State

| | |
|---|---|
| **Program** | Provider Plus Modernization |
| **Module** | Plan Management (CM-PL), supporting module (ARB §2.1) |
| **Version** | v8 — 2026-11-01 — Draft |
| **Purpose** | Defines what CM-PL must do (Part I) and how it is built (Part II), with the low-level design in Appendices A–N. It is the input to spec-driven development (ADR-033) and to architecture review. |
| **Governing rule** | Business workflows are the same as legacy (DD-06). Where this document is silent, legacy behaviour applies. |

## How to Read This Document

| Reader | Start with | Then |
|---|---|---|
| **Architect / ARB reviewer** | §0.6 Target-State Summary | §3 Architecture, §16 Decisions and ADR alignment, §18 Risks and open questions, §20 Readiness |
| **Business / product owner** | §1 Scope, §2 Business rules | Appendix M (what differs from legacy), §18.3 (questions for the business) |
| **Spec-generation agent** | §0.4 Conventions and §0.8 Spec Generation Map | The section and appendix named in §0.8 for the artifact being generated |
| **Developer / tester** | §0.8, §19 Build order | §2 rules, Appendices B (APIs), D (tables), E (events), I (files), §14 tests |

Every numbered section opens with a **section header**:

> **Status:** Complete / Partial / Open / N/A · **Sources:** where the content comes from · **Feeds:** the spec artifacts generated from it

---

# 0. Document Control

## 0.1 Document Information

| Field | Value |
|---|---|
| Module name and code | Plan Management (CM-PL) |
| Module type | Supporting (ARB §2.1) |
| Parent document | N/A |
| Version | v8 |
| Status | Draft — not yet SDD ready (§20) |
| Date | 2026-11-01 |
| Owner | TBD |
| Reviewers and approvers | TBD (SA, Business lead, Data lead, Security) |
| Classification | Internal |
| Supersedes | `target-state-plan-management-v7.md` and all earlier versions (v6, v5, final.md v1.1) |
| Contract and schema files | Appendices B (OpenAPI), C (BFF), D (DDL), E (events), I (file formats) |

## 0.2 Revision History

| Version | Date | Author | Change summary |
|---|---|---|---|
| v1.0 – v5 | 2026-11-01 | Satya, Shyam | Baseline, consolidated corrections, Template v2 alignment |
| v6 | 2026-11-01 | Satya | Closed review gaps G-01..G-33: per-state database, `db_shared` access model, complete legacy table disposition (K.1), DDL fixes, search schemas, ADR alignment, decision IDs |
| v7 | 2026-11-01 | Satya | Business workflows aligned to legacy (DD-06); features with no legacy equivalent removed and recorded in Appendix M; §1–§2 rebuilt from the legacy guides; national data with state edits (DD-07); DataLists owned by Configuration Management |
| **v8** | 2026-11-01 | Satya | **Editorial and governance refinement.** Reader guide, section headers (Status · Sources · Feeds), ID and label conventions (§0.4), spec generation map (§0.8). Open questions re-checked against the ADR Live Document and ARB: Q-02, Q-05, Q-09 closed; Q-01, Q-04 recorded as deviations; Q-10 partly answered (ADR-025 library names adopted); new Q-32 (DataList validation without a synchronous cross-domain call). Previously empty sections written from ADRs: §5.3, §5.4, §6.5, §7.5, §7.8, §12.4, §12.6, §12.7, §17, §18.1, Appendices F, J, L, N. Decision register and ADR alignment rebuilt as tables. Stale v6 wording removed (workflow, precedence, CSRF). No business rule changed |

## 0.3 Governing Inputs

| ID | Input | Version / date | Location | Used for |
|---|---|---|---|---|
| ARB | ARB Provider Plus Modernization (summary) | v22, 2026-07-07 | `ARB-Provider-Plus-Summary.md` | Platform architecture |
| ADR | ADR Live Document (ADR-001 – ADR-041) | As of 2026-11-01 | `ADR_Live_Document.txt` | Ratified platform decisions |
| UG | Plan Management User Guide | R30.2609 | `Downloads\PlanManagement\PlanManagement` | Business behaviour (cited by printed page) |
| CRG | Configuration Reference Guide | R30.2610 | same | Settings, roles, DataLists (printed page) |
| SPG | Scheduled Processes Guide | R30.2610 | same | Loaders, File to Event (printed page) |
| RN | Release Notes | R30.2610 | same | Recent behaviour changes (printed page) |
| FN | Feature Narrative | — | same | Business context (PDF page) |
| RT | Regression Test Cases | — | same | Test cases |
| INV | Legacy table inventory | 2026-09-02 | `Table-Classification-20260902-154232.xlsx` | 80 `UA3_PLAN_MGMT` tables (Appendix K.1) |
| LGCY | Legacy code | TBD | `C:\PP\lgcy\mms-cms-pl` | Business behaviour where the guides are silent |
| WF | Reference workflows | — | `Provider_Plan_Management_Functional_Workflows_and_Dropdown_Fields 1.docx` | Dropdown fields only (its approval workflow is not adopted, DD-06) |

## 0.4 Conventions

### 0.4.1 Source precedence

When sources disagree, the row below wins for that concern.

| Concern | Authoritative source | Notes |
|---|---|---|
| Business behaviour (rules, validations, data kept, workflows) | Legacy code and guides (UG, CRG, SPG) | Same as legacy (DD-06). Intentional differences are only those in Appendix M |
| Interfaces and technology | This document | Legacy WCF/SOAP, Web API 2, OData, MVC/Razor, SSIS and console loaders are not reproduced (§6.3, §11) |
| API paths, operationIds, request and response shapes | Appendix B | |
| Event names and payloads | Appendix E | |
| Tables and columns | Appendix D | Tables listed in §9.2 without DDL mirror the legacy entity columns using the conventions of D.1 |
| Platform standards | ARB and ADRs | Except the deviations listed in §16.3 |

### 0.4.2 Statement labels

Plain text is fact and cites its source. Anything else carries one of these labels and an ID that is defined in the register named.

| Label | Meaning | Register |
|---|---|---|
| `Decision (ADR-xxx)` | Ratified enterprise decision | ADR Live Document; alignment in §16.3 |
| `Decision (DD-xx)` | Domain or program decision for CM-PL | §16.1 |
| `Assumption (AS-xx)` | Believed true, not confirmed | §18.2 |
| `Open (Q-xx)` | Unresolved question | §18.3 |
| `Deviation (DV-xx)` | Departure from an ADR or the ARB awaiting approval | §16.3 |
| `Known difference (M-xx)` | Intentional difference from legacy | Appendix M |

### 0.4.3 Identifier registry

| Prefix | Object | Defined in | Example |
|---|---|---|---|
| BR- | Business rule | §2.1 | BR-011 Insert New |
| DD- | Domain / program decision | §16.1 | DD-06 Legacy parity |
| DV- | Deviation from ADR or ARB | §16.3 | DV-01 NestJS BFF |
| AS- | Assumption | §18.2 | AS-12 extra `db_shared` tables |
| Q- | Open question | §18.3 (open), §18.4 (resolved) | Q-23 ADR-020 extension |
| R- | Risk | §18.1 | R-01 |
| M- | Known difference from legacy | Appendix M | M-03 No pricing precedence |
| NFR- | Non-functional requirement | §13 | NFR-01 API latency |
| `pm_` | Table | Appendix D | `pm_provider_ucc_rate` |
| `plan.*` / `integration.plan.*` | Published / consumed event | Appendix E | `plan.rate_setting.updated.v1` |

### 0.4.4 Disposition terms

Used for capabilities, rules, screens, interfaces and data: **Preserve** (same behaviour), **Change** (same business outcome, different implementation), **Retire** (not carried forward), **New** (no legacy equivalent; platform need only).

### 0.4.5 Rules for spec-generation agents

1. Generate only from the authoritative source in §0.4.1 and the section named in §0.8.
2. Never generate behaviour for an item labelled **Open** or **Assumption** as if it were settled. Generate the closest documented default and emit a `TODO(Q-xx)` or `TODO(AS-xx)` marker.
3. Put the BR id in a code comment where the rule is implemented and in the name of at least one test.
4. Do not add features listed in Appendix M.1 (approval workflow, pricing precedence, contract participation, fee schedule assignments, retroactive corrections, NeedsReview, MCO records, InRule calls, Plan Management DataList tables).
5. Use synthetic data only.
6. Use the names in the contracts exactly (table, column, path, operationId, event). Do not invent new names.

## 0.5 Decision and Question Status

| Area | Closed | Open | IDs |
|---|---|---|---|
| Business behaviour | Q-13, Q-14, Q-15, Q-20, Q-21, Q-22, Q-26, Q-28, Q-29 | Q-11, Q-16, Q-30, Q-31 | §2, §18.3 |
| Data | Q-05, Q-25 | Q-23, Q-24 | §9, §18.3 |
| Integration and eventing | Q-08 | Q-07, Q-12, Q-18, Q-27, Q-32 | §7, §8 |
| Architecture and platform | Q-02, Q-06, Q-09 | Q-01, Q-03, Q-04, Q-10 | §3, §16 |
| Legacy transition | — | Q-17, Q-19 | §15 |
| **Total (32)** | **15** | **17** (of which 4 blockers, §18.3) | |

## 0.6 Target-State Summary

| Dimension | Target position | Source |
|---|---|---|
| Business scope | Reference data (code sets, pharmacy data, groupings, related data), seven provider-specific rate types, member-specific rates, fee schedules and cycles | §1 |
| Business workflow | Same as legacy: add, edit, copy, insert, invalidate, Release Status, uploads; no in-system approval | DD-06 |
| Architecture style | CRUD, no CQRS; transactional outbox; effective dating; audit | ADR-041, DD-04 |
| Entry point | Amazon API Gateway with native JWT authorizer and regional WAF | ADR-008, ADR-031 |
| UI | `mfe-plan-management` Next.js micro frontend on S3 + CloudFront | ADR-011 |
| BFF | Shared NestJS 10 BFF with a Plan Management module | DD-01, **deviation DV-01** from ADR-011 (.NET 10) |
| Domain services | Four .NET 10 services on Amazon EKS Auto Mode (`plan-mgmt` namespace) | ADR-004, §6.2 |
| Data | Schema `plan` in the state's operational database `pp_{tenant}`; national base data in `db_shared`; state edits in `*_state` tables | ADR-012, ADR-020, DD-07 |
| Eventing | Event Backbone through the Event Adapter; outbox relay; Glue Schema Registry | ADR-002, ADR-002a, ADR-037 |
| Integration | Outbound and client-sourced (level 80) data through CMS-INX (ARB name: External Integration Adapter) | DD-08, **deviation DV-04** |
| Batch | AWS Glue Spark (Python 3.12) on Amazon MWAA | ADR-010 |
| Identity | IRM broker, FAPI 2.0, bearer JWT with `tenant_id`, `sub`, `roles` | ADR-014 |
| Delivery | GitHub Actions, Terraform, Helm, Argo CD, Argo Rollouts | DD-03, **deviation DV-03** from ADR-015 |
| Transition | Strangler fig; legacy WCF retired at Gate 3; parity thresholds 80/95/98% | ADR-022, ADR-029 |
| Open blockers | Q-23 (ADR-020 extension), Q-07 (CMS-PM events), Q-11 (member data), Q-32 (DataList validation) | §18.3 |
| Deviations awaiting approval | 6 (DV-01 – DV-06) | §16.3 |
| SDD readiness | Not ready — blockers open (§20) | §20 |

## 0.7 Section Status Index

| Section | Status | What is missing |
|---|---|---|
| 1 Business Scope and Capabilities | Complete | — |
| 2 Business Logic | Partial | Acceptance criteria per rule; Q-30, Q-31 |
| 3 Architecture Overview | Complete | — |
| 4 Frontend | Partial | Navigation map |
| 5 BFF | Partial | Composed endpoint schemas (Appendix C) |
| 6 Domain Services | Partial | Q-32 |
| 7 Eventing | Partial | AsyncAPI files; Q-07, Q-27 |
| 8 External Interactions | Partial | Q-12, Q-18, Q-27 |
| 9 Data Architecture | Partial | Column-level mapping; volumes (Q-24); member data (Q-11); Q-23 |
| 10 Security, Identity and Tenancy | Complete | — |
| 11 Batch and File Processing | Partial | Per-feed formats for CMS/FDB code sets |
| 12 Infrastructure and Operations | Partial | Runbook content; DV-03 |
| 13 Non-Functional Requirements | Complete | — |
| 14 Testing and Quality | Partial | Tests linked in the traceability matrix |
| 15 Legacy Transition | Partial | Q-17, Q-18, Q-19 |
| 16 Decisions and Alignment | Complete | Approvals of DV-01 – DV-06 |
| 17 Anti-Patterns and Failure Modes | Complete | — |
| 18 Risks, Assumptions, Questions | Complete | Owners for risks |
| 19 Repository and Build Plan | Partial | §19.3 mapping |
| 20 Readiness Evidence | Partial | Checklist re-run |
| Appendices A–N | Partial | See each appendix status line |

## 0.8 Spec Generation Map

| Spec artifact | Generate from | Must also honour | Blocked by |
|---|---|---|---|
| Domain OpenAPI documents | Appendix B (authoritative), Appendix A | §2.1 rules, Appendix G scopes, §6.4 standards | — |
| BFF module (routes, composed endpoints) | §5, Appendix C | §5.4 token model, §10 | DV-01 approval |
| Domain service code (controllers, domain rules, repositories) | §6, §2 | §0.4.5, §6.6, §6.7 | Q-32 (DataList validation) |
| Database migrations (Alembic) | Appendix D, §9.4, §9.9 | D.1 conventions, §9.3 ownership | Q-23 (shared tables), Q-11 (member tables) |
| Event contracts (AsyncAPI) | Appendix E, §7 | ADR-002 envelope, §7.8 | Q-07, Q-27 (consumed payloads) |
| Glue jobs and Airflow DAGs | §11, Appendix I | BR-011, §9.7 retention | — |
| Micro frontend screens | §4, Appendix H | §2 rules, Appendix G | — |
| Helm charts, Terraform | §12, §19 | §10.4 isolation | DV-03 approval |
| Test suites | §14, §2.1 | §10.4 isolation tests, §13 NFRs | — |
| Migration and reconciliation scripts | §9.8, Appendix K, Appendix L | §9.5 mapping | Q-24, Q-19 |

---

# PART I — BUSINESS

# 1. Business Scope and Capabilities

> **Status:** Complete · **Sources:** UG, FN, CRG · **Feeds:** capability backlog, screen inventory (Appendix H), authorization (Appendix G)

## 1.1 Purpose

Plan Management maintains the reference data and rate information that other modules use to process transactions: code sets, pharmacy data, groupings, related data (edits, explanation codes), provider-specific and member-specific rates, fee schedules and processing cycles (FN p.2–18; UG p.103).

> Provider Management says **who** the provider is. Plan Management holds **the codes, rates and fee schedules** that apply to that provider's services.

Plan Management does not decide which rate applies to a claim. It stores effective-dated rates; consuming modules (Claims) select by date of service (FN p.8).

## 1.2 Capabilities

| Capability | Description | Disposition | Legacy source |
|---|---|---|---|
| Code sets | HCPCS, Dental (ADA), Revenue, DRG, ICD-9/ICD-10 diagnosis and procedure codes with effective-dated restrictions; modifiers as DataList items | Preserve | UG p.18–53; SPG p.50–92 |
| Pharmacy related data | NDC with CMS NDC information and status dates, indicators, COD status, rebate indicators, packages and NDC rates; labeler codes with rebate programs; GSN | Preserve | UG p.55–74 |
| Groupings | Code groupings (ranges and items, include/exclude) and "code exists within grouping" | Preserve | UG p.14–17 |
| Related data | NCCI and MUE bundling (Practitioner, OPHOS, DME), EOB, EEC with resolution criteria, EIC, HCPCS–NDC crosswalk | Preserve | UG p.75–102 |
| Provider-specific rates | Seven rate types: Usual and Customary Charges (UCC), Nursing Facility, Encounter, DRG (with custom DRG), Dispensing Fee, Inpatient, Outpatient | Preserve | UG p.104–130 |
| Member-specific rates | Rates for an individual member at a provider location | Preserve | UG p.131–133; FN p.16 |
| Fee schedules | Field-driven fee schedules: chosen fields, business identifiers, optional and user-defined fields, lines, Release Status, copy header and details, insert rows | Preserve | UG p.134–143 |
| Manage cycles | Cycle dates that control data selection windows for scheduled processing | Preserve | UG p.153–155 |
| File upload | Template-based uploads for code sets, NDC, rates, fee schedules, groupings and EOB, with statistics and error files | Change (Glue jobs) | UG p.144–152; SPG p.2–103 |
| Client-sourced updates | Code sets and NDC data sent by a client system of record (maintenance level 80), applied as events | Change (CMS-INX events) | SPG p.113–137 |
| Exports and reports | Export to Excel, PDF and upload template; grouping PDF report; loader statistics | Preserve | UG p.3, 14; CRG p.88 |
| Audit | Added and updated events per record, with before and after values | Preserve | UG p.2, 129 |
| Change publication | Every change is published for consuming modules | Change (Event Backbone replaces BizTalk event distribution, CRG p.88) | — |

## 1.3 Ownership Boundary

| Owned elsewhere | Owned by Plan Management (CM-PL) |
|---|---|
| Provider and service location — CMS-PM (Plan Management keeps a read-only reference copy) | Code sets and code restrictions (state copy and overrides, §2.1.3) |
| Members — Member module (Plan Management keeps the member reference needed for member-specific rates) | Pharmacy related data, labelers and rebate programs |
| DataLists and their maintenance levels — Configuration Management (CRG p.1, UG p.7) | Groupings and related data |
| Claims pricing and rate selection — Claims | Provider-specific and member-specific rates |
| | Fee schedules and cycles |

Plan Management never writes provider, member or DataList data.

## 1.4 Out of Scope

| Item | Reason | Reference |
|---|---|---|
| Rate selection for claims (pricing precedence) | Done by consuming modules; not a Plan Management function in legacy | M-03 |
| In-system approval workflow | Approval is a business process outside the system in legacy (FN p.17–20) | M-01, M-02 |
| Contract participation, standalone fee schedule assignments, retroactive-correction workflow, MCO and plan records | No legacy equivalent | M-04 – M-09 |
| DataList maintenance; provider enrollment and credentialing; member enrollment; claims adjudication; state policy authoring | Owned by other modules | §1.3 |

## 1.5 Actors and Roles

| Actor | Legacy role (CRG p.82–83) | Target role | What they do |
|---|---|---|---|
| Rate user | PLProvRateUser | `pm.rate-viewer` | View rates and fee schedules |
| Rate analyst | PLProvRateAnalyst | `pm.rate-analyst` | Add, edit, copy, insert and invalidate provider-specific rates, member-specific rates and fee schedules |
| Rate loader | PLProvRateLoader | `pm.rate-loader` | Upload rates for the seven rate types |
| Plan Management manager | PLManager | `pm.manager` | Maintain reference data and uploads |
| Plan Management administrator | PlanManagement Administrator, SystemAdministrators | `pm.admin` | All Plan Management actions |
| DataList roles | PLDatalistUser, PLDatalistAnalyst, PLDatalistAnalystRestrictedUse, PLDatalistAdministrator | Configuration Management roles | DataList maintenance (outside Plan Management) |
| Provider Plus UI (BFF) | — | Service identity | Calls Plan Management APIs on behalf of users |
| Batch jobs, event consumers | — | Service identity | Imports, client-sourced updates, provider reference sync |

Scopes per role are in Appendix G.

## 1.6 Business Objects

| Object | Source | Purpose |
|---|---|---|
| Provider, service location | CMS-PM (local reference copy) | Every provider-specific rate belongs to a provider service location |
| Member | Member module (local reference) | Target of member-specific rates |
| Code set entry and restriction | CMS / vendors (national base) plus state additions and edits | Codes, descriptions and coverage restrictions by date |
| NDC, labeler, GSN | FDB, CMS (national base) plus state additions and edits | Pharmacy reference data |
| Provider-specific rate | Plan Management | One of seven rate types, effective-dated |
| Member-specific rate | Plan Management | Rate for a member at a provider location |
| Fee schedule, fee schedule line | Plan Management | Field-driven rate tables |
| Grouping, related data, cycle | Plan Management | Reference data used by other modules |
| Change Request ID | DataList (client-defined) | Tracks the policy change behind every add or copy (CRG p.8) |

```mermaid
flowchart LR
  P["Provider (CMS-PM copy)"] --> L["Service location"]
  L --> PSR["Provider-specific rate<br/>(7 rate types)"]
  M["Member (reference)"] --> MSR["Member-specific rate"]
  L --> MSR
  C["Code set entry<br/>(national base + state edits)"] --> PSR
  C --> FSL["Fee schedule line"]
  FS["Fee schedule<br/>(fields, identifiers, Release Status)"] --> FSL
  CR["Change Request ID<br/>(DataList)"] -.-> PSR
  CR -.-> FS
  CR -.-> C
```

# 2. Business Logic

> **Status:** Partial — acceptance criteria per rule pending; Q-30, Q-31 open · **Sources:** UG, CRG, RN, FN · **Feeds:** domain rules (`Domain/` folders), validation, tests (§14.4)

## 2.1 Business Rules Catalogue

Each rule is implemented in exactly one service's `Domain/` folder, with its ID in a code comment and in the name of at least one test.

| ID | Rule | Enforced in | Legacy source |
|---|---|---|---|
| BR-001 | A provider-specific rate needs a provider and service location that exist in the provider reference ("A valid match was not found for the entered value") | Rate Setting | UG p.104, 182 |
| BR-002 | The service location must belong to the selected provider | Rate Setting | UG p.104 |
| BR-003 | Provider Location ID is required for all seven provider-specific rate types; there is no provider-level rate without a location | Rate Setting | UG p.108–128 |
| BR-004 | A member-specific rate needs a member that exists in the member reference ("Member ID – Name is a required field") | Rate Setting | UG p.182 |
| BR-005 | Codes used in rates, fee schedules and restrictions must be valid for the effective period | All services | UG p.170–190 |
| BR-006 | Rate type, pricing method, rate category, code type and rate adjustment values come from DataLists | All services | CRG p.52–56 |
| BR-007 | Rate Amount or Rate Percent is required ("Rate Amount or Rate Percent is required") | Rate Setting | UG p.178 |
| BR-008 | Effective Date is required; End Date defaults to MaxDate (12/31/9999) and is not before Effective Date; dates lie between MinDate and MaxDate | All services | CRG p.76 |
| BR-009 | Processing Start and End Dates: required when the matching *RateProcessingDatesRequired setting is true; both or neither; Processing Start Date cannot be before today | Rate Setting | CRG p.72–78; UG p.187 |
| BR-010 | No two valid records with the same pricing key (§2.2.1) may overlap in effective period ("Effective or End Date overlaps an existing {0} Rate record") | Rate Setting | UG p.163 |
| BR-011 | Insert New (online or upload): the new row end-dates the existing row to the day before its Effective Date; it may overlap only one existing row, and that row must be open-ended | Rate Setting | UG p.112, 116, 123, 126, 129, 142–143 |
| BR-012 | Change Request ID is required to add or copy a rate, fee schedule or code set entry; it is not copied | All services | UG p.21, 107; CRG p.8 |
| BR-013 | Date-based edit limits: when Effective Date, End Date and Processing Start Date are on or before today, only Processing End Date can be edited | Rate Setting | UG p.140 |
| BR-014 | Records are never deleted; they are invalidated (Valid flag) or end-dated | All services | UG p.133 |
| BR-015 | Fee schedule Release Status is Pending, Test, Release or Delete; a copied header starts as Pending; Edit Fields is available only while Pending | Rate Setting | CRG p.58; UG p.137, 142 |
| BR-016 | Fee schedule business identifiers define the unique key used by overlap checks; at least one identifier is required, and an identifier must also be a required field | Rate Setting | UG p.139–140, 177–178 |
| BR-017 | A procedure code cannot have duplicate modifiers | Rate Setting | UG p.183 |
| BR-018 | Dispensing Fee: blank Drug Type or Dispensing Type means ALL | Rate Setting | UG p.122 |
| BR-019 | Maintenance level controls what users may do with a code set: 01/40 full, 30 add only, 50 update and inactivate, 60 inactivate only, 80 client-sourced (view only, no audit), 90 and 99 view only | Code Information | CRG p.14; UG p.56–57 |
| BR-020 | MUE and NCCI edit panels are read-only when the Effective Date is in the past | Related Information | RN p.5 |
| BR-021 | Labeler codes can be added or edited only when DrugLabelerSource = Plan Management; each labeler needs at least one rebate program with effective and end dates | Code Information | UG p.68–71 |
| BR-022 | Data of one tenant is never visible to another tenant | All services | ADR-023 |
| BR-023 | Every add and update is audited with date, user and source of change, and before and after values for rates; client-sourced (level 80) changes are not audited | All services | UG p.2, 129, 148 |
| BR-024 | Exact duplicate records are rejected | All services | UG p.163 |
| BR-025 | Publication failure is visible and retriable | All services | Target platform (M-26) |
| BR-026 | Only actions allowed for the caller's role are permitted (legacy security functions, Appendix G) | All services | CRG p.82–83 |

### 2.1.1 Provider and Location Reference

| Aspect | Behaviour | Source |
|---|---|---|
| Initial load | One-time migration load of `pm_provider` and `pm_provider_service_location` from the legacy Initial Provider Loader fields: ProviderId, ServiceLocationId, ProviderBillingId, EnrollmentTypeCD (F, IG), LocationName (IG: "LastName, FirstName"), IsActive, BusinessName, FirstName, LastName | SPG p.98–103 |
| Ongoing sync | `provider.registered.v1`, `provider.updated.v1`, `provider.terminated.v1` from CMS-PM upsert the reference copy and its active flag (Appendix E.3). The ARB names `provider.approved.v1` as the event CM-PL consumes | **Assumption (AS-03)**, **Open (Q-07)** |
| Effect on rates | No rate changes automatically when a provider or location changes | UG ch. V |
| Inactive provider | Whether an inactive provider or location blocks new rates | **Open (Q-30)** |

### 2.1.2 Reference Data and Maintenance Levels

| Data | Source and cadence | Online maintenance by state users |
|---|---|---|
| HCPCS, CPT | CMS; quarterly HCPCS, annual CPT (UG p.152) | Add and edit, by maintenance level |
| ICD-9/ICD-10, DRG, Revenue, Dental | CMS / licensed vendor | Add and edit, by maintenance level |
| Modifiers | ModifierLoader into DataList items (SPG p.61) | Through Configuration Management |
| NDC, packages, NDC rates, GSN, HICL, manufacturer | First Databank; weekly (UG p.152) | NDC, packages, rates, GSN editable; HICL and manufacturer load only |
| CMS NDC information, status dates, COD status | CMS NDC file, quarterly (SPG p.3) | Add and edit |
| Labeler codes | CMS Drug Rebate Labeler file, quarterly (UG p.61, 144) | Per BR-021 |
| HCPCS–NDC crosswalk | Noridian, monthly (SPG p.45) | Edit loaded values |
| NCCI, MUE | CMS, quarterly (FN p.15) | Add and edit (BR-020) |

The maintenance level of each code set is configured in Configuration Management (DataList Maintenance Level, CRG p.14) and enforced by Plan Management (BR-019).

### 2.1.3 National Data with State Edits (DD-07)

Legacy keeps a full copy of national reference data per state and lets state users add and edit it (UG p.18–71). The target keeps that behaviour on top of the shared national store (ADR-020).

| Layer | Where | Written by |
|---|---|---|
| National base | `db_shared.plan` (`pm_code`, `pm_ndc`, …) | Loader Glue jobs only (ADR-020) |
| State additions and edits | Tenant `*_state` table of the same shape, `base_id` → national row (null for a state-only addition) (Appendix D.3.3) | Code Information Service; client-sourced events (level 80) |
| Read rule | Return the state row where one exists for the same natural key and period, otherwise the national row | Code Information Service |

Tables beyond the ADR-020 list are placed in `db_shared` under **Assumption (AS-12)**; ADR-020 must be extended (**Open (Q-23)**).

## 2.2 Calculations and Decision Logic

Plan Management performs no rate calculation and no rate selection. It validates and stores rates; consuming modules select by date of service (FN p.8, p.10).

### 2.2.1 Pricing Keys and Overlap

Every provider-specific rate also carries: provider service location (BR-003), Effective and End Date, Processing Start and End Date, Change Request ID, Valid, Rate Adjustment (01 with claim adjustment, 02 without; CRG p.54) and VOS tags.

| Rate type | Key fields (BR-010) | Value fields | Legacy source |
|---|---|---|---|
| Usual and Customary Charges (UCC) | Code Type, Code, Rate Category, Modifiers 1–4 | Rate Amount | UG p.108; SPG p.159 |
| Nursing Facility | Code Type (Revenue or Level of Care), Code, Rate Category | Rate Amount | UG p.111 |
| Encounter | Encounter Type (optional), Rate Category | Rate Amount | UG p.114–115 |
| DRG | DRG Code, Rate Category, Severity of Illness | Rate Amount, Base Rate, Cost Charge Ratio, cost and day outlier, capital, educational, paid, disproportionate share; custom DRG type, amount, percent | UG p.118–119 |
| Dispensing Fee | Provider Specialty, Drug Type, Dispensing Type (blank = ALL), Ingredient From and To | Rate Amount | UG p.122 |
| Inpatient | Code Type, Code, Rate Category | Rate Amount | UG p.125 |
| Outpatient | Code Type, Code, Rate Category | Rate Amount or Rate Factor (percent) | UG p.128 |
| Member-specific | Member, provider location, Code Type, Code (Level of Care) | Rate Amount | UG p.131–133 |
| Fee schedule line | The fee schedule's business identifier fields (BR-016) | Rate Amount, Rate Percent, adjustment factors, units | UG p.139–140 |

Rate Category values: Case Rate, DRG, Flat Rate, Other, Per Diem (CRG p.55).

### 2.2.2 Processing Dates

Effective and End Date give the validity of the rate by date of service. Processing Start and End Date (legacy `RateStartDate`, `RateEndDate`) bound when the rate may be used in processing (**Assumption (AS-14)**, inferred from UG p.140 and CRG p.72–78). Whether they are required is set per rate type by the *RateProcessingDatesRequired settings (default false; Appendix J).

## 2.3 Maintenance Lifecycle

There is no in-system approval workflow; review and approval happen outside the system and are referenced by the Change Request ID (FN p.17–20, DD-06).

### 2.3.1 Records and Their Operations

| Record | Operations | Legacy source |
|---|---|---|
| Provider-specific rate (seven types) | Search (also from Provider Management), view, add, edit (BR-013), copy, insert new, invalidate, upload, audit | UG p.104–130 |
| Member-specific rate | Search, view, add, edit, invalidate | UG p.131–133 |
| Fee schedule header | Search, view, add, edit, edit fields (Pending only), copy header, copy details, set Release Status, lock during batch upload | UG p.134–143 |
| Fee schedule line | Add, edit (BR-013), insert new rows, invalidate, upload (including invalid segments for conversion) | UG p.140–147 |
| Code set entry and restriction | Search, view, add, edit (by maintenance level and Change Request ID) | UG p.18–53 |
| NDC and sub-panels, labeler, GSN | Search, view, add, edit | UG p.55–74 |
| Grouping | Search, view, add, edit, validate, invalidate | UG p.14–17 |
| NCCI, MUE, EOB, EEC, EIC, HCPCS–NDC crosswalk | Search, view, add, edit | UG p.75–102 |
| Cycle | Search, add, edit | UG p.153–155 |

### 2.3.2 Fee Schedule Release Status

```mermaid
stateDiagram-v2
  [*] --> Pending: Add / Copy header
  Pending --> Test
  Pending --> Release
  Test --> Release
  Test --> Pending
  Pending --> Delete
  Test --> Delete
  Release --> Delete
```

| Status | Meaning |
|---|---|
| Pending | Being built; fields can be changed (Edit Fields) |
| Test | Available for testing |
| Release | Available for processing; saving in Release shows "no further editing is allowed" (UG p.142) |
| Delete | Withdrawn |

The transitions drawn are those implied by the guides; the exact allowed transitions and whether lines can be edited in Release are **Open (Q-31)** (UG p.140 vs p.142).

### 2.3.3 Copy and Insert

| Operation | Behaviour | Rule |
|---|---|---|
| Copy | Creates a new record from an existing one; the Change Request ID is not copied and must be entered | BR-012 |
| Insert New | Adds a row that end-dates the existing open-ended row to the day before the new row's Effective Date | BR-011 |

## 2.4 Time-Based Behaviour

> **Status:** N/A — legacy has no date-driven status change. Records are effective-dated and consumers select them by date of service (FN p.8, p.10). The v6 daily transition job is not adopted (M-08).

## 2.5 Rules Engine Integration

> **Status:** N/A, pending confirmation — legacy configures an InRule application name (`InRule.ApplicationId`, CRG p.88) but documents no rule evaluation in Plan Management. The ARB names only CM-PE and CMS-PM as InRule users. The target makes no InRule call (M-10). **Open (Q-16):** confirm that no Plan Management operation evaluates rules.

---

# PART II — TECHNICAL

# 3. Architecture Overview

> **Status:** Complete · **Sources:** ARB, ADRs, §16 decisions · **Feeds:** solution design, C4 diagrams, ARB review

## 3.1 Architecture Classification and Patterns

| Concern | Choice | Source |
|---|---|---|
| Style | CRUD; no CQRS, no read models, no projectors | ADR-041, DD-04 |
| Tenancy | Database per tenant: schema `plan` in the state's operational database `pp_{tenant}`, shared by all modules | ADR-012, ARB §4.1 (`pp_t1`, `pp_t2`, …) |
| National reference data | `db_shared.plan`, written only by loader Glue jobs; state edits in tenant `*_state` tables | ADR-020, DD-07 |
| Business workflow | Legacy maintenance operations (add, edit, copy, insert, invalidate, Release Status); no in-system approval | DD-06 |
| Entry point | Amazon API Gateway, native JWT authorizer, regional WAF | ADR-008, ADR-031 |
| Cross-domain communication | Events only, through the Event Adapter; synchronous calls only to CM-CORE shared services | ADR-002, ARB §3.1 rules 1–2 |
| Reliable publishing | Transactional outbox + Outbox Relay | DD-09 (no ADR; outbox is an ARB gap) |
| External systems | Never call Plan Management; receive data outbound through CMS-INX | ARB §3.1 rule 4, DD-08 |

Every API operation, read or write, uses the same tables in the same database. Every state change writes an outbox row in the same transaction; the Outbox Relay publishes it after commit.

## 3.2 System Context (C1)

```mermaid
flowchart TB
  Staff["State Plan Management staff<br/>(rate analysts, managers)"]
  Ops["Operations / Support"]

  PL["<b>Plan Management (CM-PL)</b><br/>Code sets, pharmacy data, groupings, related data,<br/>provider and member rates, fee schedules, cycles"]

  IdP["IRM broker (OIDC identity broker)<br/>JWT with tenant_id, sub, roles"]
  Tenant["Tenant Registry (CM-CORE)<br/>tenant config, DB routing, feature flags"]
  CfgMgmt["Configuration Management<br/>(DataLists, maintenance levels)"]
  PM["Provider Management (CMS-PM)<br/>provider and service location"]
  Files["CMS / FDB / Noridian files<br/>rate, fee schedule, grouping, EOB files"]
  INX["CMS-INX<br/>(External Integration Adapter)"]
  Client["Client system of record<br/>(maintenance level 80 data)"]
  Consumers["Consuming modules<br/>(Claims, Provider, Member, TPL, Authorization,<br/>Managed Care, Drug Rebate, data warehouse)"]
  CW["Amazon CloudWatch"]

  Staff -->|"Maintain reference data, rates,<br/>fee schedules (browser)"| PL
  Ops -->|"Dashboards, DLQ redrive"| CW
  PL -->|"Sign-in, JWT"| IdP
  PL -->|"Resolve tenant DB and flags"| Tenant
  CfgMgmt -.->|"DataList values (Q-32)"| PL
  PM -->|"provider.* events"| PL
  Files -->|"S3 imports"| PL
  Client -->|"Files"| INX
  INX -->|"integration.plan.*.changed.v1"| PL
  PL -->|"plan.* events"| Consumers
  PL -->|"plan.* events"| INX
  PL -->|"OpenTelemetry"| CW
```

| External actor / system | Interaction with Plan Management | Mechanism |
|---|---|---|
| State staff | Use `mfe-plan-management` | Browser → API Gateway → BFF |
| IRM broker | Brokers sign-in to the state IdP or Gainwell IdP (Microsoft Entra ID); issues the JWT | OIDC, FAPI 2.0 (ADR-014) |
| Tenant Registry | Resolves tenant database, schema version and feature flags | Synchronous API (CM-CORE, allowed by ARB rule 2) |
| Configuration Management | Owns DataLists and maintenance levels | Mechanism for service-side validation open (Q-32) |
| Provider Management | Publishes provider and location events; never called synchronously | Event Backbone |
| CMS / FDB / Noridian and rate files | Staged in S3 and loaded by batch imports | S3 + MWAA + Glue |
| CMS-INX | Delivers client-sourced (level 80) data as events; delivers `plan.*` events outbound | Event Backbone |
| Consuming modules | Receive `pp.plan.events` | Event Backbone (consumers to inventory, Q-18) |
| CloudWatch | Receives all telemetry; raises alarms | OpenTelemetry (ADR-016) |

## 3.3 Containers and Components (C2)

```mermaid
flowchart LR
  subgraph Clients
    Browser["Browser"]
  end

  subgraph Edge["Edge (AWS)"]
    CF["CloudFront + S3<br/>Next.js shell + mfe-plan-management"]
    APIGW["Amazon API Gateway<br/>native JWT authorizer · regional WAF"]
    ALB["Internal ALB (VPC Link)"]
  end

  subgraph EKS["Amazon EKS Auto Mode (shared cluster)"]
    BFF["NestJS 10 BFF<br/>(shared, Plan Management module)"]
    subgraph NS["plan-mgmt namespace"]
      CIS["Code Information Service<br/>/v1/code-information, /v1/ndc"]
      GS["Grouping Service<br/>/v1/grouping"]
      RSS["Rate Setting Service<br/>/v1/rate-setting, /v1/fee-schedule"]
      RIS["Related Information Service<br/>/v1/related-information, /v1/cycle-schedule"]
      Relay["Outbox Relay<br/>(hosted in each API host)"]
      Cons["Event consumers<br/>(hosted in Rate Setting and Code Information hosts)"]
    end
  end

  subgraph Data["Data"]
    TDB[("Aurora PostgreSQL<br/>pp_{tenant} · schema plan")]
    SDB[("Aurora PostgreSQL<br/>db_shared · schema plan")]
    Redis[("ElastiCache Redis<br/>BFF cache · idempotency keys")]
    Archive[("pp_{tenant} · plan_audit_archive")]
  end

  subgraph Messaging["Event Backbone"]
    EA["Event Adapter<br/>pp.plan.events · pp.provider.events ·<br/>pp.integration.events · plan.dlq.v1"]
  end

  subgraph Batch["Batch"]
    S3["S3 staging"]
    MWAA["Airflow (MWAA)"]
    Glue["Glue Spark (Python 3.12)"]
  end

  subgraph Shared["CM-CORE and shared"]
    IdP["IRM broker"]
    TR["Tenant Registry"]
    CW["CloudWatch"]
  end

  INX["CMS-INX"]

  Browser --> CF
  Browser -->|"/api/plan-management/**"| APIGW
  APIGW -->|"VPC Link"| ALB --> BFF
  APIGW -->|"JWKS"| IdP
  BFF -->|"SigV4 + JWT"| CIS & GS & RSS & RIS
  BFF --> Redis
  CIS & GS & RSS & RIS --> TDB
  CIS -->|"read-only"| SDB
  RSS -->|"audit history"| Archive
  CIS & GS & RSS & RIS --> TR
  TDB --> Relay --> EA
  EA -->|"provider.*"| Cons
  EA -->|"integration.plan.*"| Cons
  Cons --> TDB
  EA -->|"plan.*"| INX
  INX -->|"integration.plan.*"| EA
  BFF -->|"pre-signed upload"| S3
  S3 --> MWAA --> Glue
  Glue --> TDB
  Glue --> SDB
  BFF & CIS & GS & RSS & RIS & Glue --> CW
```

| Container | Technology | Responsibility |
|---|---|---|
| Shell + `mfe-plan-management` | Next.js 15, React 19, Module Federation, S3 + CloudFront | Plan Management screens |
| BFF (shared) | NestJS 10 (DV-01) | Token validation, aggregation, view models, import initiation, exports, errors |
| Code Information Service | .NET 10, Npgsql | Code sets and restrictions, NDC and panels, labelers, GSN, HCPCS–NDC crosswalk; consumes client-sourced events |
| Grouping Service | .NET 10, Npgsql | Groupings |
| Rate Setting Service | .NET 10, Npgsql | Seven provider-specific rate types, member-specific rates, fee schedules, provider and member reference copies, publication status; consumes provider events |
| Related Information Service | .NET 10, Npgsql | EOB, EEC, EIC, MUE, NCCI, formatted content, cycles |
| Outbox Relay | Hosted background service in each API host | Publishes outbox rows after commit |
| Event consumers | Hosted background services (DD-05) | `provider.*` → Rate Setting; `integration.plan.*` → Code Information |
| Tenant database | Aurora PostgreSQL `pp_{tenant}`, schema `plan` | All Plan Management tenant data, outbox, audit |
| Shared database | Aurora PostgreSQL `db_shared`, schema `plan` | National base data; read-only to services |
| Redis | Amazon ElastiCache | BFF response cache, idempotency keys, `shared:` code cache |
| Batch | S3, MWAA, Glue Spark | File imports and migration loads |

> The v7 C2 placed the client-sourced event consumer in the Rate Setting host while §8.1 assigned it to the Code Information Service. v8 places each consumer in the service that owns the data it writes.

## 3.4 Technology Stack

| Layer | Technology | Source |
|---|---|---|
| Frontend | Next.js 15.5, React 19.2, TypeScript 5.6, Module Federation (`@module-federation/nextjs-mf` 8.8), `@mms/ui-kit`, Tailwind CSS 3.4, TanStack Query 5, React Hook Form 7 + Zod 3, OpenTelemetry JS, Jest, Playwright | ADR-011, ADR-032 |
| BFF | NestJS 10.4, TypeScript 5.6, `@nestjs/swagger`, class-validator, jose, AWS SDK v3 + `aws4` (SigV4), Redis 4.7 client, OpenTelemetry Node SDK, Jest + Supertest | DD-01 (DV-01) |
| Domain APIs | .NET 10, ASP.NET Core Web API, Swashbuckle, Npgsql with Repository Pattern; `Nullable`, `ImplicitUsings`, `TreatWarningsAsErrors`, analyzers `latest-recommended` | ADR-004 |
| Shared libraries | `hpp_tenant_context`, `hpp_auth`, `hpp_db` (ConnectionRouter), `hpp_observability`, `hpp_feature_flags_client`, `hpp_contracts`, `hpp_tenant_registry_client`; Event Adapter client and resilience library names to confirm (Q-10) | ADR-025 |
| Schema migrations | Alembic, per tenant database | ADR-007 |
| Database | Amazon Aurora PostgreSQL Multi-AZ | ADR-012 |
| Messaging | Event Backbone through the Event Adapter (transport is configuration: SNS/SQS or MSK) | ADR-002 |
| Schema registry | AWS Glue Schema Registry | ADR-002a |
| Batch | AWS Glue Spark (Python 3.12), Amazon MWAA, Amazon S3 | ADR-010 |
| Runtime | Amazon EKS Auto Mode (`plan-mgmt` namespace), KEDA; internal ALB behind API Gateway VPC Link | ADR-004, DD-05 |
| Identity | IRM broker; FAPI 2.0 (Authorization Code + PKCE + PAR); JWT with `tenant_id`, `sub`, `roles` | ADR-014 |
| Edge | Amazon API Gateway (native JWT authorizer), regional AWS WAF (OWASP CRS) | ADR-008, ADR-031 |
| Observability | OpenTelemetry → Amazon CloudWatch | ADR-016 |
| Delivery | GitHub Actions, Terraform, Docker + ECR, Helm, Argo CD, Argo Rollouts, JFrog Artifactory | ADR-015 (DV-03 for EKS release tooling) |

## 3.5 End-to-End Request Flow

```mermaid
sequenceDiagram
  autonumber
  participant U as Browser (mfe-plan-management)
  participant G as API Gateway (JWT authorizer, WAF)
  participant B as BFF (Plan Management module)
  participant S as Rate Setting Service
  participant T as Tenant Registry
  participant D as pp_{tenant}.plan
  participant R as Outbox Relay
  participant E as Event Adapter

  U->>G: POST /api/plan-management/rate-setting/provider-ucc (Bearer JWT)
  G->>G: Validate JWT, require tenant_id, throttle
  G->>B: Forward (VPC Link)
  B->>S: POST /v1/rate-setting/provider-ucc (SigV4 + JWT, X-Idempotency-Key)
  S->>T: Resolve tenant database (cached)
  S->>S: Validate BR-001..BR-012
  S->>D: One transaction: rate row, pm_version_history row, pm_outbox_event row
  S-->>B: 201 Created (saved record)
  B-->>U: View model
  R->>D: Claim unpublished rows (FOR UPDATE SKIP LOCKED)
  R->>E: Publish plan.rate_setting.updated.v1
  R->>D: Mark published (pm_publication_status)
```

# 4. Frontend

> **Status:** Partial — navigation map pending · **Sources:** ADR-011, ADR-032, UG · **Feeds:** micro frontend screens, Playwright tests

## 4.1 Architecture Overview

Plan Management screens are the Module Federation remote **`mfe-plan-management`**, loaded at runtime by the shared Next.js shell alongside `mfe-enrollment`, `mfe-credentialing` and `mfe-admin`. One build serves all tenants; each state can run a different UI version (ARB §4.6, ADR-011).

## 4.2 Technology Stack

TanStack Query for server state; React Hook Form + Zod for forms; `@mms/ui-kit` components; Tailwind CSS (§3.4).

## 4.3 Screen Inventory

Details per screen are in Appendix H.

| Screen group | Disposition | Backing contract |
|---|---|---|
| Code Sets (HCPCS, Dental, Revenue, DRG, ICD-9/10 diagnosis and procedure) | Preserve | Appendix B.3 |
| Pharmacy Related Data (NDC and panels, labeler codes, GSN) | Preserve | Appendix B.2, B.3 |
| Groupings | Preserve | Appendix B.4 |
| Related Data (NCCI, MUE, EOB, EEC, EIC, HCPCS–NDC crosswalk) | Preserve | Appendix B.3, B.7 |
| Provider Specific Rates (seven types) and audit | Preserve | Appendix B.6 |
| Member Specific Rates | Preserve | Appendix B.6 |
| Fee Schedules | Preserve | Appendix B.5 |
| File Upload | Change (S3 + import jobs) | Appendix B, I |
| Manage Cycles | Preserve | Appendix B.8 |
| Publication & Integration Status | New (platform) | Appendix B.9 |

Dropdown values come from DataLists owned by Configuration Management; they are never hard-coded.

## 4.4 Navigation and Shell Integration

The remote exposes `./App`, mounted by the shell under `/plan-management/[[...slug]]` behind `RequireAuth`; sub-routes are internal to the remote. Remotes never import each other; cross-remote interaction uses the shell event bus.

## 4.5 Tenant Customization

Per-tenant behaviour is resolved at runtime from the tenant manifest and feature flags (`hpp_feature_flags_client`); tenant-specific fields and validators load as code-split chunks. No code branches on tenant identity (ADR-018 principle).

## 4.6 API Communication

- The remote calls **only** the BFF (`/api/plan-management/**`) through API Gateway; never a domain API.
- Errors are RFC 7807 ProblemDetails: `400` shows field errors from `errors`; `409` (`https://errors.gainwell.com/conflict/concurrency`) shows "this record changed — reload".

## 4.7 Hosting, Security, Observability and Accessibility

| Concern | Standard | Source |
|---|---|---|
| Hosting | Static export to S3 + CloudFront; content-hashed `remoteEntry.js`; redeploying the remote does not rebuild the shell | ADR-011 |
| Browser security | CSP, HSTS, X-Frame-Options, Referrer-Policy, SRI | ADR-031 |
| Accessibility | WCAG 2.2 AA and Section 508; axe-core and Lighthouse CI on every PR; failures block merge | ADR-032 |
| Telemetry | OpenTelemetry JS with `tenant_id` and correlation id | ADR-016 |

# 5. BFF (Backend for Frontend)

> **Status:** Partial — composed endpoint schemas pending · **Sources:** ADR-008, ADR-011, ADR-014, DD-01 · **Feeds:** BFF module code, Appendix C

## 5.1 Purpose and Responsibilities

Plan Management adds a **Plan Management module** to the shared BFF; there is no separate Plan Management BFF. The BFF has no database access (ADR-011). Next.js API Routes and Server Actions are not used as a BFF.

| # | Responsibility | What the Plan Management module does |
|---|---|---|
| 1 | Authentication and authorization | Re-validates the JWT (jose, IRM broker JWKS); propagates `sub`, `roles`, `tenant_id`; checks scopes (Appendix G) before forwarding |
| 2 | Aggregation | Combines responses from several Plan Management services into one screen response |
| 3 | View models | Shapes Appendix B responses into screen view models |
| 4 | Orchestration | Multi-step screens (upload → import → status); business rules stay in domain services |
| 5 | Imports and exports | Pre-signed S3 upload URLs, import start and status, exports (Appendix C) |
| 6 | Error handling | RFC 7807 ProblemDetails; correlation id on every request and response |

## 5.2 Routes

| BFF route | Methods | Forwards to |
|---|---|---|
| `/api/plan-management/code-information/**` | GET, POST | Code Information `/v1/code-information` |
| `/api/plan-management/ndc/**` | GET, POST | Code Information `/v1/ndc` |
| `/api/plan-management/grouping/**` | GET, POST, PATCH | Grouping `/v1/grouping` |
| `/api/plan-management/fee-schedule/**` | GET, POST, PATCH | Rate Setting `/v1/fee-schedule` |
| `/api/plan-management/rate-setting/**` | GET, POST, PATCH | Rate Setting `/v1/rate-setting` |
| `/api/plan-management/related-information/**` | GET, POST | Related Information `/v1/related-information` |
| `/api/plan-management/cycle-schedule/**` | GET, POST, PATCH | Related Information `/v1/cycle-schedule` |
| `/api/plan-management/imports/**` | GET, POST | Import endpoints of the owning service |

Tenant configuration, DataList lookups and health endpoints are existing shared BFF endpoints.

## 5.3 Composed Endpoints

| Endpoint | Purpose | Calls | Appendix |
|---|---|---|---|
| `POST /api/plan-management/imports/upload-url` | Pre-signed S3 URL for an upload | S3 | C.2.1 |
| `POST /api/plan-management/imports` | Start an import; returns `importId` | Owning service import endpoint | C.2.2 |
| `GET /api/plan-management/imports/{importId}` | Status, statistics and error-file link | `/v1/{area}/imports/{importId}`, S3 | C.2.3 |
| `POST /api/plan-management/exports` | Excel, PDF or upload-template export; grouping PDF report | Owning service search endpoint | C.2.4 |
| `GET /api/plan-management/lookups/{datalist}` | Cached DataList values | Configuration Management (Q-32) | C.2.5 |

## 5.4 Session and Token Model

| Step | Behaviour | Source |
|---|---|---|
| Sign-in | Authorization Code + PKCE + PAR against IRM broker, which federates to the state IdP or Gainwell IdP | ADR-014 |
| Token | JWT with `tenant_id`, `sub`, `roles`; sent as `Authorization: Bearer` on every call | ADR-014, DD-02 |
| Edge validation | API Gateway native JWT authorizer validates signature, issuer, audience, expiry and requires `tenant_id` | ADR-008 |
| BFF | Re-validates the JWT and checks scopes; forwards the same JWT to domain services with SigV4 | ADR-009 |
| Services | Validate the JWT again (`hpp_auth`); tenant and user come only from the JWT | ADR-025 |
| Cookies and CSRF | Not used: no server-side session, so no CSRF guard (Q-02 closed) | ADR-008 |

## 5.5 Contract Governance

- Every domain API has an OpenAPI 3.0 document in `api-specification/` (Appendix B), approved by the SA before code generation (ADR-033).
- The BFF uses TypeScript clients generated from those documents.
- CI runs an OpenAPI diff on every pull request; a breaking change fails the build unless the path version changes (`/v1/` → `/v2/`). Consumer-driven contract tests run in addition (ADR-015).

## 5.6 Technology and Resilience

Pipeline: CorrelationIdMiddleware → JwtAuthGuard (tenant from JWT) → ScopeGuard → controller → ProblemDetailsExceptionFilter. Resilience per downstream client: retry with exponential backoff and jitter (3 attempts, idempotent calls only), circuit breaker, 5 s timeout, rate limiting. Redis response cache with tenant-prefixed keys and 300 s TTL for code lookups and DataLists.

# 6. Domain Services

> **Status:** Partial — Q-32 open · **Sources:** §2, legacy WCF services, ADR-022 · **Feeds:** service scaffolding, controllers, repositories

## 6.1 Service Pattern and Boundaries

Every service is a .NET 10 ASP.NET Core Web API on EKS (`plan-mgmt` namespace) with Npgsql repositories against the tenant database, transactional outbox, Event Adapter and OpenTelemetry. A service owns its tables; no service reads another service's tables directly.

## 6.2 Service Catalog

| Service | Base routes | Owns (tables, Appendix D) | Publishes | Consumes |
|---|---|---|---|---|
| Code Information | `/v1/code-information`, `/v1/ndc` | `pm_code_state`, `pm_code_restriction`, `pm_hcpcs_ndc_association_state`, `pm_vos_tag`, `pm_ndc_state`, `pm_ndc_package`, `pm_ndc_rate`, `pm_ndc_rebate`, `pm_manufacturer_state`, `pm_drug_classification_state`, `pm_labeler_state`, `pm_labeler_rebate_program`, `pm_ndc_status_state`; reads `db_shared` | `plan.code_information.updated.v1`, `clinical_code.restriction.changed.v1`, `plan.ndc.reference.updated.v1`, `plan.ndc.rate.updated.v1`, `drug_code.updated.v1` | `integration.plan.*.changed.v1` |
| Grouping | `/v1/grouping` | `pm_grouping`, `pm_grouping_item` | `plan.grouping.updated.v1` | — |
| Rate Setting | `/v1/rate-setting`, `/v1/fee-schedule` | `pm_provider`, `pm_provider_service_location`, `pm_member`, `pm_provider_specific_rate`, `pm_provider_ucc_rate`, `pm_provider_drg_rate`, `pm_provider_drg_custom`, `pm_member_rate`, `pm_fee_schedule*`, `pm_file_loader_history`, `pm_publication_status` | `plan.rate_setting.updated.v1`, `plan.member_rate.updated.v1`, `plan.fee_schedule.updated.v1`, `fee_schedule.published.v1` | `provider.registered.v1`, `provider.updated.v1`, `provider.terminated.v1` |
| Related Information | `/v1/related-information`, `/v1/cycle-schedule` | `pm_exception_*`, `pm_explanation_of_benefit*`, `pm_edit_rule`, `pm_formatted_content`, `pm_cycle_schedule` | `plan.related_information.updated.v1`, `plan.cycle_schedule.updated.v1` | — |
| Batch imports (Glue) | — | `pm_import_job` | `plan.import.completed.v1`, `plan.import.failed.v1` | — |

Every service writes its own rows to `pm_version_history` and `pm_outbox_event`.

## 6.3 Legacy API Surface Mapping

| Legacy surface | Target | Disposition |
|---|---|---|
| `UX.Services` Web API 2 controllers, `UX.Providers` WCF proxies | BFF Plan Management module | Change |
| `CodeInformationService`, `CodeInformationQueryService`, `ExternalCodeQueryService`, `DiagnosisQueryService` (WCF) | `/v1/code-information` | Change |
| `NDCInformationService`, `NDCInformationQueryService`, `NDCQueryService`, `NationalDrugCodeQueryService` (WCF); `api/NationalDrugCodeQuery/*` (Web API 2) | `/v1/ndc` | Change |
| `GroupingService`, `GroupingQueryService` (WCF) | `/v1/grouping` | Change |
| `FeeScheduleService`, `FeeScheduleQueryService` (WCF) | `/v1/fee-schedule` | Change |
| `RateSettingService`, `RateSettingQueryService`, `RateSettingReportService` (WCF) | `/v1/rate-setting` | Change |
| `RateSettingFileUploadService` (WCF) | S3 upload + import job (`/v1/rate-setting/attachments/add`, file loader history endpoints) | Change |
| `RelatedInformationService`, `RelatedInformationQueryService` (WCF) | `/v1/related-information` | Change |
| `CycleScheduleService`, `CycleScheduleQueryService` (WCF) | `/v1/cycle-schedule` | Change |
| `Batch*Service` (WCF bulk uploads) | Import endpoints + Glue jobs (§11, Appendix I) | Change |
| `*EventService` (`IEventDistribution`) change distribution | Events through the Event Adapter (§7) | Change |
| `Get*Events`, `Get*AggregateDelta` queries | Audit history queries (`/events`, `/aggregate-delta`, Appendix B), served from `pm_version_history` and the legacy archive | Preserve |
| `PlanReferenceController` OData (`/odata`), `PlanManagementCacheRefresh` | Internal consumers use `/v1` REST through the BFF or events; caches refresh from events | Retire |

### 6.3.1 Maintenance and Platform Endpoints

| Method | Path | Purpose | Legacy operation |
|---|---|---|---|
| POST | `/v1/rate-setting/provider-ucc` | Add a UCC rate | Add Usual and Customary Charges |
| POST | `/v1/rate-setting/provider-drg` | Add a DRG rate with custom DRG values | Add DRG Rate |
| POST | `/v1/rate-setting/provider-specific` | Add a Nursing Facility, Encounter, Dispensing Fee, Inpatient or Outpatient rate | Add rate (per type) |
| POST | `/v1/rate-setting/member-specific` | Add a member-specific rate | Add Member Specific Rate |
| POST | `/v1/rate-setting/member-specific/search` | Search member-specific rates | Search Member Specific Rates |
| GET, PATCH | `/v1/rate-setting/{rateFamily}/{id}` | Read or edit a rate (BR-013) | View, Edit |
| POST | `/v1/rate-setting/{rateFamily}/{id}:copy` | Copy; Change Request ID required (BR-012) | Copy |
| POST | `/v1/rate-setting/{rateFamily}/{id}:invalidate` | Invalidate (BR-014) | Edit with Valid unchecked |
| POST | `/v1/rate-setting/{rateFamily}/{id}:insert` | Insert a new rate that end-dates the current one (BR-011) | Insert New |
| GET | `/v1/rate-setting/{rateFamily}/{id}/audit` | Audit history | Provider Specific Audit |
| GET | `/v1/rate-setting/publication-status?aggregateId=` | Publication status per change | — (platform, M-26) |
| POST | `/v1/rate-setting/publication-status/{eventId}:retry` | Retry a failed publication | — (platform, M-26) |
| GET | `/v1/{area}/imports/{importId}` | Import job status | File Upload status |

`{rateFamily}` ∈ `provider-ucc`, `provider-drg`, `provider-specific`, `member-specific`.

## 6.4 API Design Standards

| Standard | Rule |
|---|---|
| Versioning | URI versioning `/v1/...`; contract-first OpenAPI 3.0 |
| Identity | `Authorization: Bearer <JWT>` on every call; tenant and user come only from the JWT; `tenantId`, `TenantId` and `Requestor` body fields are ignored |
| Correlation | `X-Correlation-Id` optional inbound, always returned |
| Idempotency | `X-Idempotency-Key` required on every state-changing endpoint; duplicates within 24 h return the original result (Redis) |
| Errors | `application/problem+json` (RFC 7807); validation errors in `errors: { "<field>": ["..."] }` |
| Concurrency | Every maintained record carries `versionNumber`; a stale value returns `409` (`https://errors.gainwell.com/conflict/concurrency`). Legacy tracked change by event-store commit id; this is a deliberate change (M-24) |
| Actions | Maintenance actions other than create and edit are `POST .../{id}:<action>` (`copy`, `insert`, `invalidate`, `validate`) with body `{ "versionNumber": n, "changeRequestCode": "..." }` |
| Validation order | Request validation runs before business logic |
| Search | Paged; sortable and filterable fields map to an allow-list of columns |

## 6.5 Synchronous Communication

| From | To | Purpose | Allowed by | Timeout / retry | Failure behaviour |
|---|---|---|---|---|---|
| BFF | Plan Management services | All UI operations | ARB §3.1 rule 3 | 5 s; 3 retries for idempotent calls | ProblemDetails `502`/`503`/`504` |
| Services | Tenant Registry API (CM-CORE) | Tenant database routing, feature flags | ARB §3.1 rule 2 | Redis-cached (5 min TTL, ADR-007); circuit breaker | Fail closed (`503`) |
| Services | Configuration Management (DataList values and maintenance levels, BR-006, BR-019) | Validate DataList values on write | **Open (Q-32)** — Configuration Management is not part of CM-CORE, so a synchronous call conflicts with ARB §3.1 rule 1 | — | — |
| Services | Other domains (CMS-PM, CM-PE, Member) | — | Not allowed (ADR-002) | — | — |
| Services | InRule | — | Not used (§2.5) | — | — |

## 6.6 Persistence Pattern and Transactions

- Each service has Npgsql repositories with explicit, parameterized SQL; one unit of work owns one connection and transaction per write request.
- The business rows, the `pm_version_history` row and the `pm_outbox_event` row are written in the same transaction.

## 6.7 Resiliency

| Pattern | Implementation |
|---|---|
| Transactional outbox | Business rows and `pm_outbox_event` in one Npgsql transaction |
| Idempotency | `X-Idempotency-Key` (Redis, 24 h); imports keyed by `importId`; consumers idempotent on `event_id` |
| Optimistic concurrency | `version_number` check; `409` on mismatch |
| Retry and circuit breaker | BFF → services; services → Tenant Registry |
| Fail closed | Provider, location or member missing from the reference copy (BR-001, BR-004); Tenant Registry unavailable |
| Dead letter | Every consumer has a DLQ (§7.6); alarm on depth > 0 (ADR-037) |
| Health checks | `/health/live`, `/health/ready` |

# 7. Eventing

> **Status:** Partial — AsyncAPI files pending; Q-07, Q-27 open · **Sources:** ADR-002, ADR-002a, ADR-037, SPG · **Feeds:** AsyncAPI, outbox relay, consumers

## 7.1 Event Backbone Strategy

All cross-domain integration uses the Event Backbone through the Event Adapter (ADR-002). The transport (SNS/SQS or MSK) is environment configuration; domain code is identical on both.

```
Business transaction → pm_{table} + pm_version_history + pm_outbox_event (one commit)
  → Outbox Relay → Event Adapter → pp.plan.events → consumer queues / groups (+ DLQ)
```

## 7.2 Event Rules

| Rule | Source |
|---|---|
| Envelope on every event: `tenant_id`, `event_name`, `event_version`, `event_id`, `occurred_at`, `correlation_id`, `trace_id`, `producer`, plus `payload` and `metadata` (Appendix E.1) | ADR-002 |
| `tenant_id` comes from the JWT or the originating event, never from the payload; topics are environment-scoped, not tenant-scoped | ADR-002 |
| Event names follow `<domain>.<stream>.<action>.<version>`; topics follow `pp.<domain>.<stream>` | ADR-002 |
| Payloads carry identifiers and changed business fields only; no PII | ADR-016 |
| Consumers are idempotent on `event_id` and re-validate `tenant_id` | ARB §4.1 |
| Outbox Relays claim rows with `SELECT … FOR UPDATE SKIP LOCKED`; any relay may publish any row, including rows written by Glue jobs, and no row is published twice concurrently | DD-09 |
| Legacy in-process event chaining is replaced by published events consumed by the owning domain | ADR-002 |
| Topic retention 90 days; DLQ `plan.dlq.v1` with alarm | ADR-037 |

## 7.3 Published Events

Catalog in Appendix E.2. The ARB names a single `plan.updated.v1` (Figure 11); it is delivered as the specific events below, and no event with that name is published.

| Consumer need | Subscribe to |
|---|---|
| Rates | `plan.rate_setting.updated.v1`, `plan.member_rate.updated.v1`, `fee_schedule.published.v1`, `plan.fee_schedule.updated.v1` |
| Reference data | `plan.code_information.*`, `clinical_code.restriction.changed.v1`, `plan.ndc.*`, `drug_code.updated.v1`, `plan.grouping.*`, `plan.related_information.*`, `plan.cycle_schedule.*` |
| Import outcomes | `plan.import.completed.v1`, `plan.import.failed.v1` |

## 7.4 Consumed Events

| Event | Producer | Consumer service | Action | Status |
|---|---|---|---|---|
| `provider.registered.v1`, `provider.updated.v1`, `provider.terminated.v1` | CMS-PM | Rate Setting | Upsert `pm_provider`, `pm_provider_service_location` | AS-03, Q-07 |
| `integration.plan.*.changed.v1` (9 event types, §8.1) | CMS-INX | Code Information | Upsert state reference tables (level 80) | AS-15, Q-27 |
| Member reference events | Member module | Rate Setting | Upsert `pm_member` | Q-11 |

## 7.5 Producer–Consumer Matrix

| Producer | Topic | Event family | Known consumers |
|---|---|---|---|
| CM-PL (all services) | `pp.plan.events` | `plan.*`, `clinical_code.*`, `drug_code.*`, `fee_schedule.*` | Claims, Provider, Member, TPL, Authorization, Managed Care, Drug Rebate, data warehouse, CMS-INX (legacy consumers, UG p.1, FN p.7); confirmation pending (Q-18) |
| CMS-PM | `pp.provider.events` | `provider.*` | CM-PL Rate Setting |
| CMS-INX | `pp.integration.events` | `integration.plan.*` | CM-PL Code Information |

## 7.6 Topics and Channels

| Concern | SNS/SQS | MSK (Kafka) |
|---|---|---|
| Plan topic | SNS `pp-plan-events` (logical `pp.plan.events`) | `pp.plan.events` |
| Provider topic consumed | SQS queue on `pp-provider-events` | Consumer group on `pp.provider.events` |
| Integration topic consumed | SQS queue on `pp-integration-events` | Consumer group on `pp.integration.events` |
| Ordering | Not guaranteed; consumers idempotent and version-checked | Partition key `tenant_id` + `aggregate_id` |
| Dead letter | SQS DLQ after 3 receives; redrive | `plan.dlq.v1`; replay |
| KEDA scaling signal | Queue depth | Consumer lag |

## 7.7 Delivery Guarantees

At-least-once. Business rows and outbox rows commit together; the Outbox Relay publishes after commit, sets `published_at` and updates `pm_publication_status`. Failed publications are retried and stay visible as `Failed` until published or retried by a user (BR-025). Consumers deduplicate on `event_id`.

## 7.8 Schema Governance

| Concern | Rule | Source |
|---|---|---|
| Registry | Every event schema is registered in AWS Glue Schema Registry, accessed through the Event Adapter | ADR-002a |
| Contract file | One AsyncAPI document per producing service in `api-specification/<service>/` | ADR-033 |
| Compatibility | Backward-compatible changes keep the version; a breaking change publishes `.v2` alongside `.v1` until consumers move | ADR-002 |
| Testing | Consumer-driven contract tests for every inter-domain event in CI | ADR-015 |
| Consumed schemas | Taken from the producer's registered schema; `integration.plan.*` payloads pending the legacy File to Event templates (Q-27) | — |

# 8. External Interactions and Shared Services

> **Status:** Partial — Q-12, Q-18, Q-27 open · **Sources:** SPG, UG, FN, ADR-003, ADR-019 · **Feeds:** integration contracts (Appendix F), AsyncAPI

## 8.1 Inventory

**Inbound client-sourced reference data** (legacy "File to Event", SPG p.113–137). A client system of record sends a file; the integration layer validates it and publishes one event per record. Applies only to data at maintenance level 80. In the target, CMS-INX publishes the events and the Code Information Service consumes them.

| Legacy job | Target event | Plan Management target |
|---|---|---|
| HCPCSCodeChanged, DentalCodeChanged | `integration.plan.code.changed.v1` | `pm_code_state` |
| ICD10DiagnosisCodeChanged, ICD10ProcedureCodeChanged | `integration.plan.code.changed.v1` | `pm_code_state`, `pm_code_restriction` |
| NationalDrugCodeChanged | `integration.plan.ndc.changed.v1` | `pm_ndc_state` |
| NDCRateChanged | `integration.plan.ndc_rate.changed.v1` | `pm_ndc_rate` |
| NDCRebateChanged | `integration.plan.ndc_rebate.changed.v1` | `pm_ndc_rebate` |
| NationalDrugCodeCODStatusChanged | `integration.plan.ndc_status.changed.v1` | `pm_ndc_status_state` |
| HCPCSNDCASSCNChanged | `integration.plan.hcpcs_ndc.changed.v1` | `pm_hcpcs_ndc_association_state` |
| ManufacturerChanged | `integration.plan.manufacturer.changed.v1` | `pm_manufacturer_state` |
| DrugClassificationChanged (GSN) | `integration.plan.drug_classification.changed.v1` | `pm_drug_classification_state` |
| DataListItemChanged | Not consumed by Plan Management | Configuration Management |

**Consumers of Plan Management data** (UG p.1, FN p.7, p.20): Claims, Provider, Member, TPL, Authorization Determination, Managed Care, Drug Rebate (labeler and invoice type data), the data warehouse, and CMS (NCCI/MUE reports). External consumers beyond Provider Plus are not yet inventoried (Q-18).

## 8.2 Interface Specifications

One row per interface in Appendix F.

## 8.3 Inbound Access

Plan Management receives no calls from external systems. Inbound data arrives as files (S3 imports) or as events from CMS-INX and CMS-PM.

## 8.4 Shared Platform Service Usage

| Service | Used | Purpose |
|---|---|---|
| IRM broker | Yes | Identity (ADR-014) |
| Tenant Registry | Yes | Database routing, feature flags (ADR-007) |
| Event Adapter / Backbone | Yes | All cross-domain events (ADR-002) |
| Reporting Service (CM-CORE) | To confirm | On-demand Excel/CSV exports (ADR-019); v8 keeps exports in the BFF until confirmed (DV-05) |
| InRule | No | §2.5 |
| AddressValidation, Correspondence, Screening | No | Not needed by Plan Management |

## 8.5 Reports and Outbound Files

| Output | Legacy source | Target | Source |
|---|---|---|---|
| Loader statistics and error files | SPG p.107 | `pm_import_job` + S3 error files (Appendix I.4) | ADR-010 |
| Screen exports (Excel, PDF, upload template) | UG p.3 | BFF export endpoint (C.2.4); ADR-019 Reporting Service to confirm (DV-05) | ADR-019 |
| Grouping PDF report | CRG p.88 (`GroupingReportService`) | BFF export endpoint | — |
| Data warehouse feed | FN p.7 | Tenant-scoped S3 datasets to Gainwell Genius; files to external consumers through S3 + MoveIt. Feed content **Open (Q-12)** | ADR-019, ADR-003 |

# 9. Data Architecture and Persistence

> **Status:** Partial — column-level mapping, volumes (Q-24), member data (Q-11), ADR-020 extension (Q-23) · **Sources:** ADR-007, ADR-012, ADR-013, ADR-020, INV · **Feeds:** Alembic migrations, repositories, migration scripts

## 9.1 Overview

| Store | Database / schema | Holds | Written by | Read by |
|---|---|---|---|---|
| Tenant | `pp_{tenant}` / `plan` | All tables in §9.2 not marked `*` | Plan Management services; Glue import jobs | Plan Management services |
| Shared | `db_shared` / `plan` | Tables marked `*` in §9.2 | Loader Glue jobs only (ADR-020) | Plan Management services (read-only role) |
| Archive | `pp_{tenant}` / `plan_audit_archive` | Legacy `COMMITS`, `SNAPSHOTS`, `EVENT_AUDIT` | One-time migration load | Audit endpoints |

- **Decision (ADR-012, ARB §4.1):** database per tenant on a shared Aurora cluster (`pp_t1`, `pp_t2`, …); CM-PE, CMS-PM and CM-PL tables share the state's database (ARB §9.4). Plan Management owns schema `plan` in it.
- `db_shared` also holds the CM-CORE Tenant Registry tables; Plan Management reaches the registry only through its API.
- PostgreSQL cannot join across databases and no FDW or dblink is used. Services open a second, read-only connection to `db_shared` through the `ConnectionRouter` and cache code values in Redis under the non-tenant prefix `shared:`.
- CRUD (ADR-041): every read and write uses the same tables.

## 9.2 Data Model

| Area | Tables |
|---|---|
| Platform | `pm_outbox_event`, `pm_publication_status`, `pm_import_job`, `pm_file_loader_history` |
| Audit | `pm_version_history` |
| Provider and member reference | `pm_provider`, `pm_provider_service_location`, `pm_member` |
| Provider-specific rates | `pm_provider_specific_rate` (Nursing Facility, Encounter, Dispensing Fee, Inpatient, Outpatient), `pm_provider_ucc_rate`, `pm_provider_drg_rate`, `pm_provider_drg_custom` |
| Member-specific rates | `pm_member_rate` |
| Fee schedules | `pm_fee_schedule`, `pm_fee_schedule_field`, `pm_fee_schedule_field_definition`, `pm_fee_schedule_line` |
| Code information | `pm_code`*, `pm_code_state`, `pm_code_restriction`, `pm_hcpcs_ndc_association`*, `pm_hcpcs_ndc_association_state`, `pm_vos_tag` |
| NDC | `pm_ndc`*, `pm_ndc_state`, `pm_ndc_package`, `pm_manufacturer`*, `pm_manufacturer_state`, `pm_drug_classification`*, `pm_drug_classification_state`, `pm_labeler`*, `pm_labeler_state`, `pm_labeler_rebate_program`, `pm_ndc_status`*, `pm_ndc_status_state`, `pm_ndc_rate`, `pm_ndc_rebate` |
| Groupings | `pm_grouping`, `pm_grouping_item` |
| Related information | `pm_exception_information`, `pm_exception_information_restriction`, `pm_exception_error_code`, `pm_exception_error_code_restriction`, `pm_explanation_of_benefit`, `pm_explanation_of_benefit_restriction`, `pm_edit_rule` (MUE, NCCI), `pm_formatted_content`, `pm_cycle_schedule` |
| Legacy audit archive | Schema `plan_audit_archive` (read-only) |

`*` = national base in `db_shared`. Each `*_state` table holds the state's additions and edits of that national table (§2.1.3, Appendix D.3.3). `pm_manufacturer`, `pm_drug_classification`, `pm_labeler`, `pm_ndc_status`, `pm_hcpcs_ndc_association` and modifier codes are beyond the ADR-020 list (**AS-12**, **Q-23**).

Common columns on every maintained table: `effective_date`, `end_date`, `is_valid`, `version_number`, `change_request_code` (where legacy has it), `created_at`, `created_by`, `updated_at`, `updated_by`.

```mermaid
erDiagram
  pm_provider ||--o{ pm_provider_service_location : has
  pm_provider ||--o{ pm_provider_specific_rate : has
  pm_provider ||--o{ pm_provider_ucc_rate : has
  pm_provider ||--o{ pm_provider_drg_rate : has
  pm_provider_drg_rate ||--o{ pm_provider_drg_custom : has
  pm_member ||--o{ pm_member_rate : has
  pm_fee_schedule ||--o{ pm_fee_schedule_field : defines
  pm_fee_schedule ||--o{ pm_fee_schedule_line : contains
  pm_grouping ||--o{ pm_grouping_item : contains
  pm_outbox_event ||--|| pm_publication_status : tracks
```

**Retired legacy tables** (full list in Appendix K.1):

| Legacy tables | Replaced by |
|---|---|
| `PROVIDER_ETL`, `ETL_RESULT`, `PURGE_RESULT`, `BATCH_ERROR_MSG`, `BATCH_ERROR_RECORD` | `pm_import_job` and S3 row-level error files (Appendix I.4) |
| `STAGING_NURSING_FACILITY` | Nothing (no documented use) |
| `HPP_TENANT` | Tenant Registry `tenants` (CM-CORE) |
| `EVENT_DISTRIBUTION` | `pm_outbox_event` and the Outbox Relay (§7.7) |
| `QUERY_LOG`, `QUERY_LOG_INDEX` | Nothing (no CQRS query store) |
| `COMMITS`, `SNAPSHOTS`, `EVENT_AUDIT` | `plan_audit_archive` (read-only) and `pm_version_history` (§9.10) |

## 9.3 Data Ownership

| Data | System of record | Owning service | Schema | How it arrives |
|---|---|---|---|---|
| Provider and service location | CMS-PM | Rate Setting (copy only) | `pp_{tenant}.plan` | Migration load, then `provider.*` events (§2.1.1) |
| Member reference | Member module | Rate Setting (copy only) | `pp_{tenant}.plan` | Migration load; ongoing source open (Q-11) |
| Provider-specific and member-specific rates, fee schedules | Plan Management | Rate Setting | `pp_{tenant}.plan` | UI and imports |
| National code sets, NDC, manufacturers, drug classifications, labelers (base) | CMS, FDB, Noridian | Loader Glue jobs (write); Code Information (read) | `db_shared.plan` | Vendor files (§11) |
| State additions and edits of national data | The state | Code Information | `pp_{tenant}.plan` (`*_state`) | UI and client-sourced events (§2.1.3, §8.1) |
| Code restrictions, NDC rates and rebates, VOS tags | Plan Management | Code Information | `pp_{tenant}.plan` | UI and imports |
| DataLists and maintenance levels | Configuration Management | — | Configuration Management | Read only (Q-32) |
| Groupings | Plan Management | Grouping | `pp_{tenant}.plan` | UI and imports |
| EOB, exceptions, MUE, NCCI, formatted content, cycles | Plan Management | Related Information | `pp_{tenant}.plan` | UI and imports |

**Schema ownership.** Only Plan Management services hold a database role with grants on schema `plan`. Other modules (CM-PE, CMS-PM) have no grants on it and receive Plan Management data only through events (ADR-002). Plan Management roles have no grants on other modules' schemas. The `db_shared` role is read-only. Verified by isolation test #8 (§10.4). The ARB does not define per-module schema ownership; this closes that gap for CM-PL.

**Overlapping legacy copies.** `UA3_PROVIDER.PROVIDER_UCC_RATES` duplicates `PROVIDER_UCC_RATE`, and `UA3_TENANT.TM_CYCLE_DT` overlaps `CYCLE_SCHED`. Plan Management owns both; the copies are reconciled into `pm_provider_ucc_rate` and `pm_cycle_schedule` during migration and then retired.

## 9.4 Database and Schema Design

| Rule | Detail |
|---|---|
| Credentials | Each service uses two credentials resolved by the `ConnectionRouter` (`hpp_db`): a tenant role with grants on `pp_{tenant}.plan`, and a read-only role on `db_shared.plan` |
| Keys | `uuid` primary keys (`gen_random_uuid()`) |
| Cross-database references | Logical only (no foreign keys across databases); checked by the service |
| Overlap | `daterange` + exclusion constraint where business keys must not overlap (BR-010) |
| Encryption | Per-tenant KMS key and Secrets Manager credential per tenant database (ADR-031) |
| Naming | `pm_` prefix; DDL in Appendix D |

## 9.5 Legacy-to-Target Data Mapping

Table-level mapping is in Appendix D.4; the disposition of all 80 `UA3_PLAN_MGMT` tables is in Appendix K.1. **Column-level mapping is pending** and is a prerequisite for the migration scripts (§0.8).

## 9.6 Data Classification and Privacy

| Data | Classification | Controls |
|---|---|---|
| Provider name, location contact names (`pm_provider`, `pm_provider_service_location`) | PII | Per-tenant KMS encryption; redacted in logs (`hpp_observability`); never in events or error responses |
| Member data (`pm_member`, `pm_member_rate`) | PII — scope open | ADR-006 states no beneficiary health information resides in Provider Plus; storing member identifiers needs Compliance approval (Q-11, AS-04) |
| Rates, fee schedules, code restrictions, related information | Internal business data | Tenant database; per-tenant KMS key |
| National code sets (`db_shared`) | Public reference data | Read-only to services |

The platform handles provider PII, not PHI (ADR-006).

## 9.7 Lifecycle and Retention

| Data | Retention | Source |
|---|---|---|
| Business records | Never deleted; invalidated or end-dated (BR-014) | UG p.133 |
| Load files, error files, legacy audit archive | 7 years in S3 Object Lock; Glacier after 90 days | ADR-016 |
| pgAudit and CloudTrail logs | 7 years in S3 Object Lock | ADR-016 |
| Event topics | 90 days | ADR-037 |
| Published `pm_outbox_event` rows, `pm_import_job` rows | **Open (Q-24)** | — |
| Idempotency keys | 24 h (Redis TTL) | §6.4 |

## 9.8 Data Migration and Reconciliation

| Step | Detail | Source |
|---|---|---|
| Sources | Legacy SQL Server, or Oracle for tenants that run on Oracle; each tenant from its production engine | ADR-013 |
| Load | One-time ETL (AWS DMS + scripts) into `pm_*` using Appendix D.4 and K.1 | ADR-013 |
| Reconciliation | Row counts, keys, effective-date ranges and rate values per tenant per area; differences resolved before cutover | ADR-029 |
| Parallel run | Legacy and target side by side for one full business cycle with the same loads and rate changes | ADR-029 |
| Cutover | Final delta load, reconciliation sign-off, consumers switched, legacy read-only; no dual-write after cutover | §15 |
| Versioning | Migrated records start at `version_number` 1 | — |

Detail in Appendix L.

## 9.9 Schema Migrations

- Alembic is the only migration tool (ADR-007). Revisions live in `components/supporting-modules/plan-mgmt/db/<service>/` and run through the shared Alembic runner.
- Applied per tenant database by the pipeline; a failure blocks only that tenant. The schema version per tenant is recorded in the Tenant Registry.
- Plan Management revisions touch schema `plan` only and keep their own version table `plan.alembic_version`. Revisions for `db_shared.plan` run once per environment.
- Every migration is backward compatible with the previous application version (expand, then contract).

## 9.10 Audit and Legacy History

- `pm_version_history` records every add, update, copy, insert, invalidate and Release Status change in the same transaction, with `before_json` and `after_json` (BR-023). It replaces legacy `EVENT_AUDIT` for new changes and serves the `/events` and `/aggregate-delta` queries.
- Legacy history (`COMMITS`, `SNAPSHOTS`, `EVENT_AUDIT`) is exported once to S3 (Object Lock) and loaded into the read-only `plan_audit_archive` schema; it is not replayed. Audit endpoints return archive history before cutover and `pm_version_history` after.

## 9.11 Data Volumes

> **Status:** Open (Q-24) — row counts and growth per tenant per table are not yet captured. Source: legacy production row counts per state. Needed for indexing, Glue sizing and the 4-hour batch SLA (NFR-07).

# 10. Security, Identity and Tenancy

> **Status:** Complete · **Sources:** ADR-008, ADR-009, ADR-014, ADR-023, ADR-031 · **Feeds:** auth middleware, IAM policies, isolation test suite

## 10.1 Entry Point and Trust Boundaries

| Boundary | Control | Source |
|---|---|---|
| Internet → API Gateway | Regional WAF (OWASP CRS), TLS 1.3, throttling | ADR-031 |
| API Gateway → BFF | Native JWT authorizer (signature, issuer, audience, expiry, `tenant_id` required); VPC Link to internal ALB | ADR-008 |
| BFF → services | IAM-signed requests (SigV4) + forwarded JWT; NetworkPolicy allows only the BFF | ADR-009 |
| Services → data | `ConnectionRouter` per tenant; schema-scoped database roles | ADR-025, §9.3 |
| External systems | No inbound route; outbound only through CMS-INX | ARB §3.1 |

## 10.2 Identity and Authentication

- Users sign in through IRM broker with FAPI 2.0 (Authorization Code + PKCE + PAR) (ADR-014). Token model in §5.4.
- Every service validates the JWT (`hpp_auth`); tenant comes from `hpp_tenant_context`.
- Pods use EKS Pod Identity with least-privilege IAM roles; no static credentials; secrets from AWS Secrets Manager (ADR-031).

## 10.3 Authorization

- Roles follow the legacy security roles (§1.5); scopes per endpoint in Appendix G.
- Maintenance levels (BR-019) and DrugLabelerSource (BR-021) further restrict writes and are enforced in the domain services.

## 10.4 Tenant Context and Isolation

The tenant database is selected by the `ConnectionRouter` from the JWT `tenant_id`; no request can reach another tenant's database. A tenant isolation suite runs as a **mandatory CI gate on every pull request and merge to `main`**; any failure blocks the merge (ADR-023).

| # | Boundary | Negative test |
|---|---|---|
| 1 | JWT `tenant_id` (gateway, BFF, every service) | A token for tenant A cannot read or change tenant B data; a token without `tenant_id` is rejected |
| 2 | Database routing (`hpp_db`) | A request for tenant A can open only `pp_{tenant_A}` |
| 3 | S3 path prefix | Tenant A cannot read, write or list objects under tenant B's prefix |
| 4 | Event Backbone | An event for tenant A is never applied to tenant B data; an event without `tenant_id` goes to the DLQ |
| 5 | Redis key prefix | A tenant A key is never returned for tenant B; `shared:` keys hold only `db_shared` data |
| 6 | CloudWatch namespace / dimensions | Tenant A metrics and logs are not visible in tenant B dashboards |
| 7 | Tenant Registry configuration | Tenant A cannot read or use tenant B configuration, flags or routing |
| 8 | Schema ownership (CM-PL addition) | Another module's role cannot read or write schema `plan`; a Plan Management role cannot read other schemas; the `db_shared` role cannot write |

Also required: an external penetration test of tenant isolation passed before any state goes live, and an immediate security alert on any cross-tenant access attempt (CloudWatch, GuardDuty) (ADR-031).

## 10.5 Data Protection

Encryption at rest with per-tenant KMS keys (Aurora and S3); TLS 1.3 in transit (TLS 1.2 only for legacy external inbound clients); PII is masked in logs with `hpp_observability` (allow-list, HMAC-SHA256) and never returned in errors (ADR-016, ADR-031).

# 11. Batch and File Processing

> **Status:** Partial — per-feed formats for CMS/FDB code sets pending · **Sources:** SPG, UG p.144–152, ADR-010 · **Feeds:** Glue jobs, Airflow DAGs, Appendix I

All legacy console loaders and SSIS packages are replaced by **AWS Glue Spark (Python 3.12)** jobs orchestrated by **Amazon MWAA** (ADR-010). Jobs read files staged in S3, apply the legacy loader validations, write idempotently, write outbox rows and record results in `pm_import_job`.

| Rule | Detail | Source |
|---|---|---|
| Trigger | S3 file-arrival sensor or an import request; no date-driven status job | SPG p.1 |
| Cadence | Weekly FDB, monthly Noridian, quarterly CMS NDC, HCPCS and labeler files, annual CPT | UG p.152 |
| Rate uploads | Apply Insert New (BR-011); need the provider reference loaded first | SPG p.93 |
| Fee schedule uploads | The fee schedule is locked while its upload runs | Appendix B.5 Lock/Unlock |
| Code set purge | Non-production utility only ("Do not run this process in Production") | SPG p.148 |
| SLA | 99% of jobs within 4 hours (NFR-07) | ADR-010 |

| Legacy loader | Target job | Disposition |
|---|---|---|
| `CMSHCPCSLoader`, `CDTLoader`, `ICD10DiagLoader`, `ICD10ProcLoader`, `ICD9DiagLoader`, `ICD9ProcLoader`, `DRGLoader`, `RevenueLoader`, `ModifierLoader` | One Glue job and DAG per CMS feed | Change |
| `FDBNDCLoader`, `FDBNDCClassLoader`, `FDBNDCMFRLoader`, `FDBNDCRatesLoader`, `CMSNDCLoader` | Glue ingestion of FDB/CMS NDC files with file-arrival sensors and retries | Change |
| `FeeScheduleLoader`, `RateLoader`, `NoridianLoader` | Glue jobs applying BR-011 | Change |
| `EOBLoader`, `GroupLoader` | Glue jobs keeping the legacy Excel template validations (Appendix I) | Change |
| `DataListItemLoader`, `DataListCacheRefresh`, `DataListItemExtract`, Reset Datalist Item Data, duplicate-attribute clean-up | Configuration Management | Retire (from CM-PL) |
| Initial Provider Loader | One-time migration step (§2.1.1, §9.8) | Change |
| File to Event processes | CMS-INX events (§8.1) | Change |
| `CodeSetsConversion` | Migration Glue job | Change |
| `ORACLE_Purge_RestrictedCodeData`, `SQL_Purge_RestrictedCodeData` | One tenant-aware purge Glue job (non-production) | Change |
| SSIS packages | — | Retire |

# 12. Infrastructure, Delivery and Operations

> **Status:** Partial — runbook content pending; DV-03 awaiting approval · **Sources:** ADR-004, ADR-015, ADR-016, ADR-024, ADR-031 · **Feeds:** Helm charts, Terraform, pipelines, dashboards

## 12.1 Compute and Scaling

| Component | Runs on | Scaling |
|---|---|---|
| `mfe-plan-management` | S3 + CloudFront | — |
| BFF (shared) | Existing BFF deployment on EKS | Existing BFF scaling |
| Rate Setting API host (+ Outbox Relay, provider event consumer) | EKS Auto Mode, `plan-mgmt` | KEDA: request rate / CPU and queue depth or consumer lag |
| Code Information API host (+ Outbox Relay, client-sourced event consumer) | EKS Auto Mode, `plan-mgmt` | KEDA: request rate / CPU and queue depth or consumer lag |
| Grouping and Related Information API hosts (+ Outbox Relay) | EKS Auto Mode, `plan-mgmt` | KEDA: request rate / CPU |
| Batch | AWS Glue + Amazon MWAA | Glue autoscaling |

The `plan-mgmt` namespace has ResourceQuota, LimitRange, PodDisruptionBudgets, EKS Pod Identity service accounts and NetworkPolicies: only the BFF reaches the Plan Management APIs; the APIs reach only Aurora, Redis, the Tenant Registry and the messaging endpoints.

## 12.2 Network and Ingress

Amazon API Gateway with a regional WAF web ACL and native JWT authorizer; VPC Link to an internal ALB in front of the BFF; TLS 1.3. No inbound route for external systems. Egress through the shared Security VPC (Palo Alto NGFW, layer-7 egress proxy) (ADR-031).

## 12.3 Delivery

| Concern | Choice | Source |
|---|---|---|
| CI/CD | GitHub Actions, trunk-based, protected `main`, one pipeline per domain | ADR-015 |
| Infrastructure | Terraform; state in S3 with DynamoDB locking | ADR-015 |
| Images | Docker → Amazon ECR with image scanning | ADR-015 |
| Packages | JFrog Artifactory (NuGet, npm, PyPI) | ADR-015, ADR-025 |
| Release to EKS | Helm chart per service, Argo CD, Argo Rollouts canary (10% → 50% → 100%) with automatic rollback on CloudWatch alarms | DD-03 — **deviation DV-03**: ADR-015 covers Lambda only (SAM, CodeDeploy) and excludes Argo CD |
| Production approval | GitHub Environments | ADR-015 |

## 12.4 CI Quality Gates

Every gate blocks the merge or release on failure (ADR-015, ARB §4.9).

| Gate | When |
|---|---|
| Unit tests | Every PR |
| Consumer-driven contract tests (OpenAPI and events) | Every PR |
| OpenAPI breaking-change diff | Every PR |
| Tenant isolation suite (§10.4) | Every PR and merge to `main` |
| SAST, SBOM, secret scanning, dependency review, PII field scanner | Every PR |
| ECR image vulnerability scan | Every build |
| Accessibility (axe-core, Lighthouse CI) | Every PR (UI) |
| Integration tests | Merge to `main` |
| Playwright UI tests | Merge to `main` / nightly |
| Terraform IAM policy linter | Every PR (infra) |
| FAPI 2.0 conformance check on the IRM broker client | Release |
| Production approval | Release (GitHub Environments) |

## 12.5 Observability

| Concern | Standard |
|---|---|
| Instrumentation | OpenTelemetry in the remote, BFF, every service (incl. Outbox Relay and consumers) and every Glue job; export to CloudWatch (ADR-016) |
| Tracing | W3C `trace_id` from UI → gateway → BFF → API → database and event envelope; `tenant_id` on every span |
| Logging | Structured JSON with `tenant_id`, `correlation_id`, `service_name`, `timestamp`, `severity`; PII redacted by `hpp_observability` |
| Metrics | Request rate, error rate, P50/P95/P99 per endpoint; queue depth / consumer lag; outbox backlog; Glue job success and duration |
| Dashboards | Per-tenant CloudWatch dashboards with a Plan Management section |
| Alerts | DLQ depth > 0; consumer lag > 60 s; unpublished outbox rows older than 5 min; API P95 > 2 s; error rate above budget; batch failure or SLA breach |

## 12.6 Runbooks

> **Status:** Open — list agreed, content pending.

| Runbook | Trigger |
|---|---|
| DLQ redrive (`plan.dlq.v1`) | DLQ depth > 0 |
| Failed publication retry | `pm_publication_status = Failed` |
| Failed import re-run | `plan.import.failed.v1` |
| Alembic migration failure for one tenant | Pipeline failure |
| Fee schedule left locked after a failed upload | Lock older than the import job |
| Provider reference resync | Missing provider or location (BR-001) for a known CMS-PM provider |
| DR failover and failback | Regional outage (ADR-024) |

## 12.7 Disaster Recovery

| Concern | Target | Source |
|---|---|---|
| Regions | Primary us-east-1, DR us-west-2 | ADR-024 |
| RTO | 15 minutes | ADR-024 |
| RPO | 10 minutes for Aurora tenant data; near-zero for S3 and events | ADR-024 |
| Mechanism | Aurora Multi-AZ; daily snapshots cross-copied; 35-day PITR; S3 Cross-Region Replication; Aurora global database promotion runbook; Route 53 health-check failover | ADR-024 |
| Redeploy | Terraform + Helm/Argo CD in the DR region (DV-03) | ADR-024 |

# 13. Non-Functional Requirements

> **Status:** Complete · **Sources:** ARB §5, ADR-016, ADR-024, ADR-032, ADR-038 · **Feeds:** performance tests, alarms, capacity plan

| ID | Requirement | Target | Scope | Measured by | Source |
|---|---|---|---|---|---|
| NFR-01 | Synchronous API latency | P95 ≤ 2 s | All `/v1` endpoints via API Gateway | OpenTelemetry APM, k6 | ADR-038 |
| NFR-02 | Rate save, copy, insert | P95 ≤ 2 s | Rate Setting write endpoints | OpenTelemetry APM | ADR-038 |
| NFR-03 | Data write latency | P95 ≤ 500 ms per upsert | Repository layer | OpenTelemetry DB spans | ADR-038 |
| NFR-04 | Page load | P95 ≤ 3 s | `mfe-plan-management` screens | Lighthouse CI, RUM | ADR-038 |
| NFR-05 | Event propagation | P95 ≤ 60 s commit → consumer | `plan.*` events | Outbox age + consumer lag | ADR-038 |
| NFR-06 | Throughput | ≥ 100 requests/s per tenant | BFF + APIs | k6 load test | ADR-038 |
| NFR-07 | Batch completion | 99% of jobs within 4 hours | Glue imports | MWAA run metrics | ADR-010 |
| NFR-08 | Availability | 99.99% monthly | APIs, BFF routes, Aurora, Event Backbone | CloudWatch synthetics | ADR-038 |
| NFR-09 | Recovery | RTO 15 min; RPO 10 min (Aurora) | Tenant data | DR test | ADR-024 |
| NFR-10 | Retention | Audit and load files 7 years | S3 Object Lock | Bucket policy audit | ADR-016 |
| NFR-11 | Accessibility | WCAG 2.2 AA, Section 508 | All screens | axe-core, Lighthouse CI | ADR-032 |

# 14. Testing and Quality Strategy

> **Status:** Partial — tests not yet linked in §14.4 · **Sources:** ADR-015, ADR-023, ADR-028, ADR-029, RT · **Feeds:** test suites, CI gates

## 14.1 Test Levels

| Level | Scope | Tooling | Gate / cadence |
|---|---|---|---|
| Unit | Domain rules (BR ids), validation, mapping | xUnit (services), Jest (BFF, UI) | Every PR |
| Repository / data | SQL, constraints (incl. overlap exclusion), outbox transactionality | Testcontainers PostgreSQL at Alembic head | Every PR |
| API and event contract | OpenAPI conformance, error model, consumer-driven contracts | OpenAPI validator, Pact or equivalent | Every PR |
| Tenant isolation | Eight boundaries (§10.4) | Isolation suite | Every PR and merge to `main` |
| Integration | Service + database + outbox + Event Adapter | Ephemeral environment | Merge to `main` |
| UI and accessibility | Role-based flows, a11y | Playwright, axe | PR smoke + nightly |
| Batch | Glue jobs: golden files, bad rows, idempotency, BR-011 on upload | Glue local runner | Every PR |
| Security | SAST, DAST, authorization, secrets | Security toolchain | Every PR + release |
| Performance | NFR-01 – NFR-07 | k6 + load harness | Release |
| Migration and reconciliation | Row counts, keys, date ranges, rate values per tenant (§9.8) | Reconciliation framework | Before cutover |
| Legacy parity | Target vs legacy against ADR-029 thresholds | Parity pipeline | Gate 1, Gate 2, dress rehearsals, Gate 3 |
| Resilience / DR | Failover, DLQ redrive, relay restart | Chaos and DR drills | Before go-live, then quarterly |

## 14.2 Test Data

- Synthetic data only (§0.4.5).
- Golden files per import type (Appendix I) with expected accepted, rejected and error-file output.
- Date-logic cases for overlap, Insert New and edit limits (BR-010, BR-011, BR-013) are taken from the legacy Regression Test Cases (RT).

## 14.3 Generated Test Artifacts

Generated tests are reviewed by the QA Lead and Validation Lead before they run in CI; no generated artifact runs unreviewed (ADR-028, IMAGE methodology).

## 14.4 Traceability Matrix

| Rule / requirement | Endpoint(s) / event(s) | Screen(s) | Test(s) |
|---|---|---|---|
| BR-001 – BR-004 reference checks | Rate create endpoints | Provider and Member Specific Rates | TBD |
| BR-010, BR-011 overlap and Insert New | Rate create, `:insert`, rate uploads | Provider Specific Rates, File Upload | RT date-logic cases |
| BR-012 Change Request ID | Create, `:copy` | Rate, fee schedule and code set screens | TBD |
| BR-013, BR-020 date-based edit limits | Rate, fee schedule, MUE/NCCI PATCH | Rate, Fee Schedule, MUE, NCCI | TBD |
| BR-015, BR-016 Release Status and identifiers | Fee schedule PATCH, Edit Fields | Fee Schedules | TBD |
| BR-019 maintenance levels | Code set and NDC writes | Code Sets, Pharmacy | TBD |
| BR-022 tenant isolation | All | All | Isolation suite #1–#8 |
| BR-023 audit | All writes; `/audit`, `/events` | Audit panels | TBD |
| BR-025 publication | `pm_outbox_event`, `pm_publication_status`, `plan.*` | Publication & Integration Status | TBD |
| Stale `versionNumber` → 409 (M-24) | All mutating endpoints | All edit screens | TBD |
| Imports match golden files | `/v1/{area}/imports`, `plan.import.*` | File Upload | Golden-file suite |

# 15. Legacy Transition and Retirement

> **Status:** Partial — Q-17, Q-18, Q-19 open · **Sources:** ADR-022, ADR-029, ADR-034, ARB §6 · **Feeds:** cutover plan, parity pipeline

## 15.1 Transition Pattern

- **Decision (ADR-022):** strangler fig. Target services are built beside the legacy WCF services, parity is validated, and legacy WCF is retired at Gate 3.
- Data is migrated and cut over per tenant, from the engine the tenant runs in production, with no dual-write after cutover (§9.8). A split by capability instead of by tenant would need a data sync design.
- **Open (Q-17):** retirement slices (by tenant or by endpoint family) and coexistence period.

## 15.2 Coexistence

```mermaid
flowchart LR
  Files["Vendor and rate files"] --> L["Legacy CM-PL<br/>(system of record)"]
  Files --> T["Target CM-PL<br/>(parallel run)"]
  Users["Rate changes (replayed)"] --> L
  Users --> T
  L --> P["Parity pipeline<br/>(ADR-029)"]
  T --> P
  P --> R["Parity report<br/>+ known-difference register (Appendix M)"]
```

## 15.3 Phases

| Phase | System of record | Legacy endpoints | Target | Exit criteria |
|---|---|---|---|---|
| Build | Legacy | Active | In development | Slices in §19.4 complete in DEV |
| Parity / parallel run | Legacy | Active | Parallel run | Parity > 80% at Gate 1 and Gate 2 (ADR-029); business and operations sign-off |
| Dress rehearsals | Legacy | Active | Rehearsal cutovers | Parity ≥ 95% (ADR-029); two rehearsals (ARB §6, M5) |
| Cutover | Target | Read-only | Live | Parity ≥ 98% at Gate 3; final delta load; reconciliation sign-off; consumers switched; rollback runbook signed (ARB §6, M5) |
| Hypercare | Target | Read-only | Live | TBD |
| Retirement | Target | Retired (ADR-022) | Live | §15.6 |

## 15.4 Legacy Consumer Switch-Over

> **Status:** Open (Q-18) — consumers named in the legacy guides are listed in §8.1; external consumers are not yet inventoried. Endpoint mapping in §6.3.

| Legacy endpoint | Legacy consumers | Switch method | Temporary compatibility component (owner, removal date) | Retire at |
|---|---|---|---|---|
| TBD | TBD | TBD | TBD | TBD |

## 15.5 Rollback

> **Status:** Open (Q-19) — a signed rollback runbook is required by milestone M5 (ARB §6). Triggers, data reconciliation back to legacy and freeze windows are not yet defined.

## 15.6 Retirement Criteria

Legacy WCF retires at Gate 3 (ADR-022) when parity ≥ 98%, every consumer in §15.4 has switched, and the rollback window has closed. Per-endpoint criteria depend on Q-17.

## 15.7 Legacy Changes During Transition

Every change to legacy Plan Management after 2026-06-01 is logged in the Current State Delta Log and reviewed each sprint (ADR-034). A change that affects a rule in §2.1, a table in Appendix D or a file in Appendix I updates this document and the parity baseline before the next gate.

# 16. Architecture Decisions, Exceptions and Alignment

> **Status:** Complete — DV approvals pending · **Sources:** ADR Live Document, ARB · **Feeds:** ARB review, ADR amendments

## 16.1 Decision Register

| ID | Decision | Rationale | Status | Related |
|---|---|---|---|---|
| DD-01 | BFF runtime is the shared NestJS 10 BFF | Shared with the existing micro frontends | Program decision; **deviates from ADR-011** | DV-01, Q-01 |
| DD-02 | Browser → API uses a bearer JWT validated by API Gateway; no cookie session or CSRF | ADR-008, ADR-014 | Aligned | Q-02 (closed) |
| DD-03 | Release to EKS with Helm, Argo CD and Argo Rollouts | CodeDeploy does not support EKS | Program decision; **deviates from ADR-015** | DV-03, Q-03 |
| DD-04 | CRUD; no CQRS, read models or projectors | ADR-041 | Aligned | Q-06 (closed) |
| DD-05 | All services, event consumers and the Outbox Relay run on EKS as hosted services; no Lambda, ECS or Kubernetes Jobs | One runtime per module | Program decision; **deviates from ADR-005 and ADR-022 (Lambda)** | DV-02, Q-08 (closed) |
| DD-06 | Business workflows are the same as legacy; features with no legacy equivalent are not built | Stakeholder decision, 2026-11-01 | Approved | Appendix M |
| DD-07 | National data in `db_shared`; state additions and edits in tenant `*_state` tables | Preserves legacy online maintenance on top of ADR-020 | Proposed; **needs ADR-020 extension** | DV-06, Q-23 |
| DD-08 | Keep the name CMS-INX for the integration boundary | Architect decision | Program decision; **deviates from ARB naming** (External Integration Adapter) | DV-04, Q-04 |
| DD-09 | Transactional outbox (`pm_outbox_event`) and Outbox Relay | Atomic save and publish; ARB leaves it open (ARB §9.4) | Proposed; no ADR exists | Raise ADR |

## 16.2 Domain Decisions

DD-06 and DD-07 are the domain decisions; their effects are recorded in §2.3, §2.1.3 and Appendix M.

## 16.3 Alignment with Platform Standards

| ADR / ARB | Position | This document | Status |
|---|---|---|---|
| ADR-002 | Event Backbone via Event Adapter; envelope; `pp.<domain>.<stream>` topics | §7 | Aligned |
| ADR-002a | AWS Glue Schema Registry | §7.8 | Aligned |
| ADR-003 | Outbound files via S3 + MoveIt | §8.5 | Aligned |
| ADR-004 | .NET 10 on EKS Auto Mode; Python 3.12 for Glue | §3.4 | Aligned |
| ADR-005 | Lambda consumers for projectors and integration workers | Hosted services on EKS (DD-05) | **DV-02** |
| ADR-006 | Provider PII, no PHI or beneficiary health data | Member data scope open | Aligned; Q-11 must confirm |
| ADR-007 | Alembic only | §9.9 | Aligned |
| ADR-008 | API Gateway native JWT authorizer, single entry point | §5.4, §10.1 | Aligned |
| ADR-009 | IAM-signed service-to-service calls | §10.1 | Aligned |
| ADR-010 | Glue Spark on MWAA; 99% in 4 h | §11 | Aligned |
| ADR-011 | Next.js micro frontends; **.NET 10 Native AOT BFF** | Next.js remote; NestJS BFF (DD-01) | **DV-01** |
| ADR-012 | Database per tenant; national code sets in `db_shared` | §9.1 | Aligned |
| ADR-013 | DMS + scripts for data; Alembic for schema | §9.8 | Aligned |
| ADR-014, ADR-036 | IRM broker, FAPI 2.0 | §5.4, §10.2 | Aligned |
| ADR-015 | SAM + CodeDeploy (Lambda); Argo CD excluded | Helm, Argo CD, Argo Rollouts (DD-03) | **DV-03** |
| ADR-016 | OpenTelemetry; `hpp_observability`; 7-year WORM audit | §12.5, §9.7 | Aligned |
| ADR-018 | InRule per tenant | Not used (§2.5) | N/A — Q-16 |
| ADR-019 | On-demand reports via CM-CORE Reporting Service; analytics to Gainwell Genius | Exports in the BFF; data warehouse via Genius | **DV-05** (exports) |
| ADR-020 | National code sets (HCPCS, ICD-9, ICD-10, DRG, NDC, Revenue, Dental) in `db_shared`, loader-only writes | Also manufacturer, drug classification, labeler, NDC status, HCPCS–NDC association, modifiers; state edits in `*_state` (DD-07) | **DV-06** — Q-23 |
| ADR-022 | Strangler fig; .NET 10 Lambda functions beside WCF; retire at Gate 3 | Strangler fig kept; services on EKS (DD-05) | **DV-02** (compute only) |
| ADR-023 | Seven isolation boundaries on every PR | Seven + schema ownership (§10.4) | Aligned |
| ADR-024 | DR us-west-2, RTO 15 min, RPO 10 min | §12.7 | Aligned |
| ADR-025 | Seven `hpp_*` packages | §3.4; Event Adapter client and resilience library names to confirm | Aligned (Q-10 residual) |
| ADR-028 | IMAGE QE; reviewed generated tests | §14.3 | Aligned |
| ADR-029 | Parity thresholds 80/95/98% | §15.3 | Aligned |
| ADR-031 | Zero trust; WAF on API Gateway; per-tenant KMS; pen test before go-live | §10 | Aligned |
| ADR-032 | WCAG 2.2 AA | §4.7 | Aligned |
| ADR-033 | Spec-driven development; SA approves specs | §0.8, §5.5 | Aligned |
| ADR-034 | Current State Delta Log | §15.7 | Aligned |
| ADR-037 | 90-day retention; per-domain DLQ | §7.2 | Aligned |
| ADR-041 (supersedes ADR-026, ADR-040) | No CQRS | DD-04 | Aligned |
| ARB §2.1 naming | External Integration Adapter | CMS-INX (DD-08) | **DV-04** |

**Deviation register**

| ID | Deviation | ADR / ARB | Approval path | Owner |
|---|---|---|---|---|
| DV-01 | NestJS 10 BFF instead of .NET 10 Native AOT | ADR-011 | Amend ADR-011 or adopt a .NET BFF | SA, Frontend lead |
| DV-02 | Hosted services on EKS instead of Lambda consumers and Lambda functions | ADR-005, ADR-022 | Amend ADR-005 and ADR-022 | SA, Platform |
| DV-03 | Helm, Argo CD, Argo Rollouts for EKS | ADR-015 | Amend ADR-015 for EKS workloads | SA, Platform |
| DV-04 | Name CMS-INX instead of External Integration Adapter | ARB §2.1 | ARB naming note | SA |
| DV-05 | Screen exports in the BFF instead of the CM-CORE Reporting Service | ADR-019 | Confirm with CM-CORE or move exports | SA |
| DV-06 | Extra national tables in `db_shared`; state edits in `*_state` tables | ADR-020 | Extend ADR-020 | SA, Data |

# 17. Anti-Patterns and Failure Modes

> **Status:** Complete · **Sources:** ADRs, §2, §7 · **Feeds:** code review checklist, tests

## 17.1 Anti-Patterns (do not do)

| Anti-pattern | Why | Instead |
|---|---|---|
| Calling CMS-PM, CM-PE or Member APIs synchronously | Breaks ARB §3.1 rule 1 | Local reference copy from events |
| Reading another module's schema in the shared tenant database | Breaks schema ownership (§9.3) | Events |
| Writing to `db_shared` from a service | Breaks ADR-020 | State edits in `*_state` tables |
| Joining across `pp_{tenant}` and `db_shared` (FDW, dblink) | Not possible; couples databases | Resolve in the service; `shared:` cache |
| Taking `tenant_id` from a request body or event payload | Tenant spoofing | JWT / event envelope only |
| Branching code on tenant identity | ADR-018 principle | Feature flags, tenant configuration |
| Hard-coding DataList values | BR-006 | DataList lookups |
| Publishing an event outside the business transaction | Lost or phantom events | Outbox row in the same transaction |
| Deleting records | BR-014 | Invalidate or end-date |
| Adding features from Appendix M.1 (approval workflow, pricing precedence, …) | DD-06 | Raise a change request |
| Logging provider or member names | ADR-016 | `hpp_observability` redaction |
| Unbounded searches | Performance (NFR-01) | Mandatory paging and allow-listed filters |

## 17.2 Failure Modes

| Failure | Detection | Behaviour | Recovery |
|---|---|---|---|
| Outbox Relay down | Unpublished rows older than 5 min | Writes continue; events delayed | Relay restart publishes backlog |
| Publication fails repeatedly | `pm_publication_status = Failed` | Visible on Publication & Integration Status | Retry endpoint or runbook |
| Duplicate event delivery | — | Consumer ignores repeated `event_id` | None needed |
| Out-of-order provider events | Older `occurred_at` than stored | Older event ignored | None needed |
| Consumer poison message | DLQ depth > 0 | Message moved to `plan.dlq.v1` | Fix and redrive |
| Provider not yet in reference copy | BR-001 validation error | Rate save rejected (fail closed) | Provider resync runbook |
| Tenant Registry unavailable | Circuit breaker open | `503`, no write | Automatic when registry recovers |
| Import file malformed | Row-level errors | Job completes with rejected rows and error file | Fix file and re-import |
| Fee schedule left locked | Lock older than import job | Edits blocked | Unlock runbook |
| Alembic revision fails for one tenant | Pipeline failure | Only that tenant blocked | Fix revision; re-run |
| Concurrent edits | Stale `versionNumber` | `409` | User reloads |

# 18. Risks, Assumptions and Open Questions

> **Status:** Complete — owners for risks pending · **Sources:** this document, ADRs, ARB · **Feeds:** RAID log, ARB review

## 18.1 Risks

| ID | Risk | Impact | Likelihood | Mitigation | Owner |
|---|---|---|---|---|---|
| R-01 | ADR-020 is not extended; extra national tables must move to tenant databases | Schema rework for NDC, labeler, crosswalk | Medium | Decide Q-23 before Code Information schema is frozen (ADR-020 gates schema design) | SA, Data |
| R-02 | CMS-PM provider event catalog arrives late | Rates cannot be validated (BR-001–BR-003) | Medium | Event Catalog KT session; agree a stub contract early | SA, CMS-PM |
| R-03 | Compliance does not approve member identifiers in Provider Plus (ADR-006) | Member-specific rates cannot be delivered as designed | Medium | Raise Q-11 now | Compliance |
| R-04 | Deviations DV-01 – DV-06 are not approved | Rework of BFF, runtime, delivery or schema | Medium | Present the deviation register at the next ARB | SA |
| R-05 | Synchronous DataList validation conflicts with the no-sync rule (Q-32) | Rework of validation path | Medium | Decide Q-32 before rate endpoints are built | SA |
| R-06 | Unknown external consumers of legacy data | Breakage at cutover | Medium | Inventory consumers (Q-18) before Gate 2 | SA, Ops |
| R-07 | Legacy changes during transition are not reflected | Parity failures | Medium | Delta Log review every sprint (ADR-034) | SA |

## 18.2 Assumptions

| ID | Statement | Evidence | Status | Owner |
|---|---|---|---|---|
| AS-01 | One operational database per state (`pp_{tenant}`) shared by all modules; Plan Management owns schema `plan` | ADR-012, ARB §4.1, ARB §9.4 | **Closed in v8** (confirmed) | SA |
| AS-02 | CMS-INX is the boundary the ARB calls the External Integration Adapter | ARB §2.1 | **Closed in v8** → DD-08 / DV-04 | SA |
| AS-03 | The consumed provider events in §2.1.1 and Appendix E.3 match the CMS-PM catalog | ARB names only `provider.approved.v1` | Open (Q-07) | SA, CMS-PM |
| AS-04 | Member-specific rates are in scope; the member copy holds identifier and display name only | UG p.131–133 | Open (Q-11) | Compliance, Business |
| AS-06 | Shared libraries use the ADR-025 names; the Event Adapter client (`hpp_events`) and resilience library (`hpp_resilience`) keep working names until confirmed | ADR-025 | Partly closed (Q-10) | SA, Platform |
| AS-12 | `db_shared` also holds manufacturer, drug classification, labeler, NDC status, HCPCS–NDC association and modifiers | Beyond ADR-020 | Open (Q-23) | SA, Data |
| AS-14 | Processing Start/End Dates bound when a rate may be used in processing; Effective/End Dates bound the date of service | Inference from UG p.140, CRG p.72–78 | Open (confirm with business) | Business |
| AS-15 | Client-sourced (level 80) data arrives as CMS-INX events, one per record | SPG p.113–137 | Open (Q-27) | SA, Integration |

AS-05, AS-07 – AS-11 and AS-13 were closed in v7 by legacy evidence.

## 18.3 Open Questions

Priority: **Blocker** = stops build of a slice; **Important** = needed before go-live; **Quick win** = settle from legacy code; **Approval** = answered by an ADR, deviation needs sign-off; **Low**.

| ID | Priority | Question | Why it matters | Default used in this document | Needed from | Owner |
|---|---|---|---|---|---|---|
| Q-23 | Blocker | Extend ADR-020 to the extra national tables and the `*_state` pattern? | ADR-020 gates schema design; affects every reference-data table | Extra tables in `db_shared` (AS-12); state edits in `*_state` (DD-07) | ARB / ADR owner | SA, Data |
| Q-07 | Blocker | CMS-PM provider and location event catalog and payloads | Every rate needs a valid provider and location (BR-001–BR-003) | `provider.registered/updated/terminated.v1` (AS-03) | CMS-PM team; Event Catalog KT | SA, CMS-PM |
| Q-11 | Blocker (member rates only) | Source of member data after migration, fields stored, PII approval | ADR-006 says no beneficiary health data in Provider Plus | Identifier and display name only (AS-04) | Compliance, Business | Compliance |
| Q-32 | Blocker | How do services validate DataList values and maintenance levels (BR-006, BR-019) without a synchronous call to Configuration Management? | Configuration Management is not CM-CORE (ARB §3.1 rules 1–2) | **Proposal:** consume DataList change events into a read-only local cache; alternative: treat the DataList API as a CM-CORE shared service | SA, Configuration Management | SA |
| Q-27 | Important | Payload schemas of the nine `integration.plan.*` events | Level-80 states cannot go live without them | One event per record (AS-15) | Legacy File to Event templates | SA, Integration |
| Q-18 | Important | External consumers of legacy Plan Management data | Unknown consumers break at cutover | Consumers in §8.1 | Ops inventory | SA, Ops |
| Q-24 | Important | Data volumes; retention of outbox and import rows | Capacity, indexing, NFR-07 | None | Legacy production row counts | Data, Ops |
| Q-17 | Important | Strangler-fig slices and coexistence period | Cutover plan | Per tenant (§15.1) | SA | SA |
| Q-19 | Important | Rollback triggers and freeze windows | Rollback runbook due at M5 | None | SA, Ops | SA, Ops |
| Q-12 | Important | Data warehouse feed content | Downstream analytics | Genius S3 datasets (ADR-019) | Business, Data | Business |
| Q-30 | Quick win | Does an inactive provider or location block new rates? | Validation rule | Not blocked (legacy guides silent) | Legacy code | Business |
| Q-31 | Quick win | Can a fee schedule be edited in Release? | UG p.140 vs p.142 | Not editable in Release (UG p.142) | Legacy code | Business |
| Q-16 | Quick win | Does any Plan Management operation evaluate InRule rules? | Confirms M-10 | No InRule calls | Business rules lead | Business |
| Q-01 | Approval | NestJS BFF vs ADR-011 .NET BFF | DV-01 | NestJS (DD-01) | ARB | SA, Frontend lead |
| Q-03 | Approval | EKS release tooling (ADR-015 is Lambda-only; ARB notes the gap) | DV-03 | Helm, Argo CD, Argo Rollouts (DD-03) | ARB | SA, Platform |
| Q-04 | Approval | CMS-INX vs External Integration Adapter | DV-04 | CMS-INX (DD-08) | ARB | SA |
| Q-10 | Low | Package names for the Event Adapter client and resilience library (not in ADR-025) | Naming only | `hpp_events`, `hpp_resilience` | Platform | SA, Platform |

## 18.4 Resolved Questions

| ID | Topic | Resolution | Source | Resolved in |
|---|---|---|---|---|
| Q-02 | Browser → API auth | Bearer JWT validated by API Gateway's native JWT authorizer; no cookie or CSRF | ADR-008, ADR-014 | v8 |
| Q-05 | Tenant database model | One database per state (`pp_t1`, …) shared by all modules | ADR-012, ARB §4.1, §9.4 | v8 |
| Q-06 | CQRS vs CRUD | CRUD | ADR-041 | v6 |
| Q-08 | Event consumer compute | Hosted services on EKS (DV-02) | DD-05 | v6 |
| Q-09 | Per-tenant version pinning | Each state can run different UI, API, schema and event versions | ARB §4.6, ADR-011 | v8 |
| Q-13 | Outbound files | Exports, grouping PDF, data warehouse feed preserved | SPG p.108 | v7 |
| Q-14 | Pricing precedence | Not a Plan Management function (M-03) | FN p.8, p.10 | v7 |
| Q-15 | Time-based transitions | None; loaders on demand or file arrival | SPG p.1 | v7 |
| Q-20 | Pricing key | Key fields per rate type (§2.2.1) | UG p.108–139 | v7 |
| Q-21 | Location requirement | Required for all seven rate types (BR-003) | UG p.108–128 | v7 |
| Q-22 | Approval | No in-system approval (DD-06) | FN p.17–20, CRG p.58 | v7 |
| Q-25 | DataList ownership | Configuration Management | CRG p.1, UG p.7 | v7 |
| Q-26 | MCO records | Not in Plan Management (M-09) | UG p.1 | v7 |
| Q-28 | Unmapped legacy tables | `pm_labeler_rebate_program`; staging table retired | UG p.68–71 | v7 |
| Q-29 | Audit store | `pm_version_history` with before/after JSON | UG p.2, 129 | v7 |

# 19. Repository, Build and Delivery Plan

> **Status:** Partial — §19.3 pending · **Sources:** monorepo layout, ADR-025, ADR-033 · **Feeds:** scaffolding, build order

## 19.1 Repository Layout

Paths are relative to the monorepo root `mmes-cms-prv/`.

```
mmes-cms-prv/
├── components/
│   ├── enrollment/
│   │   ├── ux/components/
│   │   │   ├── shell/                    # Next.js host
│   │   │   ├── mfe-enrollment/
│   │   │   ├── mfe-credentialing/
│   │   │   ├── mfe-admin/
│   │   │   └── mfe-plan-management/      # Plan Management remote (§4)
│   │   └── bff/                          # shared BFF; Plan Management module (§5)
│   ├── supporting-modules/
│   │   └── plan-mgmt/                    # Plan Management module (§19.2)
│   └── shared-libs/libs/                 # hpp_* shared libraries (ADR-025)
├── db/                                   # shared Alembic environment and runner
└── iac/                                  # platform Terraform
```

## 19.2 Module and Service Structure

```
components/supporting-modules/plan-mgmt/
├── services/
│   ├── code-information-service/         # /v1/code-information, /v1/ndc
│   ├── grouping-service/                 # /v1/grouping
│   ├── rate-setting-service/             # /v1/rate-setting, /v1/fee-schedule, platform-status
│   └── related-information-service/      # /v1/related-information, /v1/cycle-schedule
├── api-specification/                    # OpenAPI (Appendix B) + AsyncAPI (Appendix E), per service
├── batch/                                # Airflow DAGs and Glue Spark jobs (§11)
├── db/                                   # Alembic revisions per service (§9.9)
├── libs/                                 # libraries shared by this module's services
├── deploy/                               # Helm values, Argo CD, environment overlays
├── infra/                                # Terraform for this module's AWS resources
├── local-dev/                            # docker-compose and stubs
├── Directory.Build.props                 # net10.0, Nullable, ImplicitUsings, TreatWarningsAsErrors
├── Directory.Packages.props              # central package versions
└── ProviderPlus.slnx
```

Inside each service:

```
services/rate-setting-service/
├── src/RateSettingService/
│   ├── Controllers/        # REST endpoints (create, edit, search, actions)
│   ├── Services/           # use cases, validation orchestration
│   ├── Domain/             # entities, business rules (BR ids), overlap and Insert New logic
│   ├── Repositories/       # Npgsql repositories, SQL
│   ├── Events/             # event contracts, outbox writer, Outbox Relay, consumers
│   ├── Infrastructure/     # data source, transactions, ConnectionRouter, adapters
│   ├── RateSettingService.csproj
│   └── Program.cs
├── tests/
├── helm/
└── Dockerfile
```

## 19.3 Legacy Capability to Layout Mapping

| Legacy project / component | Target location |
|---|---|
| `HP.HSP.UA3.PlanManagement.UX.Presentation` (MVC/Razor) | `mfe-plan-management` |
| `UX.Services`, `UX.Providers` | BFF Plan Management module |
| Code Information and NDC WCF services | `services/code-information-service` |
| Grouping WCF services | `services/grouping-service` |
| Rate Setting, Fee Schedule, file upload WCF services | `services/rate-setting-service` |
| Related Information, Cycle Schedule WCF services | `services/related-information-service` |
| `components/batch/*Loader` | `batch/` |
| Event store, `EVENT_DISTRIBUTION` | `Events/` outbox in each service |

Project names to be verified against the legacy repository (LGCY).

## 19.4 Slice Catalog and Build Order

Every business flow is built as a vertical slice: BFF route → controller → service → domain rules → repository → outbox event → screen → batch follow-up where relevant. Reference data comes before rates, because rates validate codes and locations.

| # | Slice | Depends on | Blocked by |
|---|---|---|---|
| 1 | Foundations: auth and tenancy, error model, versioning, audit, outbox, publication status | — | — |
| 2 | Provider and member reference copies (migration load + events) | 1 | Q-07, Q-11 |
| 3 | Code sets with state edits, maintenance levels, client-sourced events | 1 | Q-23, Q-32, Q-27 (events only) |
| 4 | Pharmacy data: NDC and panels, labelers, GSN, crosswalk | 3 | Q-23 |
| 5 | Provider-specific rates (seven types) with overlap, Insert New and copy | 2, 3 | Q-32, Q-30 |
| 6 | Member-specific rates | 2, 5 | Q-11 |
| 7 | Fee schedules: fields, identifiers, lines, Release Status, copy, uploads | 3 | Q-31 |
| 8 | Groupings, related data, cycles | 1 | — |

# 20. Readiness Evidence

> **Status:** Partial · **Sources:** review checklist · **Feeds:** gate decisions

## 20.1 Readiness Criteria

| Criterion | Status |
|---|---|
| No open Blocker questions (§18.3) | Not met — Q-23, Q-07, Q-11, Q-32 |
| Deviations DV-01 – DV-06 approved or reversed | Not met |
| Every BR has at least one linked test (§14.4) | Not met |
| OpenAPI documents in Appendix B parse and resolve | Met (checked in v6/v7) |
| Appendix K.1 covers all 80 legacy tables | Met |
| DDL exists for every table in §9.2 | Not met — `pm_member`, `pm_member_rate` (Q-11) |
| Review checklist v2 re-run on v8 | Not met |

## 20.2 Evidence

| Evidence | Location | Result | Notes |
|---|---|---|---|
| Review checklist v2 report | `plan-management-target-state-review-checklist-report.md` | Baseline (v5) | Re-run on v8 |
| YAML/JSON contract parse check | v7 validation | 13 blocks parse; all `$ref`s resolve | Re-run on v8 |

# APPENDICES — LOW LEVEL DESIGN

| Appendix | Content | Authoritative for | Status |
|---|---|---|---|
| A | API standards, OpenAPI packaging, batch ingestion | Cross-cutting API rules | Complete |
| B | Domain OpenAPI contracts (B.1–B.9) | Paths, operationIds, schemas | Partial |
| C | BFF composed endpoints | BFF contracts | Partial |
| D | Database schema (DDL) | Tables and columns | Partial — `pm_member`, `pm_member_rate` (Q-11) |
| E | Event contracts | Event names and payloads | Partial — AsyncAPI pending |
| F | External interface specifications | Integration contracts | Partial |
| G | Authorization matrix | Scopes per endpoint | Complete |
| H | Screen specifications | Screens and screen rules | Partial |
| I | Batch and file formats | Import templates | Partial |
| J | Configuration catalog | Settings and flags | Partial |
| K | Legacy inventory and traceability | Legacy table disposition | Complete (K.1) |
| L | Migration, reconciliation and cutover | Cutover steps | Partial |
| M | Known-difference register | Differences from legacy | Pending sign-off |
| N | Glossary and references | Terms | Complete |

## Appendix A — API Standards

### A.1 API Standards

#### A.1.1 Versioning and base paths

- URI versioning: `/v1/...`
- Domain surfaces:
  - `/v1/ndc`
  - `/v1/code-information`
  - `/v1/grouping`
  - `/v1/fee-schedule`
  - `/v1/rate-setting`
  - `/v1/related-information`
  - `/v1/cycle-schedule`

#### A.1.2 Authentication, tenanting, authorization

- `Authorization: Bearer <JWT>` required.
- Tenant and user are derived from JWT claims only; `tenantId`, `TenantId` and `Requestor` fields in request bodies are ignored.
- Authorization is scope-based (Appendix G).

#### A.1.3 Correlation and idempotency

- `X-Correlation-Id` optional inbound; always returned.
- `X-Idempotency-Key` required for endpoints that create or mutate durable state.

#### A.1.4 Error model

- `application/problem+json` (RFC 7807) for non-2xx.
- Validation errors return:
  - `errors: { "<fieldPath>": ["..."] }`

#### A.1.5 Concurrency and maintenance actions

- Every maintained record includes `versionNumber` (int).
- Mutations require `versionNumber` to match the latest stored version.
  - On mismatch: `409 Conflict` with `type = https://errors.gainwell.com/conflict/concurrency`.
- Maintenance actions are action endpoints: `:copy`, `:insert`, `:invalidate` (rates, Appendix B.6), `:validate` / `:invalidate` (groupings, Appendix B.4).
- `changeRequestCode` is required on create, `:copy` and `:insert` (BR-012).
- There are no workflow statuses or approval actions (DD-06).

Standard action payload:

```json
{
  "versionNumber": 7,
  "changeRequestCode": "CR-0001"
}
```

---

### A.2 OpenAPI Packaging

One OpenAPI document per domain (ownership and smaller diffs):
- `ndc.openapi.yaml`
- `code-information.openapi.yaml`
- `grouping.openapi.yaml`
- `fee-schedule.openapi.yaml`
- `rate-setting.openapi.yaml`
- `related-information.openapi.yaml`
- `cycle-schedule.openapi.yaml`
- `platform-status.openapi.yaml`

### A.3 Batch Ingestion

#### A.3.1 Goals

- Replace legacy Batch*.svc upload operations with consistent REST + object storage artifact references.
- Support idempotent ingestion (replay-safe) and safe retries.
- Provide validation feedback without exposing sensitive data.

#### A.3.2 Import orchestration

```mermaid
sequenceDiagram
  autonumber
  participant UI as "Admin UI"
  participant API as "Domain API"
  participant DB as "Tenant DB"
  participant WF as "MWAA Orchestrator"
  participant GL as "Glue Job"
  participant EB as "Event Backbone"

  UI->>API: "POST /v1/<domain>/imports"
  API->>DB: "Insert pm_import_job(submitted)"
  API->>WF: "Start workflow(importId, artifact)"
  WF->>GL: "Run job"
  GL->>DB: "Upsert domain tables"
  GL->>DB: "Update pm_import_job(succeeded/failed)"
  GL->>DB: "Write pm_outbox_event rows"
  API->>EB: "Outbox Relay publishes through the Event Adapter"
```

#### A.3.3 Import status response (minimum)

```json
{
  "importId": "7cbd9c74-7c56-4a77-b62c-41e57b8f2b61",
  "domain": "ndc",
  "status": "succeeded",
  "submittedAt": "2026-10-22T10:00:00Z",
  "startedAt": "2026-10-22T10:01:00Z",
  "completedAt": "2026-10-22T10:05:00Z",
  "summary": {
    "recordsRead": 1000,
    "recordsAccepted": 998,
    "recordsRejected": 2,
    "recordsCreated": 10,
    "recordsUpdated": 988,
    "errors": [
      { "code": "VALIDATION", "count": 2, "message": "Invalid NDC format" }
    ]
  }
}
```

## Appendix B — Domain OpenAPI Contracts

These OpenAPI 3.0 contracts are authoritative for paths, operation ids and payload shapes. Each document is placed in its service folder under `api-specification/` (Part II §19).

- `operationId` values keep the legacy operation names so each target operation can be traced to the legacy behaviour it rebuilds (the `summary` names the legacy operation).
- `tenantId`, `TenantId` and `Requestor` fields in request schemas are kept for shape compatibility only; services ignore them and take tenant and user from the JWT.
- Rate add, edit, copy, insert and invalidate endpoints (§6.3.1) are in B.6; platform endpoints are in B.9 `platform-status.openapi.yaml`.
- The `/events` and `/aggregate-delta` operations are audit-history queries served from `pm_version_history` and the legacy audit archive.

| File | Base route | Service |
| --- | --- | --- |
| `common.openapi.yaml` | — | Shared schemas and responses |
| `ndc.openapi.yaml` | `/v1/ndc` | Code Information |
| `code-information.openapi.yaml` | `/v1/code-information` | Code Information |
| `grouping.openapi.yaml` | `/v1/grouping` | Grouping |
| `fee-schedule.openapi.yaml` | `/v1/fee-schedule` | Rate Setting |
| `rate-setting.openapi.yaml` | `/v1/rate-setting` | Rate Setting |
| `related-information.openapi.yaml` | `/v1/related-information` | Related Information |
| `cycle-schedule.openapi.yaml` | `/v1/cycle-schedule` | Related Information |
| `platform-status.openapi.yaml` | `/v1/rate-setting/publication-status`, `/v1/{area}/imports/{importId}` | Rate Setting (publication status, import status) |

### B.1 `common.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Common Components
  version: 0.1.0
servers:
  - url: /
components:
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT
  responses:
    Problem:
      description: ProblemDetails
      content:
        application/problem+json:
          schema:
            $ref: '#/components/schemas/ProblemDetails'
  schemas:
    PageRequest:
      type: object
      additionalProperties: false
      required: [size]
      properties:
        size:
          type: integer
          minimum: 1
          maximum: 200
        cursor:
          type: string
          nullable: true
    PageResponse:
      type: object
      additionalProperties: false
      required: [nextCursor]
      properties:
        nextCursor:
          type: string
          nullable: true
    ActionRequest:
      type: object
      additionalProperties: false
      required: [versionNumber]
      properties:
        versionNumber:
          type: integer
          minimum: 0
        comment:
          type: string
          nullable: true
          maxLength: 2000
    ImportArtifactRef:
      type: object
      additionalProperties: false
      required: [storage, bucket, key]
      properties:
        storage:
          type: string
          enum: [s3]
        bucket:
          type: string
          minLength: 1
        key:
          type: string
          minLength: 1
    ImportRequest:
      type: object
      additionalProperties: false
      required: [source, artifact, mode]
      properties:
        source:
          type: string
          minLength: 1
        importType:
          type: string
          nullable: true
        artifact:
          $ref: '#/components/schemas/ImportArtifactRef'
        mode:
          type: string
          enum: [upsert, replace]
        dryRun:
          type: boolean
          default: false
    ImportCreatedResponse:
      type: object
      additionalProperties: false
      required: [importId]
      properties:
        importId:
          type: string
          format: uuid
    ImportStatusResponse:
      type: object
      additionalProperties: false
      required: [importId, domain, status, submittedAt]
      properties:
        importId:
          type: string
          format: uuid
        domain:
          type: string
        status:
          type: string
          enum: [submitted, running, succeeded, failed]
        submittedAt:
          type: string
          format: date-time
        startedAt:
          type: string
          format: date-time
          nullable: true
        completedAt:
          type: string
          format: date-time
          nullable: true
        summary:
          type: object
          additionalProperties: true
          nullable: true
    SearchPage:
      type: object
      additionalProperties: false
      required: [currentPage, pageSize, rowCount]
      description: Paging information returned by every search operation.
      properties:
        currentPage: { type: integer, minimum: 1 }
        pageSize: { type: integer, minimum: 1, maximum: 500 }
        rowCount: { type: integer, minimum: 0 }
    ProblemDetails:
      type: object
      additionalProperties: true
      required: [type, title, status]
      properties:
        type: { type: string }
        title: { type: string }
        status: { type: integer }
        detail: { type: string, nullable: true }
        instance: { type: string, nullable: true }
        correlationId: { type: string, nullable: true }
        errors:
          type: object
          nullable: true
          additionalProperties:
            type: array
            items: { type: string }
      example:
        type: https://errors.gainwell.com/validation
        title: Validation failed
        status: 400
        detail: One or more fields are invalid.
        instance: /v1/ndc/search
        correlationId: 2f7d8b8f4b7c4f9db4e2c8c8c9b3a111
        errors:
          effectiveDate: [Effective date is required]

```

### B.2 `ndc.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - NDC Reference API (legacy operationIds)
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/ndc/search:
    post:
      operationId: SearchNationalDrugCode
      summary: 'Legacy: INDCInformationQueryService.SearchNationalDrugCode'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchNationalDrugCodeQueryRequest' }
            example: { CurrentPage: 1, PageSize: 25, SortField: NationalDrugCode, SortDirection: ASC, Where: { NationalDrugCode: '00011122233', IsValid: 'true' } }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchNationalDrugCodeQueryResponse' }
              example: { items: [ { NationalDrugCodeId: '0b1c2d3e-0000-4000-8000-000000000001', NationalDrugCode: '00011122233', NationalDrugCodeDescription: 'SYNTHETICOL 10 MG TABLET', GenericName: 'SYNTHETICOL', BrandName: 'SYNTHBRAND', GSN: '000001', HICL: '000001', IsValid: true, RebateIndicator: false } ], page: { currentPage: 1, pageSize: 25, rowCount: 1 } }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/ndc/search-rates:
    post:
      operationId: SearchNationalDrugCodeRates
      summary: 'Legacy: INDCInformationQueryService.SearchNationalDrugCodeRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/NationalDrugCodeRateQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/NationalDrugCodeRateQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/ndc/{ndc11}:
    get:
      operationId: GetNationalDrugCode
      summary: 'Legacy OData function: GetNationalDrugCode'
      parameters:
        - name: ndc11
          in: path
          required: true
          schema: { type: string, pattern: '^[0-9]{11}$' }
        - name: effectiveOn
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetNationalDrugCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/ndc/imports/national-drug-codes:
    post:
      operationId: UploadNationalDrugCodes
      summary: 'Legacy batch: IBatchNDCInformationService.UploadNationalDrugCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/ndc/imports/drug-classification:
    post:
      operationId: UploadDrugClassification
      summary: 'Legacy batch: IBatchNDCInformationService.UploadDrugClassification'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/ndc/imports/manufacturer:
    post:
      operationId: UploadManufacturer
      summary: 'Legacy batch: IBatchNDCInformationService.UploadManufacturer'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/ndc/imports/national-drug-code-rates:
    post:
      operationId: UploadNationalDrugCodeRates
      summary: 'Legacy batch: IBatchNDCInformationService.UploadNationalDrugCodeRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    FilterCriteriaOfSortEnumerationsNationalDrugCodeRateFieldTypeBem01oYX:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
          enum:
            - RateTypeCode
            - RateAmount
            - EffectiveDate
            - EndDate
            - IsValid
        FilterValue:
          type: object
          additionalProperties: true
        FilterValues:
          type: array
          items:
            type: string
        SearchPattern:
          type: string
          enum:
            - Default
            - EqualTo
            - Contains
            - EndsWith
            - StartsWith
            - NotEqualTo
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    GetNationalDrugCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfNationalDrugCodeFullView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GetNationalDrugCodeQueryParms'
    GetNationalDrugCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AsOfDate:
              type: string
              format: date-time
              nullable: true
            NationalDrugCode:
              type: string
            NationalDrugCodeDescription:
              type: string
            NationalDrugCodeId:
              type: string
            ReturnCMSStatus:
              type: boolean
              nullable: true
            ReturnCODStatus:
              type: boolean
              nullable: true
            ReturnRates:
              type: boolean
              nullable: true
            ReturnRebates:
              type: boolean
              nullable: true
    NationalDrugCodeCMSStatusView:
      type: object
      additionalProperties: false
      properties:
        AddedDate:
          type: string
          format: date-time
          nullable: true
        CMSNDCStatusDateId:
          type: string
          format: uuid
        DateTermReportedDate:
          type: string
          format: date-time
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
          nullable: true
        InactivatedDate:
          type: string
          format: date-time
          nullable: true
        IsValid:
          type: boolean
        LastUpdatedDate:
          type: string
          format: date-time
          nullable: true
        NationalDrugCodeId:
          type: string
          format: uuid
        TerminationDate:
          type: string
          format: date-time
          nullable: true
    NationalDrugCodeCODStatusView:
      type: object
      additionalProperties: false
      properties:
        CODStatus:
          type: string
        EffectiveDate:
          type: string
          format: date-time
          nullable: true
        EndDate:
          type: string
          format: date-time
          nullable: true
        IsValid:
          type: boolean
        NationalDrugCodeCODStatusId:
          type: string
          format: uuid
        NationalDrugCodeId:
          type: string
          format: uuid
        SourceCode:
          type: string
    NationalDrugCodeFullView:
      type: object
      additionalProperties: false
      properties:
        BrandName:
          type: string
        CMSDrugCategory:
          type: string
        CMSStatus:
          type: array
          items:
            $ref: '#/components/schemas/NationalDrugCodeCMSStatusView'
        CODStatuses:
          type: array
          items:
            $ref: '#/components/schemas/NationalDrugCodeCODStatusView'
        CaseSize:
          type: integer
          format: int32
          nullable: true
        ClottingFactorIndicator:
          type: boolean
        DEACode:
          type: string
        DataListItemId:
          type: string
          format: uuid
        DataListItemPeriodId:
          type: string
        DrugForm:
          type: string
        ExternalKey:
          type: string
        GNI:
          type: string
        GSN:
          type: string
        GenericName:
          type: string
        IsValid:
          type: boolean
        LabelerId:
          type: string
        MaintenanceDrug:
          type: string
        NDCClass:
          type: string
        NDCFormat:
          type: string
        NDCPackageSize:
          type: number
          format: double
          nullable: true
        NDCSource:
          type: string
        NDCStatus:
          type: string
        NDDFAddedDate:
          type: string
          format: date-time
        NDDFUpdatedDate:
          type: string
          format: date-time
          nullable: true
        NationalDrugCode:
          type: string
        NationalDrugCodeDescription:
          type: string
        NationalDrugCodeEffectiveDate:
          type: string
          format: date-time
        NationalDrugCodeEndDate:
          type: string
          format: date-time
        NationalDrugCodeId:
          type: string
          format: uuid
        OBC3:
          type: string
        ObsoleteDate:
          type: string
          format: date-time
          nullable: true
        Package:
          type: string
        PackageSize:
          type: number
          format: double
          nullable: true
        PediatricIndicator:
          type: boolean
        PreviousNDC:
          type: string
        Rates:
          type: array
          items:
            $ref: '#/components/schemas/NationalDrugCodeRateView'
        Rebates:
          type: array
          items:
            $ref: '#/components/schemas/NationalDrugCodeRebateView'
        ReplacementNDC:
          type: string
        Reused:
          type: string
        ShelfPack:
          type: integer
          format: int32
          nullable: true
        ShipperQuantity:
          type: integer
          format: int32
          nullable: true
        StandardPackage:
          type: string
        Suffix:
          type: string
        TerminationDate:
          type: string
          format: date-time
        TherapeuticEquivalency:
          type: string
        UnitDose:
          type: string
        UnitOfUse:
          type: string
        UpdatedIndicator:
          type: string
    NationalDrugCodePartialView:
      type: object
      additionalProperties: false
      properties:
        BrandName:
          type: string
        DataListItemId:
          type: string
          format: uuid
        GSN:
          type: string
        GenericName:
          type: string
        HICL:
          type: string
        IsValid:
          type: boolean
        NationalDrugCode:
          type: string
        NationalDrugCodeDescription:
          type: string
        NationalDrugCodeId:
          type: string
          format: uuid
        RebateIndicator:
          type: boolean
    NationalDrugCodeRateFilter:
      allOf:
        -
          $ref: '#/components/schemas/FilterCriteriaOfSortEnumerationsNationalDrugCodeRateFieldTypeBem01oYX'
        -
          type: object
          additionalProperties: false
          properties: {}
    NationalDrugCodeRateQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfNationalDrugCodeRateView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/NationalDrugCodeRateQueryParms'
    NationalDrugCodeRateQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/NationalDrugCodeRateQuery' }

    NationalDrugCodeRateQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/NationalDrugCodeRateView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    NationalDrugCodeRateQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            NationalDrugCodeId:
              type: string
            NationalDrugCodeRateFilters:
              type: array
              items:
                $ref: '#/components/schemas/NationalDrugCodeRateFilter'
    NationalDrugCodeRateView:
      type: object
      additionalProperties: false
      properties:
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
        NationalDrugCodeId:
          type: string
          format: uuid
        NationalDrugCodeRateId:
          type: string
          format: uuid
        RateAmount:
          type: number
          format: double
        RateTypeCode:
          type: string
    NationalDrugCodeRebateView:
      type: object
      additionalProperties: false
      properties:
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        IsValid:
          type: boolean
        NationalDrugCodeId:
          type: string
          format: uuid
        NationalDrugCodeRebateId:
          type: string
          format: uuid
        RebateIndicator:
          type: boolean
    Query:
      type: object
      additionalProperties: false
      properties:
        ByPassCountQuery:
          type: boolean
        CurrentPage:
          type: integer
          format: int32
        CycleDate:
          type: string
          format: date-time
          nullable: true
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfNationalDrugCodeFullView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/NationalDrugCodeFullView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfNationalDrugCodePartialView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/NationalDrugCodePartialView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfNationalDrugCodeRateView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/NationalDrugCodeRateView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    SearchFieldsSearchPattern:
      type: string
      enum:
        - Default
        - EqualTo
        - Contains
        - EndsWith
        - StartsWith
        - NotEqualTo
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
    SearchNationalDrugCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfNationalDrugCodePartialView'
        -
          type: object
          additionalProperties: false
          properties:
            SortDirection:
              type: string
              enum:
                - ASC
                - DESC
            SortField:
              type: string
              enum:
                - Default
                - NationalDrugCodeDescription
                - NationalDrugCode
                - GenericName
                - GSN
                - HICL
                - BrandName
                - IsValid
                - RebateIndicator
            Where:
              $ref: '#/components/schemas/SearchNationalDrugCodeQueryParms'
    SearchNationalDrugCodeQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchNationalDrugCodeQuery' }

    SearchNationalDrugCodeQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/NationalDrugCodePartialView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchNationalDrugCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            BrandName:
              type: string
            BrandNameAdvancedCriteria:
              type: string
            FilterBrandName:
              type: string
            FilterBrandNameSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterGSN:
              type: string
            FilterGSNSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterGenericName:
              type: string
            FilterGenericNameSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterHICL:
              type: string
            FilterHICLSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterNationalDrugCode:
              type: string
            FilterNationalDrugCodeDescription:
              type: string
            FilterNationalDrugCodeDescriptionSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterNationalDrugCodeSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            GSN:
              type: string
            GenericName:
              type: string
            GenericNameAdvancedCriteria:
              type: string
            HICL:
              type: string
            IsValid:
              type: string
            NationalDrugCode:
              type: string
            NationalDrugCodeAdvanceCriteria:
              type: string
            NationalDrugCodeDescription:
              type: string
            NationalDrugCodeDescriptionAdvancedCriteria:
              type: string
            RebateIndicator:
              type: string
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortEnumerationsNationalDrugCodeFieldType:
      type: string
      enum:
        - Default
        - NationalDrugCodeDescription
        - NationalDrugCode
        - GenericName
        - GSN
        - HICL
        - BrandName
        - IsValid
        - RebateIndicator
    SortEnumerationsNationalDrugCodeRateFieldType:
      type: string
      enum:
        - RateTypeCode
        - RateAmount
        - EffectiveDate
        - EndDate
        - IsValid
    SortEnumerationsSortDirectionType:
      type: string
      enum:
        - ASC
        - DESC
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
    WhereOperatorEnumerationsSearchModeType:
      type: string
      enum:
        - EqualTo
        - Contains
        - StartsWith
        - EndsWith
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
```

### B.3 `code-information.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Code Information API (legacy operationIds)
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/code-information/hcpcs/{code}:
    get:
      operationId: GetHCPCSCode
      summary: 'Legacy: ICodeInformationQueryService.GetHCPCSCode / OData GetHCPCSCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetHCPCSCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/icd9-diagnosis/{code}:
    get:
      operationId: GetICD9DiagnosisCode
      summary: 'Legacy: ICodeInformationQueryService.GetICD9DiagnosisCode / OData GetICD9DiagnosisCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetICD9DiagnosisCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/icd10-diagnosis/{code}:
    get:
      operationId: GetICD10DiagnosisCode
      summary: 'Legacy: ICodeInformationQueryService.GetICD10DiagnosisCode / OData GetICD10DiagnosisCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetICD10DiagnosisCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/icd9-procedure/{code}:
    get:
      operationId: GetICD9ProcedureCode
      summary: 'Legacy: ICodeInformationQueryService.GetICD9ProcedureCode / OData GetICD9ProcedureCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetICD9ProcedureCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/icd10-procedure/{code}:
    get:
      operationId: GetICD10ProcedureCode
      summary: 'Legacy: ICodeInformationQueryService.GetICD10ProcedureCode / OData GetICD10ProcedureCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetICD10ProcedureCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/drg/{code}:
    get:
      operationId: GetDRGCode
      summary: 'Legacy: ICodeInformationQueryService.GetDRGCode / OData GetDRGCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetDRGCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/revenue/{code}:
    get:
      operationId: GetRevenueCode
      summary: 'Legacy: ICodeInformationQueryService.GetRevenueCode / OData GetRevenueCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetRevenueCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/dental/{code}:
    get:
      operationId: GetDentalCode
      summary: 'Legacy: ICodeInformationQueryService.GetDentalCode / OData GetDentalCode'
      parameters:
        - name: code
          in: path
          required: true
          schema: { type: string, minLength: 1, maxLength: 50 }
        - name: effectiveDate
          in: query
          required: false
          schema: { type: string, format: date }
        - name: endDate
          in: query
          required: false
          schema: { type: string, format: date }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetDentalCodeQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/hcpcs-ndc-association/search:
    post:
      operationId: SearchHCPCSNDCASSCN
      summary: 'Legacy: ICodeInformationQueryService.SearchHCPCSNDCASSCN'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchHCPCSNDCASSCNQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchHCPCSNDCASSCNQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/events:
    post:
      operationId: GetCodeInformationEvents
      summary: 'Legacy: ICodeInformationQueryService.GetCodeInformationEvents'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CodeInformationEventQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CodeInformationEventQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/aggregate-delta:
    post:
      operationId: GetCodeInformationAggregateDelta
      summary: 'Legacy: ICodeInformationQueryService.GetCodeInformationAggregateDelta'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CodeInformationAggregateDeltaQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CodeInformationAggregateDeltaQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/hcpcs-ndc-association/events:
    post:
      operationId: GetHCPCSNDCAssociationEvents
      summary: 'Legacy: ICodeInformationQueryService.GetHCPCSNDCAssociationEvents'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/HCPCSNDCAssociationEventQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/HCPCSNDCAssociationEventQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/hcpcs-ndc-association/aggregate-delta:
    post:
      operationId: GetHCPCSNDCAssociationAggregateDelta
      summary: 'Legacy: ICodeInformationQueryService.GetHCPCSNDCAssociationAggregateDelta'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/HCPCSNDCAssociationAggregateDeltaQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/HCPCSNDCAssociationAggregateDeltaQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/code-information/imports/hcpcs:
    post:
      operationId: UploadHCPCSCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadHCPCSCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/icd9-diagnosis:
    post:
      operationId: UploadICD9DiagnosisCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadICD9DiagnosisCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/icd9-procedure:
    post:
      operationId: UploadICD9ProcedureCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadICD9ProcedureCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/icd10-diagnosis:
    post:
      operationId: UploadICD10DiagnosisCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadICD10DiagnosisCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/icd10-procedure:
    post:
      operationId: UploadICD10ProcedureCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadICD10ProcedureCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/dental:
    post:
      operationId: UploadDentalCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadDentalCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/revenue:
    post:
      operationId: UploadRevenueCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadRevenueCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/hcpcs-ndc-association:
    post:
      operationId: UploadHCPCSNDCASSCNs
      summary: 'Legacy batch: IBatchCodeInformationService.UploadHCPCSNDCASSCNs'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/code-information/imports/drg:
    post:
      operationId: UploadDRGCodes
      summary: 'Legacy batch: IBatchCodeInformationService.UploadDRGCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    AuditEnumerationsEventAuditSortFieldType:
      type: string
      enum:
        - Default
        - EventStampDate
        - EventType
        - UserId
        - SourceOfChange
    AuditEventModel:
      type: object
      additionalProperties: false
      properties:
        AuditEvent:
          type: string
        AuditId:
          type: string
        CommitId:
          type: string
          format: uuid
        CommitTimestamp:
          type: string
          format: date-time
        EventTypeName:
          type: string
        SourceOfChange:
          type: string
        UserId:
          type: string
    AuditKeyModel:
      type: object
      additionalProperties: false
      properties:
        KeyFullName:
          type: string
        KeyName:
          type: string
        KeyValue:
          type: string
        PropertyDisplayDataListName:
          type: string
        PropertyDisplayName:
          type: string
    AuditObjectDifferenceModel:
      type: object
      additionalProperties: false
      properties:
        DisplayAfterValue:
          type: string
        DisplayBeforeValue:
          type: string
        IsAuditKey:
          type: boolean
        PropertyDisplayDatalistName:
          type: string
        PropertyDisplayName:
          type: string
        PropertyFullName:
          type: string
        PropertyName:
          type: string
    AuditObjectModel:
      type: object
      additionalProperties: false
      properties:
        AggregatePath:
          type: string
        AuditKeys:
          type: array
          items:
            $ref: '#/components/schemas/AuditKeyModel'
        Differences:
          type: array
          items:
            $ref: '#/components/schemas/AuditObjectDifferenceModel'
        ObjectFullName:
          type: string
        ObjectName:
          type: string
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    CodeInformationAggregateDeltaQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditObjectModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/CodeInformationAggregateDeltaQueryParms'
    CodeInformationAggregateDeltaQueryParms:
      type: object
      additionalProperties: false
      properties:
        CodeId:
          type: string
        CodeType:
          type: string
        CommitId:
          type: string
          format: uuid
    CodeInformationEventQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditEventModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/CodeInformationEventQueryParms'
    CodeInformationEventQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AuditWhere:
              $ref: '#/components/schemas/EventQueryParams'
            CodeType:
              type: string
            DataListItemId:
              type: string
            SortDirection:
              type: string
              enum:
                - Ascending
                - Descending
            SortField:
              type: string
              enum:
                - Default
                - EventStampDate
                - EventType
                - UserId
                - SourceOfChange
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    CoreEnumerationsMessagingSearchModeType:
      type: string
      enum:
        - EqualTo
        - NotEqualTo
        - Contains
        - StartsWith
        - EndsWith
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
    CoreEnumerationsMessagingSortDirectionType:
      type: string
      enum:
        - Ascending
        - Descending
    DRGCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            DataListItemId:
              type: string
            IsValid:
              type: boolean
            VOSIsValid:
              type: boolean
    DRGCodeRestrictionView:
      type: object
      additionalProperties: false
      properties:
        CostOutlierAmount:
          type: number
          format: double
          nullable: true
        CostOutlierPercentage:
          type: number
          format: double
          nullable: true
        DRGCodeId:
          type: string
          format: uuid
        DRGCodeRestrictionId:
          type: string
          format: uuid
        DayOutlierMaximum:
          type: object
          additionalProperties: true
          nullable: true
        DayOutlierMinimum:
          type: object
          additionalProperties: true
          nullable: true
        DayOutlierPercentage:
          type: number
          format: double
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        RelativeWeight:
          type: number
          format: double
          nullable: true
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    DRGCodeView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        Code:
          type: string
        CodeDescription:
          type: string
        CodeEffectiveDate:
          type: string
          format: date-time
          nullable: true
        CodeEndDate:
          type: string
          format: date-time
          nullable: true
        CodeLongDescription:
          type: string
        DRGCodeId:
          type: string
          format: uuid
        DRGCodeLanguages:
          type: array
          items:
            $ref: '#/components/schemas/DataListItemLanguageView'
        DRGCodeRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/DRGCodeRestrictionView'
        DataListItemId:
          type: string
        DataListItemPeriodId:
          type: string
        LastModified:
          type: string
          format: date-time
        ReplacementCode:
          type: string
        ReplacementCodeDescription:
          type: string
    DataListItemLanguageView:
      type: object
      additionalProperties: false
      properties:
        Description:
          type: string
        IsActive:
          type: boolean
        LocaleId:
          type: string
        LongDescription:
          type: string
    DentalCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            DataListItemId:
              type: string
            DentalCode:
              type: string
            IsValid:
              type: boolean
            VOSIsValid:
              type: boolean
    DentalCodeRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AgeMaximum:
          type: object
          additionalProperties: true
          nullable: true
        AgeMinimum:
          type: object
          additionalProperties: true
          nullable: true
        DentalCodeId:
          type: string
          format: uuid
        DentalCodeRestrictionId:
          type: string
          format: uuid
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        Gender:
          type: string
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsPreDProcedure:
          type: boolean
        IsValid:
          type: boolean
        IsXrayRequired:
          type: boolean
        LastModified:
          type: string
          format: date-time
        PlaceOfServiceCodes:
          type: array
          items:
            type: string
        PlaceOfServiceGroupId:
          type: string
          format: uuid
          nullable: true
        PlaceOfServiceGroupName:
          type: string
        PlaceOfServiceType:
          type: string
        Quadrants:
          type: array
          items:
            type: string
        ToothNumberGroupId:
          type: string
          format: uuid
          nullable: true
        ToothNumberGroupName:
          type: string
        ToothNumberType:
          type: string
        ToothNumbers:
          type: array
          items:
            type: string
        ToothSurfaceGroupId:
          type: string
          format: uuid
          nullable: true
        ToothSurfaceGroupName:
          type: string
        ToothSurfaceMaximum:
          type: object
          additionalProperties: true
          nullable: true
        ToothSurfaceMinimum:
          type: object
          additionalProperties: true
          nullable: true
        ToothSurfaceType:
          type: string
        ToothSurfaces:
          type: array
          items:
            type: string
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    DentalCodeView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        Code:
          type: string
        CodeDescription:
          type: string
        CodeEffectiveDate:
          type: string
          format: date-time
          nullable: true
        CodeEndDate:
          type: string
          format: date-time
          nullable: true
        CodeLongDescription:
          type: string
        DataListItemId:
          type: string
        DataListItemPeriodId:
          type: string
        DentalCodeId:
          type: string
          format: uuid
        DentalCodeLanguages:
          type: array
          items:
            $ref: '#/components/schemas/DataListItemLanguageView'
        DentalCodeRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/DentalCodeRestrictionView'
        LastModified:
          type: string
          format: date-time
        ReplacementCode:
          type: string
        ReplacementCodeDescription:
          type: string
    DiagnosisCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            DataListItemId:
              type: string
            DiagnosisCode:
              type: string
            IsValid:
              type: boolean
            VOSIsValid:
              type: boolean
    DiagnosisCodeRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AgeMaximum:
          type: object
          additionalProperties: true
          nullable: true
        AgeMinimum:
          type: object
          additionalProperties: true
          nullable: true
        DiagnosisCodeId:
          type: string
          format: uuid
        DiagnosisCodeRestrictionId:
          type: string
          format: uuid
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        Gender:
          type: string
        IsClassification:
          type: boolean
        IsEditable:
          type: boolean
        IsEmergency:
          type: boolean
        IsEndDated:
          type: boolean
        IsFamilyPlanning:
          type: boolean
        IsPregnancy:
          type: boolean
        IsPrimary:
          type: boolean
        IsTPL:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    DiagnosisCodeView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        Code:
          type: string
        CodeDescription:
          type: string
        CodeEffectiveDate:
          type: string
          format: date-time
          nullable: true
        CodeEndDate:
          type: string
          format: date-time
          nullable: true
        CodeLongDescription:
          type: string
        DataListItemId:
          type: string
        DataListItemPeriodId:
          type: string
        DiagnosisCodeId:
          type: string
          format: uuid
        DiagnosisCodeLanguages:
          type: array
          items:
            $ref: '#/components/schemas/DataListItemLanguageView'
        DiagnosisRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/DiagnosisCodeRestrictionView'
        LastModified:
          type: string
          format: date-time
    EventQueryParams:
      type: object
      additionalProperties: false
      properties:
        EventStampDate:
          type: string
          format: date-time
          nullable: true
        EventStampDateSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        EventType:
          type: string
        EventTypeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        SourceOfChange:
          type: string
        SourceOfChangeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        UserId:
          type: string
        UserIdSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    GetDRGCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfDRGCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/DRGCodeQueryParms'
    GetDentalCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfDentalCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/DentalCodeQueryParms'
    GetHCPCSCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfHCPCSCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/HCPCSCodeQueryParms'
    GetICD10DiagnosisCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfDiagnosisCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/DiagnosisCodeQueryParms'
    GetICD10ProcedureCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfProcedureCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ProcedureCodeQueryParms'
    GetICD9DiagnosisCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfDiagnosisCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/DiagnosisCodeQueryParms'
    GetICD9ProcedureCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfProcedureCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ProcedureCodeQueryParms'
    GetRevenueCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfRevenueCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/RevenueCodeQueryParms'
    HCPCSCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            DataListItemId:
              type: string
            HCPCSCode:
              type: string
            IsValid:
              type: boolean
            VOSIsValid:
              type: boolean
    HCPCSCodeRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AgeMaximum:
          type: object
          additionalProperties: true
          nullable: true
        AgeMinimum:
          type: object
          additionalProperties: true
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionError:
          type: string
        Gender:
          type: string
        HCPCSCodeId:
          type: string
          format: uuid
        HCPCSCodeRestrictionId:
          type: string
          format: uuid
        ICD10DiagnosisCodes:
          type: array
          items:
            type: string
        ICD10DiagnosisGroupId:
          type: string
          format: uuid
          nullable: true
        ICD10DiagnosisGroupName:
          type: string
        ICD10DiagnosisType:
          type: string
        ICD9DiagnosisCodes:
          type: array
          items:
            type: string
        ICD9DiagnosisGroupId:
          type: string
          format: uuid
          nullable: true
        ICD9DiagnosisGroupName:
          type: string
        ICD9DiagnosisType:
          type: string
        IsAssistantSurgeon:
          type: boolean
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        MedicareCoverage:
          type: string
        ModifierGroupId:
          type: string
          format: uuid
          nullable: true
        ModifierGroupName:
          type: string
        ModifierType:
          type: string
        Modifiers:
          type: array
          items:
            type: string
        PlaceOfServiceCodes:
          type: array
          items:
            type: string
        PlaceOfServiceGroupId:
          type: string
          format: uuid
          nullable: true
        PlaceOfServiceGroupName:
          type: string
        PlaceOfServiceType:
          type: string
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    HCPCSCodeView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        Code:
          type: string
        CodeDescription:
          type: string
        CodeEffectiveDate:
          type: string
          format: date-time
          nullable: true
        CodeEndDate:
          type: string
          format: date-time
          nullable: true
        CodeLongDescription:
          type: string
        DataListItemId:
          type: string
        DataListItemPeriodId:
          type: string
        HCPCSCodeId:
          type: string
          format: uuid
        HCPCSCodeLanguages:
          type: array
          items:
            $ref: '#/components/schemas/DataListItemLanguageView'
        HCPCSCodeRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/HCPCSCodeRestrictionView'
        LastModified:
          type: string
          format: date-time
        ReplacementCode:
          type: string
        ReplacementCodeDescription:
          type: string
    HCPCSNDCASSCNView:
      type: object
      additionalProperties: false
      properties:
        ConversionFactor:
          type: number
          format: double
          nullable: true
        DateAdded:
          type: string
          format: date-time
          nullable: true
        DateInactivated:
          type: string
          format: date-time
          nullable: true
        DateUpdated:
          type: string
          format: date-time
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        GSN:
          type: string
        HCPCSCode:
          type: string
        HCPCSCodeDescription:
          type: string
        HCPCSCodeId:
          type: string
          format: uuid
        HCPCSNDCASSCNId:
          type: string
          format: uuid
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsNDCRequired:
          type: boolean
        IsValid:
          type: boolean
        NationalDrugCode:
          type: string
        NationalDrugCodeDescription:
          type: string
        NationalDrugCodeId:
          type: string
          format: uuid
        Source:
          type: string
    HCPCSNDCAssociationAggregateDeltaQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditObjectModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/HCPCSNDCAssociationAggregateDeltaQueryParms'
    HCPCSNDCAssociationAggregateDeltaQueryParms:
      type: object
      additionalProperties: false
      properties:
        CommitId:
          type: string
          format: uuid
        HCPCSNDCAssociationId:
          type: string
    HCPCSNDCAssociationEventQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditEventModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/HCPCSNDCAssociationEventQueryParms'
    HCPCSNDCAssociationEventQueryParms:
      type: object
      additionalProperties: false
      properties:
        AuditWhere:
          $ref: '#/components/schemas/EventQueryParams'
        HCPCSNDCAssociationId:
          type: string
        SortDirection:
          type: string
          enum:
            - Ascending
            - Descending
        SortField:
          type: string
          enum:
            - Default
            - EventStampDate
            - EventType
            - UserId
            - SourceOfChange
    ProcedureCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            DataListItemId:
              type: string
            IsValid:
              type: boolean
            ProcedureCode:
              type: string
            VOSIsValid:
              type: boolean
    ProcedureCodeRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AgeMaximum:
          type: object
          additionalProperties: true
          nullable: true
        AgeMinimum:
          type: object
          additionalProperties: true
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        Gender:
          type: string
        IsCoverage:
          type: boolean
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsNonspecific:
          type: boolean
        IsOperatingRoom:
          type: boolean
        IsReview:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        ProcedureCodeId:
          type: string
          format: uuid
        ProcedureCodeRestrictionId:
          type: string
          format: uuid
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    ProcedureCodeView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        Code:
          type: string
        CodeDescription:
          type: string
        CodeEffectiveDate:
          type: string
          format: date-time
          nullable: true
        CodeEndDate:
          type: string
          format: date-time
          nullable: true
        CodeLongDescription:
          type: string
        DataListItemId:
          type: string
        DataListItemPeriodId:
          type: string
        LastModified:
          type: string
          format: date-time
        ProcedureCodeId:
          type: string
          format: uuid
        ProcedureCodeLanguages:
          type: array
          items:
            $ref: '#/components/schemas/DataListItemLanguageView'
        ProcedureRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/ProcedureCodeRestrictionView'
    Query:
      type: object
      additionalProperties: false
      properties:
        ByPassCountQuery:
          type: boolean
        CurrentPage:
          type: integer
          format: int32
        CycleDate:
          type: string
          format: date-time
          nullable: true
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfAuditEventModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditEventModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfAuditObjectModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditObjectModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfDRGCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/DRGCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfDentalCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/DentalCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfDiagnosisCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/DiagnosisCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfHCPCSCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/HCPCSCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfHCPCSNDCASSCNView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/HCPCSNDCASSCNView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfProcedureCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ProcedureCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfRevenueCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/RevenueCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    RevenueCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            DataListItemId:
              type: string
            IsValid:
              type: boolean
            RevenueCode:
              type: string
            VOSIsValid:
              type: boolean
    RevenueCodeRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AgeMaximum:
          type: object
          additionalProperties: true
          nullable: true
        AgeMinimum:
          type: object
          additionalProperties: true
          nullable: true
        BillType:
          type: string
        BillTypeCodes:
          type: array
          items:
            type: string
        BillTypeGroupId:
          type: string
          format: uuid
          nullable: true
        BillTypeGroupName:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionError:
          type: string
        Gender:
          type: string
        HCPCSCodes:
          type: array
          items:
            type: string
        HCPCSGroupId:
          type: string
          format: uuid
          nullable: true
        HCPCSGroupName:
          type: string
        HCPCSType:
          type: string
        ICD10DiagnosisCodes:
          type: array
          items:
            type: string
        ICD10DiagnosisGroupId:
          type: string
          format: uuid
          nullable: true
        ICD10DiagnosisGroupName:
          type: string
        ICD10DiagnosisType:
          type: string
        ICD10ProcedureCodes:
          type: array
          items:
            type: string
        ICD10ProcedureGroupId:
          type: string
          format: uuid
          nullable: true
        ICD10ProcedureGroupName:
          type: string
        ICD10ProcedureType:
          type: string
        ICD9DiagnosisCodes:
          type: array
          items:
            type: string
        ICD9DiagnosisGroupId:
          type: string
          format: uuid
          nullable: true
        ICD9DiagnosisGroupName:
          type: string
        ICD9DiagnosisType:
          type: string
        ICD9ProcedureCodes:
          type: array
          items:
            type: string
        ICD9ProcedureGroupId:
          type: string
          format: uuid
          nullable: true
        ICD9ProcedureGroupName:
          type: string
        ICD9ProcedureType:
          type: string
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsSurgeryRelated:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        RevenueCodeId:
          type: string
          format: uuid
        RevenueCodeRestrictionId:
          type: string
          format: uuid
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    RevenueCodeView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        Code:
          type: string
        CodeDescription:
          type: string
        CodeEffectiveDate:
          type: string
          format: date-time
          nullable: true
        CodeEndDate:
          type: string
          format: date-time
          nullable: true
        CodeLongDescription:
          type: string
        DataListItemId:
          type: string
        DataListItemPeriodId:
          type: string
        LastModified:
          type: string
          format: date-time
        ReplacementCode:
          type: string
        ReplacementCodeDescription:
          type: string
        RevenueCodeId:
          type: string
          format: uuid
        RevenueCodeLanguages:
          type: array
          items:
            $ref: '#/components/schemas/DataListItemLanguageView'
        RevenueCodeRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/RevenueCodeRestrictionView'
    SearchHCPCSNDCASSCNQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfHCPCSNDCASSCNView'
        -
          type: object
          additionalProperties: false
          properties:
            SortDirection:
              type: string
              enum:
                - ASC
                - DESC
            SortField:
              type: string
              enum:
                - Default
                - HCPCSCode
                - NationalDrugCodeDescription
                - NationalDrugCode
                - IsNDCRequired
                - IsValid
                - GSN
                - ConversionFactor
                - EffectiveDate
                - EndDate
                - DateAdded
                - DateUpdated
                - DateInactivated
                - Source
            Where:
              $ref: '#/components/schemas/SearchHCPCSNDCASSCNQueryParms'
    SearchHCPCSNDCASSCNQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchHCPCSNDCASSCNQuery' }

    SearchHCPCSNDCASSCNQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/HCPCSNDCASSCNView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchHCPCSNDCASSCNQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            FilterConversionFactor:
              type: number
              format: double
              nullable: true
            FilterConversionFactorSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterDateAdded:
              type: string
              format: date-time
              nullable: true
            FilterDateAddedSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterDateUpdated:
              type: string
              format: date-time
              nullable: true
            FilterDateUpdatedSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterEffectiveDate:
              type: string
              format: date-time
              nullable: true
            FilterEffectiveDateSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterEndDate:
              type: string
              format: date-time
              nullable: true
            FilterEndDateSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterGSN:
              type: string
            FilterGSNSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterHCPCSCode:
              type: string
            FilterHCPCSCodeSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterIsValidSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterIsvalid:
              type: boolean
              nullable: true
            FilterNDCRequired:
              type: boolean
              nullable: true
            FilterNDCRequiredSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterNationalDrugCode:
              type: string
            FilterNationalDrugCodeSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            FilterSourceCode:
              type: string
            FilterSourceCodeSearchMode:
              type: string
              enum:
                - EqualTo
                - Contains
                - StartsWith
                - EndsWith
                - GreaterThanOrEqualTo
                - LessThanOrEqualTo
              nullable: true
            GSN:
              type: string
            HCPCSCode:
              type: string
            HCPCSNDCASSCNId:
              type: string
            IsValid:
              type: boolean
            NationalDrugCode:
              type: string
            NationalDrugCodeDescription:
              type: string
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortEnumerationsHCPCSNDCASSCNFieldType:
      type: string
      enum:
        - Default
        - HCPCSCode
        - NationalDrugCodeDescription
        - NationalDrugCode
        - IsNDCRequired
        - IsValid
        - GSN
        - ConversionFactor
        - EffectiveDate
        - EndDate
        - DateAdded
        - DateUpdated
        - DateInactivated
        - Source
    SortEnumerationsSortDirectionType:
      type: string
      enum:
        - ASC
        - DESC
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
    VOSTagView:
      type: object
      additionalProperties: false
      properties:
        EntityId:
          type: string
          format: uuid
        EntityType:
          type: string
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        TagCode:
          type: string
        TagTypeCode:
          type: string
        VOSEffectiveDate:
          type: string
          format: date-time
        VOSEndDate:
          type: string
          format: date-time
        VOSTagId:
          type: string
          format: uuid
    WhereOperatorEnumerationsSearchModeType:
      type: string
      enum:
        - EqualTo
        - Contains
        - StartsWith
        - EndsWith
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
```

### B.4 `grouping.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Grouping API (legacy operationIds)
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/grouping/search:
    post:
      operationId: SearchGroupings
      summary: 'Legacy: IGroupingQueryService.SearchGroupings / OData SearchGroupings'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchGroupingQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchGroupingQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/name/search:
    post:
      operationId: SearchGroupingName
      summary: 'Legacy: IGroupingQueryService.SearchGroupingName'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchGroupingNameQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchGroupingNameQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/items/search:
    post:
      operationId: SearchGroupingItems
      summary: 'Legacy: IGroupingQueryService.SearchGroupingItems'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchGroupingItemQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchGroupingItemQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping:
    post:
      operationId: AddGroup
      summary: 'Legacy: IGroupingService.AddGroup'
      parameters:
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/AddGroupingCommand' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GroupingAdded' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/{groupId}:
    patch:
      operationId: UpdateGroup
      summary: 'Legacy: IGroupingService.UpdateGroup'
      parameters:
        - name: groupId
          in: path
          required: true
          schema: { type: string, format: uuid }
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/UpdateGroupingCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GroupingUpdated' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/{groupId}:invalidate:
    post:
      operationId: InvalidateGroup
      summary: 'Legacy: IGroupingService.InvalidateGroup'
      parameters:
        - name: groupId
          in: path
          required: true
          schema: { type: string, format: uuid }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/InvalidateGroupingCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GroupingInvalidated' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/{groupId}:validate:
    post:
      operationId: ValidateGroup
      summary: 'Legacy: IGroupingService.ValidateGroup'
      parameters:
        - name: groupId
          in: path
          required: true
          schema: { type: string, format: uuid }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ValidateGroupingCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GroupingValidated' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/events:
    post:
      operationId: GetGroupingEvents
      summary: 'Legacy: IGroupingQueryService.GetGroupingEvents'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/GroupingEventQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GroupingEventQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/aggregate-delta:
    post:
      operationId: GetGroupingAggregateDelta
      summary: 'Legacy: IGroupingQueryService.GetGroupingAggregateDelta'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchGroupingAggregateDeltaQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchGroupingAggregateDeltaQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/code-exists:
    post:
      operationId: CodeExistsWithinGrouping
      summary: 'Legacy OData function: CodeExistsWithinGrouping'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CodeExistsWithinGroupingRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CodeExistsWithinGroupingResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/grouping/batch/upload:
    post:
      operationId: UploadGrouping
      summary: 'Legacy batch: IBatchGroupingService.UploadGrouping'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    CodeExistsWithinGroupingRequest:
      type: object
      additionalProperties: false
      required: [groupName, code, asOfDate]
      properties:
        groupName: { type: string, minLength: 1 }
        code: { type: string, minLength: 1 }
        asOfDate: { type: string, format: date }
    CodeExistsWithinGroupingResponse:
      type: object
      additionalProperties: false
      required: [exists]
      properties:
        exists: { type: boolean }
    AddGroupingCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    AuditEnumerationsEventAuditSortFieldType:
      type: string
      enum:
        - Default
        - EventStampDate
        - EventType
        - UserId
        - SourceOfChange
    AuditEventModel:
      type: object
      additionalProperties: false
      properties:
        AuditEvent:
          type: string
        AuditId:
          type: string
        CommitId:
          type: string
          format: uuid
        CommitTimestamp:
          type: string
          format: date-time
        EventTypeName:
          type: string
        SourceOfChange:
          type: string
        UserId:
          type: string
    AuditKeyModel:
      type: object
      additionalProperties: false
      properties:
        KeyFullName:
          type: string
        KeyName:
          type: string
        KeyValue:
          type: string
        PropertyDisplayDataListName:
          type: string
        PropertyDisplayName:
          type: string
    AuditObjectDifferenceModel:
      type: object
      additionalProperties: false
      properties:
        DisplayAfterValue:
          type: string
        DisplayBeforeValue:
          type: string
        IsAuditKey:
          type: boolean
        PropertyDisplayDatalistName:
          type: string
        PropertyDisplayName:
          type: string
        PropertyFullName:
          type: string
        PropertyName:
          type: string
    AuditObjectModel:
      type: object
      additionalProperties: false
      properties:
        AggregatePath:
          type: string
        AuditKeys:
          type: array
          items:
            $ref: '#/components/schemas/AuditKeyModel'
        Differences:
          type: array
          items:
            $ref: '#/components/schemas/AuditObjectDifferenceModel'
        ObjectFullName:
          type: string
        ObjectName:
          type: string
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    Command:
      type: object
      additionalProperties: false
      properties:
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        ViewTimeStamp:
          type: string
          format: date-time
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    CoreEnumerationsMessagingSearchModeType:
      type: string
      enum:
        - EqualTo
        - NotEqualTo
        - Contains
        - StartsWith
        - EndsWith
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
    CoreEnumerationsMessagingSortDirectionType:
      type: string
      enum:
        - Ascending
        - Descending
    Event:
      type: object
      additionalProperties: false
      properties:
        ApplicationName:
          type: string
        CommitId:
          type: string
          format: uuid
          nullable: true
        CorrelationId:
          type: string
        EventID:
          type: string
        ModelID:
          type: string
        ModelType:
          type: string
        Timestamp:
          type: string
          format: date-time
          nullable: true
        UserID:
          type: string
        UserIp:
          type: string
    EventQueryParams:
      type: object
      additionalProperties: false
      properties:
        EventStampDate:
          type: string
          format: date-time
          nullable: true
        EventStampDateSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        EventType:
          type: string
        EventTypeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        SourceOfChange:
          type: string
        SourceOfChangeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        UserId:
          type: string
        UserIdSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    GroupingAdded:
      allOf:
        -
          $ref: '#/components/schemas/GroupingEvents'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    GroupingEventQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditEventModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GroupingEventQueryParams'
    GroupingEventQueryParams:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AuditWhere:
              $ref: '#/components/schemas/EventQueryParams'
            GroupId:
              type: string
            SortDirection:
              type: string
              enum:
                - Ascending
                - Descending
            SortField:
              type: string
              enum:
                - Default
                - EventStampDate
                - EventType
                - UserId
                - SourceOfChange
    GroupingEvents:
      allOf:
        -
          $ref: '#/components/schemas/Event'
        -
          type: object
          additionalProperties: false
          properties: {}
    GroupingInvalidated:
      allOf:
        -
          $ref: '#/components/schemas/GroupingEvents'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    GroupingItem:
      type: object
      additionalProperties: false
      properties:
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        GroupFrom:
          type: string
        GroupId:
          type: string
        GroupItemId:
          type: string
        GroupTo:
          type: string
        GroupType:
          type: string
        IsAddOn:
          type: boolean
        IsValid:
          type: boolean
    GroupingUpdated:
      allOf:
        -
          $ref: '#/components/schemas/GroupingEvents'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    GroupingValidated:
      allOf:
        -
          $ref: '#/components/schemas/GroupingEvents'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    InvalidateGroupingCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    Query:
      type: object
      additionalProperties: false
      properties:
        CurrentPage:
          type: integer
          format: int32
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfAuditEventModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditEventModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfAuditObjectModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditObjectModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfSearchGroupingItemView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/SearchGroupingItemView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfSearchGroupingNameView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/SearchGroupingNameView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfSearchGroupingView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/SearchGroupingView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    SearchGroupingAggregateDeltaQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditObjectModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/SearchGroupingAggregateDeltaQueryParms'
    SearchGroupingAggregateDeltaQueryParms:
      type: object
      additionalProperties: false
      properties:
        CommitId:
          type: string
          format: uuid
        GroupId:
          type: string
    SearchGroupingItemQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfSearchGroupingItemView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/SearchGroupingItemQueryParms'
    SearchGroupingItemQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchGroupingItemQuery' }

    SearchGroupingItemQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/SearchGroupingItemView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchGroupingItemQueryParms:
      type: object
      additionalProperties: false
      properties:
        GroupId:
          type: string
        IsValid:
          type: boolean
    SearchGroupingItemView:
      type: object
      additionalProperties: false
      properties:
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        GroupFrom:
          type: string
        GroupId:
          type: string
          format: uuid
        GroupItemId:
          type: string
          format: uuid
        GroupTo:
          type: string
        GroupType:
          type: string
        IsAddOn:
          type: boolean
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
    SearchGroupingNameQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfSearchGroupingNameView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/SearchGroupingNameQueryParms'
    SearchGroupingNameQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchGroupingNameQuery' }

    SearchGroupingNameQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/SearchGroupingNameView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchGroupingNameQueryParms:
      type: object
      additionalProperties: false
      properties:
        IsValid:
          type: boolean
          nullable: true
        SourceContentId:
          type: string
    SearchGroupingNameView:
      type: object
      additionalProperties: false
      properties:
        GroupId:
          type: string
          format: uuid
        GroupName:
          type: string
        IsValid:
          type: boolean
        SourceContentId:
          type: string
    SearchGroupingQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfSearchGroupingView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/SearchGroupingQueryParms'
    SearchGroupingQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchGroupingQuery' }

    SearchGroupingQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/SearchGroupingView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchGroupingQueryParms:
      type: object
      additionalProperties: false
      properties:
        DataList:
          type: string
        FromDate:
          type: string
          format: date-time
          nullable: true
        GroupName:
          type: string
        GroupNameBase:
          type: string
        GroupNameFilterMode:
          type: string
        GroupType:
          type: string
        IsFilterByAsOfDate:
          type: boolean
        IsFilterByEffectiveDate:
          type: boolean
        IsFilterByEndDate:
          type: boolean
        IsValid:
          type: boolean
          nullable: true
        Module:
          type: string
        ModuleName:
          type: string
        ModuleNameFilterMode:
          type: string
        SelectedGroupItem:
          type: string
        SelectedGroupItemFilterMode:
          type: string
        SourceContentId:
          type: string
        SourceContentIdFilterMode:
          type: string
        ToDate:
          type: string
          format: date-time
          nullable: true
    SearchGroupingView:
      type: object
      additionalProperties: false
      properties:
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        GroupFrom:
          type: string
        GroupId:
          type: string
          format: uuid
        GroupItemId:
          type: string
          format: uuid
        GroupName:
          type: string
        GroupTo:
          type: string
        GroupType:
          type: string
        IsAddOn:
          type: boolean
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
        ModuleName:
          type: string
        SourceContentId:
          type: string
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
    UpdateGroupingCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
    ValidateGroupingCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            GroupId:
              type: string
            GroupItems:
              type: array
              items:
                $ref: '#/components/schemas/GroupingItem'
            GroupName:
              type: string
            IsValid:
              type: boolean
            ModuleName:
              type: string
            SourceContentId:
              type: string
```

### B.5 `fee-schedule.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Fee Schedule API (legacy operationIds)
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/fee-schedule:
    post:
      operationId: AddFeeSchedule
      summary: 'Legacy: IFeeScheduleService.AddFeeSchedule'
      parameters:
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/AddFeeScheduleCommand' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleProcessed' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/fee-schedule/{feeScheduleId}:
    get:
      operationId: GetFeeSchedule
      summary: 'Legacy: IFeeScheduleQueryService.GetFeeSchedule'
      parameters:
        - name: feeScheduleId
          in: path
          required: true
          schema: { type: string, format: uuid }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetFeeScheduleQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
    patch:
      operationId: UpdateFeeSchedule
      summary: 'Legacy: IFeeScheduleService.UpdateFeeSchedule'
      parameters:
        - name: feeScheduleId
          in: path
          required: true
          schema: { type: string, format: uuid }
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/UpdateFeeScheduleCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleProcessed' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/fee-schedule/{feeScheduleId}/lines/add:
    post:
      operationId: AddFeeScheduleLine
      summary: 'Legacy: IFeeScheduleService.AddFeeScheduleLine'
      parameters:
        - name: feeScheduleId
          in: path
          required: true
          schema: { type: string, format: uuid }
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/AddFeeScheduleLineCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleLineProcessed' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/fee-schedule/{feeScheduleId}/lines/update:
    post:
      operationId: UpdateFeeScheduleLine
      summary: 'Legacy: IFeeScheduleService.UpdateFeeScheduleLine'
      parameters:
        - name: feeScheduleId
          in: path
          required: true
          schema: { type: string, format: uuid }
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/UpdateFeeScheduleLineCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleLineProcessed' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/fee-schedule/field-definition/search:
    post:
      operationId: SearchFieldDefinition
      summary: 'Legacy: IFeeScheduleQueryService.SearchFieldDefinition'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchFieldDefinitionQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchFieldDefinitionQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/partial/search:
    post:
      operationId: SearchFeeSchedulePartial
      summary: 'Legacy: IFeeScheduleQueryService.SearchFeeSchedulePartial'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchFeeSchedulePartialQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchFeeSchedulePartialQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/schedule-id/predictive-search:
    post:
      operationId: SearchScheduleIdPredictive
      summary: 'Legacy: IFeeScheduleQueryService.SearchScheduleIdPredictive'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/SearchScheduleIdPredictiveQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/SearchScheduleIdPredictiveQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/events:
    post:
      operationId: GetFeeScheduleEvents
      summary: 'Legacy: IFeeScheduleQueryService.GetFeeScheduleEvents'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/FeeScheduleEventQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleEventQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/aggregate-delta:
    post:
      operationId: GetFeeScheduleAggregateDelta
      summary: 'Legacy: IFeeScheduleQueryService.GetFeeScheduleAggregateDelta'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/FeeScheduleAggregateDeltaQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleAggregateDeltaQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/line-events:
    post:
      operationId: GetFeeScheduleLineEvents
      summary: 'Legacy: IFeeScheduleQueryService.GetFeeScheduleLineEvents'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/FeeScheduleLineEventQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleLineEventQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/line-aggregate-delta:
    post:
      operationId: GetFeeScheduleLineAggregateDelta
      summary: 'Legacy: IFeeScheduleQueryService.GetFeeScheduleLineAggregateDelta'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/FeeScheduleLineAggregateDeltaQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FeeScheduleLineAggregateDeltaQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/batch/get:
    post:
      operationId: GetFeeScheduleBatch
      summary: 'Legacy: IFeeScheduleQueryService.GetFeeScheduleBatch'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/GetFeeScheduleBatchQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetFeeScheduleBatchQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/fee-schedule/batch/upload:
    post:
      operationId: UploadFeeSchedule
      summary: 'Legacy batch: IBatchFeeScheduleService.UploadFeeSchedule'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/batch/lock:
    post:
      operationId: LockFeeSchedule
      summary: 'Legacy batch: IBatchFeeScheduleService.LockFeeSchedule'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ActionRequest' }
      responses:
        '200': { description: OK }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/fee-schedule/batch/unlock:
    post:
      operationId: UnlockFeeSchedule
      summary: 'Legacy batch: IBatchFeeScheduleService.UnlockFeeSchedule'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ActionRequest' }
      responses:
        '200': { description: OK }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    AddFeeScheduleCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            FeeScheduleFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleField'
            IsValid:
              type: boolean
            ScheduleId:
              type: string
            ScheduleName:
              type: string
            ScheduleReleaseStatus:
              type: string
            ScheduleRules:
              type: string
    AddFeeScheduleLineCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            EffectiveDate:
              type: string
              format: date-time
              nullable: true
            EndDate:
              type: string
              format: date-time
              nullable: true
            FeeScheduleId:
              type: string
            FeeScheduleLineFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleLineField'
            IsValid:
              type: boolean
              nullable: true
    AuditEnumerationsEventAuditSortFieldType:
      type: string
      enum:
        - Default
        - EventStampDate
        - EventType
        - UserId
        - SourceOfChange
    AuditEventModel:
      type: object
      additionalProperties: false
      properties:
        AuditEvent:
          type: string
        AuditId:
          type: string
        CommitId:
          type: string
          format: uuid
        CommitTimestamp:
          type: string
          format: date-time
        EventTypeName:
          type: string
        SourceOfChange:
          type: string
        UserId:
          type: string
    AuditKeyModel:
      type: object
      additionalProperties: false
      properties:
        KeyFullName:
          type: string
        KeyName:
          type: string
        KeyValue:
          type: string
        PropertyDisplayDataListName:
          type: string
        PropertyDisplayName:
          type: string
    AuditObjectDifferenceModel:
      type: object
      additionalProperties: false
      properties:
        DisplayAfterValue:
          type: string
        DisplayBeforeValue:
          type: string
        IsAuditKey:
          type: boolean
        PropertyDisplayDatalistName:
          type: string
        PropertyDisplayName:
          type: string
        PropertyFullName:
          type: string
        PropertyName:
          type: string
    AuditObjectModel:
      type: object
      additionalProperties: false
      properties:
        AggregatePath:
          type: string
        AuditKeys:
          type: array
          items:
            $ref: '#/components/schemas/AuditKeyModel'
        Differences:
          type: array
          items:
            $ref: '#/components/schemas/AuditObjectDifferenceModel'
        ObjectFullName:
          type: string
        ObjectName:
          type: string
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    Command:
      type: object
      additionalProperties: false
      properties:
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        ViewTimeStamp:
          type: string
          format: date-time
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    CoreEnumerationsMessagingSearchModeType:
      type: string
      enum:
        - EqualTo
        - NotEqualTo
        - Contains
        - StartsWith
        - EndsWith
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
    CoreEnumerationsMessagingSortDirectionType:
      type: string
      enum:
        - Ascending
        - Descending
    Event:
      type: object
      additionalProperties: false
      properties:
        ApplicationName:
          type: string
        CommitId:
          type: string
          format: uuid
          nullable: true
        CorrelationId:
          type: string
        EventID:
          type: string
        ModelID:
          type: string
        ModelType:
          type: string
        Timestamp:
          type: string
          format: date-time
          nullable: true
        UserID:
          type: string
        UserIp:
          type: string
    EventQueryParams:
      type: object
      additionalProperties: false
      properties:
        EventStampDate:
          type: string
          format: date-time
          nullable: true
        EventStampDateSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        EventType:
          type: string
        EventTypeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        SourceOfChange:
          type: string
        SourceOfChangeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        UserId:
          type: string
        UserIdSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    FeeScheduleAdded:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            FeeScheduleFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleField'
            IsValid:
              type: boolean
            OperatorId:
              type: string
            ScheduleId:
              type: string
            ScheduleName:
              type: string
            ScheduleReleaseStatus:
              type: string
            ScheduleRules:
              type: string
    FeeScheduleAggregateDeltaQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditObjectModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/FeeScheduleAggregateDeltaQueryParms'
    FeeScheduleAggregateDeltaQueryParms:
      type: object
      additionalProperties: false
      properties:
        CommitId:
          type: string
          format: uuid
        FeeScheduleId:
          type: string
    FeeScheduleBatchView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        FeeScheduleFields:
          type: array
          items:
            $ref: '#/components/schemas/FeeScheduleFieldView'
        FeeScheduleId:
          type: string
          format: uuid
        IsValid:
          type: boolean
        OperatorId:
          type: string
        ScheduleId:
          type: string
        ScheduleName:
          type: string
        ScheduleReleaseStatus:
          type: string
        ScheduleRules:
          type: string
    FeeScheduleEvent:
      allOf:
        -
          $ref: '#/components/schemas/Event'
        -
          type: object
          additionalProperties: false
          properties:
            FeeScheduleId:
              type: string
    FeeScheduleEventQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditEventModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/FeeScheduleEventQueryParms'
    FeeScheduleEventQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AuditWhere:
              $ref: '#/components/schemas/EventQueryParams'
            FeeScheduleId:
              type: string
            SortDirection:
              type: string
              enum:
                - Ascending
                - Descending
            SortField:
              type: string
              enum:
                - Default
                - EventStampDate
                - EventType
                - UserId
                - SourceOfChange
    FeeScheduleField:
      type: object
      additionalProperties: false
      properties:
        FeeScheduleFieldCode:
          type: string
        FeeScheduleFieldId:
          type: string
        IsBusinessIdentifier:
          type: boolean
        IsRequired:
          type: boolean
        OrderIndex:
          type: integer
          format: int32
    FeeScheduleFieldDefinitionView:
      type: object
      additionalProperties: false
      properties:
        DataRestrictionType:
          type: string
        DataType:
          type: string
        DatalistContentId:
          type: string
        FeeScheduleFieldCode:
          type: string
        FeeScheduleFieldDefinitionId:
          type: string
          format: uuid
        LabelContentId:
          type: string
        MaxLength:
          type: object
          additionalProperties: true
          nullable: true
        MaxValue:
          type: object
          additionalProperties: true
          nullable: true
        MinLength:
          type: object
          additionalProperties: true
          nullable: true
        MinValue:
          type: object
          additionalProperties: true
          nullable: true
        OperatorId:
          type: string
    FeeScheduleFieldView:
      type: object
      additionalProperties: false
      properties:
        FeeScheduleFieldCode:
          type: string
        FeeScheduleFieldId:
          type: string
          format: uuid
        FeeScheduleId:
          type: string
          format: uuid
        IsBusinessIdentifier:
          type: boolean
        IsRequired:
          type: boolean
        OrderIndex:
          type: integer
          format: int32
    FeeScheduleFullView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        FeeScheduleFields:
          type: array
          items:
            $ref: '#/components/schemas/FeeScheduleFieldView'
        FeeScheduleId:
          type: string
          format: uuid
        FeeScheduleLines:
          type: array
          items:
            $ref: '#/components/schemas/FeeScheduleLineView'
        HasInvalidLineData:
          type: boolean
        IsLocked:
          type: boolean
        IsValid:
          type: boolean
        OperatorId:
          type: string
        ScheduleId:
          type: string
        ScheduleName:
          type: string
        ScheduleReleaseStatus:
          type: string
        ScheduleRules:
          type: string
    FeeScheduleLineAdded:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            EffectiveDate:
              type: string
              format: date-time
              nullable: true
            EndDate:
              type: string
              format: date-time
              nullable: true
            FeeScheduleLineFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleLineField'
            FeeScheduleLineId:
              type: string
            IsValid:
              type: boolean
              nullable: true
    FeeScheduleLineAggregateDeltaQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditObjectModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/FeeScheduleLineAggregateDeltaQueryParms'
    FeeScheduleLineAggregateDeltaQueryParms:
      type: object
      additionalProperties: false
      properties:
        CommitId:
          type: string
          format: uuid
        FeeScheduleLineId:
          type: string
    FeeScheduleLineEventQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditEventModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/FeeScheduleLineEventQueryParms'
    FeeScheduleLineEventQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AuditWhere:
              $ref: '#/components/schemas/EventQueryParams'
            FeeScheduleLineId:
              type: string
            SortDirection:
              type: string
              enum:
                - Ascending
                - Descending
            SortField:
              type: string
              enum:
                - Default
                - EventStampDate
                - EventType
                - UserId
                - SourceOfChange
    FeeScheduleLineField:
      type: object
      additionalProperties: false
      properties:
        FeeScheduleFieldCode:
          type: string
        FeeScheduleFieldDesc:
          type: string
        FeeScheduleFieldValue:
          type: string
        FeeScheduleLineFieldId:
          type: string
    FeeScheduleLineInvalidated:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            EffectiveDate:
              type: string
              format: date-time
              nullable: true
            EndDate:
              type: string
              format: date-time
              nullable: true
            FeeScheduleLineFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleLineField'
            FeeScheduleLineId:
              type: string
            IsValid:
              type: boolean
              nullable: true
    FeeScheduleLineProcessed:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            FeeScheduleLineAdded:
              $ref: '#/components/schemas/FeeScheduleLineAdded'
            FeeScheduleLineId:
              type: string
            FeeScheduleLineInvalidated:
              $ref: '#/components/schemas/FeeScheduleLineInvalidated'
            FeeScheduleLineUpdated:
              $ref: '#/components/schemas/FeeScheduleLineUpdated'
            IsEndDated:
              type: boolean
            IsOnlyRateEndDateEditable:
              type: boolean
            IsOnlyRateProcessingEndDateEditable:
              type: boolean
            IsValid:
              type: boolean
    FeeScheduleLineUpdated:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            EffectiveDate:
              type: string
              format: date-time
              nullable: true
            EndDate:
              type: string
              format: date-time
              nullable: true
            FeeScheduleLineFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleLineField'
            FeeScheduleLineId:
              type: string
            IsValid:
              type: boolean
              nullable: true
    FeeScheduleLineView:
      type: object
      additionalProperties: false
      properties:
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        FeeScheduleId:
          type: string
          format: uuid
        FeeScheduleLineFields:
          type: array
          items:
            $ref: '#/components/schemas/FeeScheduleLineField'
        FeeScheduleLineId:
          type: string
          format: uuid
        IsEndDated:
          type: boolean
        IsOnlyRateEndDateEditable:
          type: boolean
        IsOnlyRateProcessingEndDateEditable:
          type: boolean
        IsValid:
          type: boolean
    FeeSchedulePartialView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        FeeScheduleId:
          type: string
          format: uuid
        HasInvalidLineData:
          type: boolean
        IsValid:
          type: boolean
        ScheduleId:
          type: string
        ScheduleName:
          type: string
        ScheduleReleaseStatus:
          type: string
    FeeScheduleProcessed:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            FeeScheduleAdded:
              $ref: '#/components/schemas/FeeScheduleAdded'
            FeeScheduleLineUpdated:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleLineUpdated'
            FeeScheduleUpdated:
              $ref: '#/components/schemas/FeeScheduleUpdated'
    FeeScheduleUpdated:
      allOf:
        -
          $ref: '#/components/schemas/FeeScheduleEvent'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            FeeScheduleFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleField'
            FeeScheduleLineInternalIds:
              type: string
            IsValid:
              type: boolean
            OperatorId:
              type: string
            ScheduleId:
              type: string
            ScheduleName:
              type: string
            ScheduleReleaseStatus:
              type: string
            ScheduleRules:
              type: string
    GetFeeScheduleBatchQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfFeeScheduleBatchView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GetFeeScheduleBatchQueryParms'
    GetFeeScheduleBatchQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ScheduleId:
              type: string
    GetFeeScheduleQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfFeeScheduleFullView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GetFeeScheduleQueryParms'
    GetFeeScheduleQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AgeMax:
              type: string
            AgeMaxFilterMode:
              type: string
            AgeMin:
              type: string
            AgeMinFilterMode:
              type: string
            Area:
              type: string
            AreaFilterMode:
              type: string
            BenefitPlan:
              type: string
            BenefitPlanFilterMode:
              type: string
            Code:
              type: string
            CodeFilterMode:
              type: string
            CodeType:
              type: array
              items:
                type: string
            County:
              type: string
            CountyFilterMode:
              type: string
            EffectiveDate:
              type: string
            EffectiveDateFilterMode:
              type: string
            EndDate:
              type: string
            EndDateFilterMode:
              type: string
            Facility:
              type: string
            FacilityFilterMode:
              type: string
            FeeScheduleId:
              type: string
            Gender:
              type: string
            GenderFilterMode:
              type: string
            IsExport:
              type: boolean
            IsFeeScheduleLineValid:
              type: boolean
            LevelOfCare:
              type: string
            LevelOfCareFilterMode:
              type: string
            MedicareCoverageInd:
              type: string
            MedicareCoverageIndFilterMode:
              type: string
            Modifier1:
              type: string
            Modifier1FilterMode:
              type: string
            Modifier2:
              type: string
            Modifier2FilterMode:
              type: string
            Modifier3:
              type: string
            Modifier3FilterMode:
              type: string
            Modifier4:
              type: string
            Modifier4FilterMode:
              type: string
            NPI:
              type: string
            NPIFilterMode:
              type: string
            Network:
              type: string
            NetworkFilterMode:
              type: string
            NonFacility:
              type: string
            NonFacilityFilterMode:
              type: string
            PopCodes:
              type: string
            PopCodesFilterMode:
              type: string
            ProcessingEndDate:
              type: string
            ProcessingEndDateFilterMode:
              type: string
            ProcessingStartDate:
              type: string
            ProcessingStartDateFilterMode:
              type: string
            ProviderServiceLocID:
              type: string
            ProviderServiceLocIDFilterMode:
              type: string
            ProviderSpecialty:
              type: string
            ProviderSpecialtyFilterMode:
              type: string
            ProviderTaxonomy:
              type: string
            ProviderTaxonomyFilterMode:
              type: string
            ProviderType:
              type: string
            ProviderTypeFilterMode:
              type: string
            Region:
              type: string
            RegionFilterMode:
              type: string
            ServiceType:
              type: string
            ServiceTypeFilterMode:
              type: string
            State:
              type: string
            StateFilterMode:
              type: string
            TaxID:
              type: string
            TaxIDFilterMode:
              type: string
            UserDefined1:
              type: string
            UserDefined1FilterMode:
              type: string
            UserDefined2:
              type: string
            UserDefined2FilterMode:
              type: string
            UserDefined3:
              type: string
            UserDefined3FilterMode:
              type: string
            UserDefined4:
              type: string
            UserDefined4FilterMode:
              type: string
            UserDefined5:
              type: string
            UserDefined5FilterMode:
              type: string
            VOSTag:
              type: string
            VOSTagFilterMode:
              type: string
            VOSTagType:
              type: string
            VOSTagTypeFilterMode:
              type: string
            ZipCode:
              type: string
            ZipCodeFilterMode:
              type: string
    Query:
      type: object
      additionalProperties: false
      properties:
        ByPassCountQuery:
          type: boolean
        CurrentPage:
          type: integer
          format: int32
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfAuditEventModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditEventModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfAuditObjectModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditObjectModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfFeeScheduleBatchView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleBatchView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfFeeScheduleFieldDefinitionView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleFieldDefinitionView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfFeeScheduleFullView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleFullView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfFeeSchedulePartialView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/FeeSchedulePartialView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfScheduleIdPredictiveView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ScheduleIdPredictiveView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryParameterEnumerationsSearchByDateType:
      type: string
      enum:
        - None
        - EffectiveDate
        - EndDate
        - RateStartDate
        - RateEndDate
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    ScheduleIdPredictiveView:
      type: object
      additionalProperties: false
      properties:
        ScheduleId:
          type: string
        ScheduleName:
          type: string
    SearchFeeSchedulePartialQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfFeeSchedulePartialView'
        -
          type: object
          additionalProperties: false
          properties:
            SortDirection:
              type: string
              enum:
                - ASC
                - DESC
            SortField:
              type: string
              enum:
                - Default
                - ScheduleId
                - ScheduleName
                - ScheduleReleaseStatus
                - ChangeRequestCode
            Where:
              $ref: '#/components/schemas/SearchFeeSchedulePartialQueryParms'
    SearchFeeSchedulePartialQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchFeeSchedulePartialQuery' }

    SearchFeeSchedulePartialQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/FeeSchedulePartialView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchFeeSchedulePartialQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            BillingCode:
              type: string
            ChangeRequestCode:
              type: string
            CodeType:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            LevelOfCareCode:
              type: string
            Modifier:
              type: string
            NPI:
              type: string
            ProviderBillingId:
              type: string
            ProviderSpecialty:
              type: string
            ProviderTaxonomy:
              type: string
            ProviderType:
              type: string
            ScheduleId:
              type: string
            ScheduleIdAdvanceCriteria:
              type: string
            ScheduleName:
              type: string
            ScheduleReleaseStatus:
              type: string
            SearchDateType:
              type: string
              enum:
                - None
                - EffectiveDate
                - EndDate
                - RateStartDate
                - RateEndDate
            TaxId:
              type: string
            ToDate:
              type: string
              format: date-time
              nullable: true
    SearchFieldDefinitionQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfFeeScheduleFieldDefinitionView'
        -
          type: object
          additionalProperties: false
          properties: {}
    SearchFieldDefinitionQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchFieldDefinitionQuery' }

    SearchFieldDefinitionQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/FeeScheduleFieldDefinitionView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchScheduleIdPredictiveQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfScheduleIdPredictiveView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/SearchScheduleIdPredictiveQueryParms'
    SearchScheduleIdPredictiveQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/SearchScheduleIdPredictiveQuery' }

    SearchScheduleIdPredictiveQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ScheduleIdPredictiveView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    SearchScheduleIdPredictiveQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ScheduleId:
              type: string
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortEnumerationsFeeScheduleFieldType:
      type: string
      enum:
        - Default
        - ScheduleId
        - ScheduleName
        - ScheduleReleaseStatus
        - ChangeRequestCode
    SortEnumerationsSortDirectionType:
      type: string
      enum:
        - ASC
        - DESC
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
    UpdateFeeScheduleCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            FeeScheduleFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleField'
            FeeScheduleId:
              type: string
            IsEditingFields:
              type: boolean
            IsValid:
              type: boolean
            ScheduleId:
              type: string
            ScheduleName:
              type: string
            ScheduleReleaseStatus:
              type: string
            ScheduleRules:
              type: string
    UpdateFeeScheduleLineCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            EffectiveDate:
              type: string
              format: date-time
              nullable: true
            EndDate:
              type: string
              format: date-time
              nullable: true
            FeeScheduleId:
              type: string
            FeeScheduleLineFields:
              type: array
              items:
                $ref: '#/components/schemas/FeeScheduleLineField'
            FeeScheduleLineId:
              type: string
            IsValid:
              type: boolean
              nullable: true
```

### B.6 `rate-setting.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Rate Setting API (legacy operationIds)
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/rate-setting/provider-ucc/search:
    post:
      operationId: SearchProviderUCCRates
      summary: 'Legacy: IRateSettingQueryService.SearchProviderUCCRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ProviderUCCRateQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ProviderUCCRateQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/provider-drg/search:
    post:
      operationId: SearchProviderDRGRates
      summary: 'Legacy: IRateSettingQueryService.SearchProviderDRGRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ProviderDRGRateQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ProviderDRGRateQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/provider-specific/search:
    post:
      operationId: SearchProviderSpecificRates
      summary: 'Legacy: IRateSettingQueryService.SearchProviderSpecificRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ProviderSpecificRateQueryRequest' }
            example: { CurrentPage: 1, PageSize: 25, SortField: EffectiveDate, SortDirection: DESC, Where: { ProviderBillingId: '0000000001', SearchDateType: EffectiveDate, FromDate: '2026-01-01T00:00:00Z' } }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ProviderSpecificRateQueryResponse' }
              example: { items: [ { ProviderSpecificRateId: '2a9a39f5-0000-4000-8000-000000000001', ProviderBillingId: '0000000001', RateType: 'SPECIFIC', BillingCode: 'A0001', RateAmount: 12.5, EffectiveDate: '2026-01-01T00:00:00Z', EndDate: '9999-12-31T00:00:00Z', IsValid: true } ], page: { currentPage: 1, pageSize: 25, rowCount: 1 } }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/file-loader-history/search:
    post:
      operationId: SearchFileLoaderHistories
      summary: 'Legacy: IRateSettingQueryService.SearchFileLoaderHistories'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/FileLoaderHistoryQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FileLoaderHistoryQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/attachments/add:
    post:
      operationId: AddAttachmentAndUpdateLoaderHistory
      summary: 'Legacy: IRateSettingFileUploadService.AddAttachmentAndUpdateLoaderHistory'
      parameters:
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/AddAttachmentCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/AttachmentAdded' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/file-loader-history/cancel:
    post:
      operationId: CancelFileLoaderHistory
      summary: 'Legacy: IRateSettingFileUploadService.CancelFileLoaderHistory'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CancelFileUploadCommand' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/FileUploadCanceled' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/batch/upload/provider-ucc:
    post:
      operationId: UploadProviderUCCRates
      summary: 'Legacy batch: IBatchProviderRateService.UploadProviderUCCRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/batch/upload/provider-drg:
    post:
      operationId: UploadProviderDRGRates
      summary: 'Legacy batch: IBatchProviderRateService.UploadProviderDRGRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/batch/upload/provider-specific:
    post:
      operationId: UploadProviderSpecificRates
      summary: 'Legacy batch: IBatchProviderRateService.UploadProviderSpecificRates'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/provider-ucc:
    post:
      operationId: AddProviderUCCRate
      summary: 'Legacy: IRateSettingService – Add Usual and Customary Charges'
      parameters:
        - $ref: '#/components/parameters/IdempotencyKey'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ProviderUCCRateWrite' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ProviderUCCRateView' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/provider-drg:
    post:
      operationId: AddProviderDRGRate
      summary: 'Legacy: IRateSettingService – Add DRG Rate'
      parameters:
        - $ref: '#/components/parameters/IdempotencyKey'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ProviderDRGRateWrite' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ProviderDRGRateView' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/provider-specific:
    post:
      operationId: AddProviderSpecificRate
      summary: 'Legacy: IRateSettingService – Add Nursing Facility, Encounter, Dispensing Fee, Inpatient or Outpatient rate'
      parameters:
        - $ref: '#/components/parameters/IdempotencyKey'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ProviderSpecificRateWrite' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ProviderSpecificRateView' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/member-specific:
    post:
      operationId: AddMemberSpecificRate
      summary: 'Legacy: Add Member Specific Rate (UG p.132)'
      parameters:
        - $ref: '#/components/parameters/IdempotencyKey'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/MemberSpecificRateWrite' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/MemberSpecificRateView' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/member-specific/search:
    post:
      operationId: SearchMemberSpecificRates
      summary: 'Legacy: Search Member Specific Rates (UG p.131)'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/MemberSpecificRateQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/MemberSpecificRateQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/{rateFamily}/{id}:
    parameters:
      - $ref: '#/components/parameters/RateFamily'
      - $ref: '#/components/parameters/RateRecordId'
    get:
      operationId: GetRate
      summary: 'Legacy: View rate (by rate family)'
      responses:
        '200':
          description: OK; body is the view schema of the rate family
          content:
            application/json:
              schema: { $ref: '#/components/schemas/AnyRateView' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
    patch:
      operationId: EditRate
      summary: 'Legacy: Edit rate; date-based edit limits apply (BR-013)'
      parameters:
        - $ref: '#/components/parameters/IdempotencyKey'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/AnyRateWrite' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/AnyRateView' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/{rateFamily}/{id}:{action}:
    parameters:
      - $ref: '#/components/parameters/RateFamily'
      - $ref: '#/components/parameters/RateRecordId'
      - name: action
        in: path
        required: true
        schema: { type: string, enum: [copy, insert, invalidate] }
    post:
      operationId: RateMaintenanceAction
      summary: 'Legacy: Copy, Insert New (BR-011) or invalidate a rate'
      parameters:
        - $ref: '#/components/parameters/IdempotencyKey'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/RateActionRequest' }
      responses:
        '200':
          description: OK; for copy and insert the body is the new record
          content:
            application/json:
              schema: { $ref: '#/components/schemas/AnyRateView' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/rate-setting/{rateFamily}/{id}/audit:
    parameters:
      - $ref: '#/components/parameters/RateFamily'
      - $ref: '#/components/parameters/RateRecordId'
    get:
      operationId: GetRateAudit
      summary: 'Legacy: Provider Specific Audit (UG p.129)'
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/RateAuditResponse' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  parameters:
    IdempotencyKey:
      name: X-Idempotency-Key
      in: header
      required: true
      schema: { type: string, minLength: 1, maxLength: 200 }
    RateFamily:
      name: rateFamily
      in: path
      required: true
      schema: { type: string, enum: [provider-ucc, provider-drg, provider-specific, member-specific] }
    RateRecordId:
      name: id
      in: path
      required: true
      schema: { type: string, format: uuid }
  schemas:
    RateWriteCommon:
      type: object
      description: Fields common to every rate write. ProviderServiceLocationId is required for provider rates (BR-003).
      required: [versionNumber, changeRequestCode, effectiveDate]
      properties:
        versionNumber: { type: integer, minimum: 0, description: 0 on create }
        changeRequestCode: { type: string, minLength: 1, description: Required on create, copy and insert (BR-012) }
        effectiveDate: { type: string, format: date }
        endDate: { type: string, format: date, nullable: true, description: Defaults to MaxDate 9999-12-31 }
        processingStartDate: { type: string, format: date, nullable: true, description: BR-009 }
        processingEndDate: { type: string, format: date, nullable: true, description: BR-009 }
        rateAdjustment: { type: string, nullable: true, description: DataList RateAdjIndicator (01, 02) }
        isValid: { type: boolean, default: true }
        vosTags:
          type: array
          items: { $ref: '#/components/schemas/VOSTagView' }
    ProviderUCCRateWrite:
      allOf:
        - $ref: '#/components/schemas/RateWriteCommon'
        - type: object
          required: [providerServiceLocationId, codeType, procedureCode, rateType, rateCategory, rateAmount]
          properties:
            providerServiceLocationId: { type: string }
            codeType: { type: string }
            procedureCode: { type: string }
            modifiers: { type: array, maxItems: 4, uniqueItems: true, items: { type: string }, description: BR-017 }
            rateType: { type: string }
            rateCategory: { type: string }
            rateAmount: { type: number, format: double }
    ProviderDRGRateWrite:
      allOf:
        - $ref: '#/components/schemas/RateWriteCommon'
        - type: object
          required: [providerServiceLocationId, drgCode, rateType, rateCategory, rateAmount, baseRate, costChargeRatio]
          properties:
            providerServiceLocationId: { type: string }
            drgCode: { type: string }
            codeType: { type: string, nullable: true }
            severityOfIllnessCode: { type: string, nullable: true }
            rateType: { type: string }
            rateCategory: { type: string }
            rateAmount: { type: number, format: double }
            baseRate: { type: number, format: double }
            costChargeRatio: { type: number, format: double }
            costOutlierTrimPoint: { type: number, format: double, nullable: true }
            costPercentage: { type: number, format: double, nullable: true }
            dayOutlier: { type: integer, nullable: true }
            dayOutlierPercentage: { type: number, format: double, nullable: true }
            capitalAmount: { type: number, format: double, nullable: true }
            capitalPercentage: { type: number, format: double, nullable: true }
            educationalAmount: { type: number, format: double, nullable: true }
            educationalPercentage: { type: number, format: double, nullable: true }
            paidPercentage: { type: number, format: double, nullable: true }
            disproportionatePercentage: { type: number, format: double, nullable: true }
            customDrgValues:
              type: array
              items:
                type: object
                required: [customDrgType]
                properties:
                  customDrgType: { type: string }
                  customAmount: { type: number, format: double, nullable: true }
                  customPercentage: { type: number, format: double, nullable: true }
    ProviderSpecificRateWrite:
      allOf:
        - $ref: '#/components/schemas/RateWriteCommon'
        - type: object
          description: Key fields depend on rateType (§2.2.1). Rate Amount or Rate Percent is required (BR-007).
          required: [providerServiceLocationId, rateType]
          properties:
            providerServiceLocationId: { type: string }
            rateType: { type: string, enum: [NursingFacility, Encounter, DispensingFee, Inpatient, Outpatient] }
            codeType: { type: string, nullable: true }
            billingCode: { type: string, nullable: true }
            rateCategory: { type: string, nullable: true }
            encounterType: { type: string, nullable: true }
            levelOfCareCode: { type: string, nullable: true }
            providerSpecialtyCode: { type: string, nullable: true }
            drugType: { type: string, nullable: true, description: Blank means ALL (BR-018) }
            dispensingType: { type: string, nullable: true, description: Blank means ALL (BR-018) }
            ingredientFrom: { type: number, format: double, nullable: true }
            ingredientTo: { type: number, format: double, nullable: true }
            rateAmount: { type: number, format: double, nullable: true }
            ratePercent: { type: number, format: double, nullable: true, description: Outpatient Rate Factor }
    MemberSpecificRateWrite:
      allOf:
        - $ref: '#/components/schemas/RateWriteCommon'
        - type: object
          required: [memberId, codeType, code, rateAmount]
          properties:
            memberId: { type: string }
            providerServiceLocationId: { type: string, nullable: true }
            codeType: { type: string }
            code: { type: string }
            rateAmount: { type: number, format: double }
    MemberSpecificRateView:
      type: object
      properties:
        memberSpecificRateId: { type: string, format: uuid }
        memberId: { type: string }
        memberDisplayName: { type: string, nullable: true }
        providerServiceLocationId: { type: string, nullable: true }
        codeType: { type: string }
        code: { type: string }
        rateAmount: { type: number, format: double }
        effectiveDate: { type: string, format: date }
        endDate: { type: string, format: date }
        processingStartDate: { type: string, format: date, nullable: true }
        processingEndDate: { type: string, format: date, nullable: true }
        changeRequestCode: { type: string }
        isValid: { type: boolean }
        versionNumber: { type: integer }
        vosTags:
          type: array
          items: { $ref: '#/components/schemas/VOSTagView' }
    MemberSpecificRateQuery:
      type: object
      properties:
        CurrentPage: { type: integer, minimum: 1 }
        PageSize: { type: integer, minimum: 1, maximum: 500 }
        Where:
          type: object
          properties:
            MemberIdName: { type: string, minLength: 4 }
            CodeType: { type: string }
            SearchDateType: { type: string }
            FromDate: { type: string, format: date-time, nullable: true }
            ToDate: { type: string, format: date-time, nullable: true }
            VOSTagType: { type: string }
            VOSTag: { type: string }
            ChangeRequestCode: { type: string }
    MemberSpecificRateQueryResponse:
      type: object
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/MemberSpecificRateView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }
    AnyRateView:
      oneOf:
        - $ref: '#/components/schemas/ProviderUCCRateView'
        - $ref: '#/components/schemas/ProviderDRGRateView'
        - $ref: '#/components/schemas/ProviderSpecificRateView'
        - $ref: '#/components/schemas/MemberSpecificRateView'
    AnyRateWrite:
      oneOf:
        - $ref: '#/components/schemas/ProviderUCCRateWrite'
        - $ref: '#/components/schemas/ProviderDRGRateWrite'
        - $ref: '#/components/schemas/ProviderSpecificRateWrite'
        - $ref: '#/components/schemas/MemberSpecificRateWrite'
    RateActionRequest:
      type: object
      required: [versionNumber]
      properties:
        versionNumber: { type: integer, minimum: 0 }
        changeRequestCode: { type: string, nullable: true, description: Required for copy and insert (BR-012) }
        effectiveDate: { type: string, format: date, nullable: true, description: Required for insert (BR-011) }
        changes:
          type: object
          additionalProperties: true
          description: For copy and insert, field values that differ from the source record
    RateAuditResponse:
      type: object
      required: [items]
      properties:
        items:
          type: array
          items:
            type: object
            properties:
              occurredAt: { type: string, format: date-time }
              event: { type: string, enum: [Added, Updated] }
              userId: { type: string }
              sourceOfChange: { type: string }
              before: { type: object, additionalProperties: true, nullable: true }
              after: { type: object, additionalProperties: true, nullable: true }
    AddAttachmentCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            ErrorAttachmentId:
              type: string
              format: uuid
              nullable: true
            ErrorFileName:
              type: string
            ErrorStatus:
              type: string
            FileAttachmentId:
              type: string
              format: uuid
            FileData:
              type: object
              additionalProperties: true
            FileExtension:
              type: string
            FileName:
              type: string
            FileUploadCode:
              type: string
            FileUploaderHistoryId:
              type: string
              format: uuid
            RecordCount:
              type: string
            SourceCode:
              type: string
            Status:
              type: string
            TypeCode:
              type: string
            TypeCodeId:
              type: string
            UploadDate:
              type: string
              format: date-time
    AttachmentAdded:
      allOf:
        -
          $ref: '#/components/schemas/AttachmentEvents'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            FileAttachmentId:
              type: string
              format: uuid
            FileData:
              type: object
              additionalProperties: true
            FileExtension:
              type: string
            FileName:
              type: string
            FileUploadCode:
              type: string
            FileUploadHistoryId:
              type: string
              format: uuid
            RecordCount:
              type: string
            Status:
              type: string
    AttachmentEvents:
      allOf:
        -
          $ref: '#/components/schemas/Event'
        -
          type: object
          additionalProperties: false
          properties:
            TrackingId:
              type: string
              format: uuid
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    CancelFileUploadCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            FileUploadHistoryId:
              type: string
    Command:
      type: object
      additionalProperties: false
      properties:
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        ViewTimeStamp:
          type: string
          format: date-time
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    Event:
      type: object
      additionalProperties: false
      properties:
        ApplicationName:
          type: string
        CommitId:
          type: string
          format: uuid
          nullable: true
        CorrelationId:
          type: string
        EventID:
          type: string
        ModelID:
          type: string
        ModelType:
          type: string
        Timestamp:
          type: string
          format: date-time
          nullable: true
        UserID:
          type: string
        UserIp:
          type: string
    FileLoaderHistoryQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfFileLoaderHistoryView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/FileLoaderHistoryQueryParms'
    FileLoaderHistoryQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/FileLoaderHistoryQuery' }

    FileLoaderHistoryQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/FileLoaderHistoryView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    FileLoaderHistoryQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            FileName:
              type: string
            FileNameFilterMode:
              type: string
            FileUploadCode:
              type: string
            FileUploadCodeFilterMode:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            ProcessedDate:
              type: string
              format: date-time
              nullable: true
            ProcessedDateFilterMode:
              type: string
            SearchDateType:
              type: string
              enum:
                - None
                - DateUploaded
                - DateProcessed
            SourceCode:
              type: string
            Status:
              type: string
            StatusFilterMode:
              type: string
            ToDate:
              type: string
              format: date-time
              nullable: true
            TypeCode:
              type: string
            TypeCodeFilterMode:
              type: string
            TypeCodeId:
              type: string
            UploadDate:
              type: string
              format: date-time
              nullable: true
            UploadDateFilterMode:
              type: string
    FileLoaderHistoryView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        ErrorAttachmentId:
          type: string
          format: uuid
          nullable: true
        ErrorFileName:
          type: string
        FileAttachmentId:
          type: string
          format: uuid
        FileName:
          type: string
        FileUploadCode:
          type: string
        FileUploadHistoryId:
          type: string
          format: uuid
        ProcessedDate:
          type: string
          format: date-time
          nullable: true
        RecordCount:
          type: string
        SourceCode:
          type: string
        Status:
          type: string
        TypeCode:
          type: string
        TypeCodeId:
          type: string
        UploadDate:
          type: string
          format: date-time
    FileUploadCanceled:
      allOf:
        -
          $ref: '#/components/schemas/Event'
        -
          type: object
          additionalProperties: false
          properties:
            FileUploadHistoryId:
              type: string
    ProviderDRGCustomView:
      type: object
      additionalProperties: false
      properties:
        CustomAmount:
          type: number
          format: double
          nullable: true
        CustomDRGType:
          type: string
        CustomPercentage:
          type: number
          format: double
          nullable: true
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
          nullable: true
        ProviderDRGCustomId:
          type: string
          format: uuid
        ProviderDRGRateId:
          type: string
          format: uuid
    ProviderDRGRateQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfProviderDRGRateView'
        -
          type: object
          additionalProperties: false
          properties:
            SortDirection:
              type: string
              enum:
                - ASC
                - DESC
            SortField:
              type: string
              enum:
                - Default
                - ProviderBillingId
                - DRGCode
                - RateType
                - BaseRate
                - CostChargeRatio
                - EffectiveDate
                - EndDate
                - RateStartDate
                - RateEndDate
                - Active
            Where:
              $ref: '#/components/schemas/ProviderDRGRateQueryParms'
    ProviderDRGRateQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ProviderDRGRateQuery' }

    ProviderDRGRateQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ProviderDRGRateView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ProviderDRGRateQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            CodeType:
              type: string
            DRGCode:
              type: string
            DRGCodeName:
              type: string
            DRGCodeNameFilterMode:
              type: string
            EffectiveDate:
              type: string
              format: date-time
            EffectiveDateFilterMode:
              type: string
            EndDate:
              type: string
              format: date-time
            EndDateFilterMode:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            IsVOSTagsReturned:
              type: boolean
            IsValid:
              type: boolean
            LocationName:
              type: string
            ProviderBillingId:
              type: string
            ProviderDRGRateId:
              type: string
            ProviderLocationIdNameCriteriaFilterMode:
              type: string
            RateAmount:
              type: number
              format: double
            RateAmountFilterMode:
              type: string
            RateCategory:
              type: string
            RateEndDate:
              type: string
              format: date-time
            RateEndDateFilterMode:
              type: string
            RateStartDate:
              type: string
              format: date-time
            RateStartDateFilterMode:
              type: string
            RateType:
              type: string
            RateTypeFilterMode:
              type: string
            SearchDateType:
              type: string
              enum:
                - None
                - EffectiveDate
                - EndDate
                - RateStartDate
                - RateEndDate
            ToDate:
              type: string
              format: date-time
              nullable: true
            VOSTag:
              type: string
            VOSTagType:
              type: string
    ProviderDRGRateView:
      type: object
      additionalProperties: false
      properties:
        BaseRate:
          type: number
          format: double
        CapitalAmount:
          type: number
          format: double
          nullable: true
        CapitalPercentage:
          type: number
          format: double
          nullable: true
        ChangeRequestCode:
          type: string
        CodeType:
          type: string
        CostChargeRatio:
          type: number
          format: double
        CostOutlierTrimPoint:
          type: number
          format: double
          nullable: true
        CostPercentage:
          type: number
          format: double
          nullable: true
        DRGCode:
          type: string
        DRGCodeDescription:
          type: string
        DayOutlier:
          type: object
          additionalProperties: true
          nullable: true
        DayOutlierPercentage:
          type: number
          format: double
          nullable: true
        DisproportionatePercentage:
          type: number
          format: double
          nullable: true
        EducationalAmount:
          type: number
          format: double
          nullable: true
        EducationalPercentage:
          type: number
          format: double
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        IsEndDated:
          type: boolean
        IsOnlyRateEndDateEditable:
          type: boolean
        IsOnlyRateProcessingEndDateEditable:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
          nullable: true
        PaidPercentage:
          type: number
          format: double
          nullable: true
        ProviderBillingId:
          type: string
        ProviderDRGCustoms:
          type: array
          items:
            $ref: '#/components/schemas/ProviderDRGCustomView'
        ProviderDRGRateId:
          type: string
          format: uuid
        ProviderServiceLocation:
          $ref: '#/components/schemas/ProviderServiceLocationView'
        RateAmount:
          type: number
          format: double
        RateEndDate:
          type: string
          format: date-time
          nullable: true
        RateStartDate:
          type: string
          format: date-time
          nullable: true
        RateType:
          type: string
        RateTypeDescription:
          type: string
        SeverityofIllnessCode:
          type: string
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    ProviderServiceLocationView:
      type: object
      additionalProperties: false
      properties:
        EnrollmentTypeCode:
          type: string
        FirstName:
          type: string
        IsValid:
          type: boolean
        LastName:
          type: string
        LocationName:
          type: string
        ProviderBillingId:
          type: string
        ProviderServiceLocationId:
          type: string
    ProviderSpecificRateQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfProviderSpecificRateView'
        -
          type: object
          additionalProperties: false
          properties:
            SortDirection:
              type: string
              enum:
                - ASC
                - DESC
            SortField:
              type: string
              enum:
                - Default
                - ProviderBillingId
                - RateType
                - DispensingType
                - DrugType
                - BillingCode
                - RateAmount
                - RatePercent
                - EffectiveDate
                - EndDate
                - LevelOfCareCode
                - RateStartDate
                - RateEndDate
                - ProviderSpecialtyCode
                - EncounterType
                - Ingredient
                - Active
            Where:
              $ref: '#/components/schemas/ProviderSpecificRateQueryParms'
    ProviderSpecificRateQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ProviderSpecificRateQuery' }

    ProviderSpecificRateQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ProviderSpecificRateView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ProviderSpecificRateQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            BillingCode:
              type: string
            BillingCodeName:
              type: string
            ChangeRequestCode:
              type: string
            CodeSearchResultFilterMode:
              type: string
            CodeType:
              type: string
            DispensingType:
              type: string
            DispensingTypeFilterMode:
              type: string
            DispensingTypeName:
              type: string
            DrugType:
              type: string
            DrugTypeCode:
              type: string
            DrugTypeFilterMode:
              type: string
            EffectiveDate:
              type: string
              format: date-time
            EffectiveDateFilterMode:
              type: string
            EncounterType:
              type: string
            EncounterTypeFilterMode:
              type: string
            EncounterTypeName:
              type: string
            EndDate:
              type: string
              format: date-time
            EndDateFilterMode:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            Ingredient:
              type: number
              format: double
              nullable: true
            IngredientFilterMode:
              type: string
            IsVOSTagsReturned:
              type: boolean
            IsValid:
              type: boolean
            LevelOfCareCode:
              type: string
            LevelOfCareCodeFilterMode:
              type: string
            LevelOfCareCodeName:
              type: string
            LocationName:
              type: string
            ProviderBillingId:
              type: string
            ProviderLocationIdNameCriteriaFilterMode:
              type: string
            ProviderServiceTypeCode:
              type: string
            ProviderSpecialtyCode:
              type: string
            ProviderSpecialtyFilterMode:
              type: string
            ProviderSpecificRateId:
              type: string
            RateAmount:
              type: number
              format: double
            RateAmountFilterMode:
              type: string
            RateCategory:
              type: string
            RateEndDate:
              type: string
              format: date-time
            RateEndDateFilterMode:
              type: string
            RatePercent:
              type: number
              format: double
            RatePercentFilterMode:
              type: string
            RateStartDate:
              type: string
              format: date-time
            RateStartDateFilterMode:
              type: string
            RateType:
              type: string
            RateTypeFilterMode:
              type: string
            SearchDateType:
              type: string
              enum:
                - None
                - EffectiveDate
                - EndDate
                - RateStartDate
                - RateEndDate
            ToDate:
              type: string
              format: date-time
              nullable: true
            VOSTag:
              type: string
            VOSTagType:
              type: string
    ProviderSpecificRateView:
      type: object
      additionalProperties: false
      properties:
        BillingCode:
          type: string
        BillingCodeDescription:
          type: string
        ChangeRequestCode:
          type: string
        CodeType:
          type: string
        CreatedDate:
          type: string
          format: date-time
          nullable: true
        DispensingType:
          type: string
        DispensingTypeDescription:
          type: string
        DrugType:
          type: string
        DrugTypeDescription:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EncounterType:
          type: string
        EncounterTypeDescription:
          type: string
        EndDate:
          type: string
          format: date-time
        IngredientFrom:
          type: number
          format: double
          nullable: true
        IngredientTo:
          type: number
          format: double
          nullable: true
        IsEndDated:
          type: boolean
        IsOnlyRateEndDateEditable:
          type: boolean
        IsOnlyRateProcessingEndDateEditable:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
          nullable: true
        LevelOfCareCode:
          type: string
        LevelOfCareDescription:
          type: string
        ProviderBillingId:
          type: string
        ProviderServiceLocation:
          $ref: '#/components/schemas/ProviderServiceLocationView'
        ProviderServiceTypeCode:
          type: string
        ProviderSpecialtyCode:
          type: string
        ProviderSpecialtyDescription:
          type: string
        ProviderSpecificRateId:
          type: string
          format: uuid
        RateAmount:
          type: number
          format: double
          nullable: true
        RateEndDate:
          type: string
          format: date-time
          nullable: true
        RatePercent:
          type: number
          format: double
          nullable: true
        RateStartDate:
          type: string
          format: date-time
          nullable: true
        RateType:
          type: string
        RateTypeDescription:
          type: string
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    ProviderUCCRateQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfProviderUCCRateView'
        -
          type: object
          additionalProperties: false
          properties:
            SortDirection:
              type: string
              enum:
                - ASC
                - DESC
            SortField:
              type: string
              enum:
                - Default
                - ProviderBillingId
                - ProcedureCode
                - Rate
                - RateType
                - EffectiveDate
                - EndDate
                - RateStartDate
                - RateEndDate
                - Modifier
                - Active
            Where:
              $ref: '#/components/schemas/ProviderUCCRateQueryParms'
    ProviderUCCRateQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ProviderUCCRateQuery' }

    ProviderUCCRateQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ProviderUCCRateView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ProviderUCCRateQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ChangeRequestCode:
              type: string
            CodeType:
              type: string
            EffectiveDate:
              type: string
              format: date-time
            EffectiveDateFilterMode:
              type: string
            EndDate:
              type: string
              format: date-time
            EndDateFilterMode:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            IsVOSTagsReturned:
              type: boolean
            IsValid:
              type: boolean
            LocationName:
              type: string
            ModifierCode:
              type: string
            ModifierCodeFilterMode:
              type: string
            ProcedureCode:
              type: string
            ProcedureCodeFilterMode:
              type: string
            ProcedureCodeName:
              type: string
            ProviderBillingId:
              type: string
            ProviderLocationIdNameCriteriaFilterMode:
              type: string
            ProviderUCCRateId:
              type: string
            RateAmount:
              type: number
              format: double
            RateAmountFilterMode:
              type: string
            RateCategory:
              type: string
            RateEndDate:
              type: string
              format: date-time
            RateEndDateFilterMode:
              type: string
            RateStartDate:
              type: string
              format: date-time
            RateStartDateFilterMode:
              type: string
            RateType:
              type: string
            RateTypeFilterMode:
              type: string
            SearchDateType:
              type: string
              enum:
                - None
                - EffectiveDate
                - EndDate
                - RateStartDate
                - RateEndDate
            ToDate:
              type: string
              format: date-time
              nullable: true
            VOSTag:
              type: string
            VOSTagType:
              type: string
    ProviderUCCRateView:
      type: object
      additionalProperties: false
      properties:
        ChangeRequestCode:
          type: string
        CodeType:
          type: string
        CreatedDate:
          type: string
          format: date-time
          nullable: true
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        IsEndDated:
          type: boolean
        IsOnlyRateEndDateEditable:
          type: boolean
        IsOnlyRateProcessingEndDateEditable:
          type: boolean
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
          nullable: true
        Modifier1:
          type: string
        Modifier2:
          type: string
        Modifier3:
          type: string
        Modifier4:
          type: string
        ProcedureCode:
          type: string
        ProcedureCodeDescription:
          type: string
        ProviderBillingId:
          type: string
        ProviderServiceLocation:
          $ref: '#/components/schemas/ProviderServiceLocationView'
        ProviderUCCRateId:
          type: string
          format: uuid
        RateAmount:
          type: number
          format: double
        RateEndDate:
          type: string
          format: date-time
          nullable: true
        RateStartDate:
          type: string
          format: date-time
          nullable: true
        RateType:
          type: string
        RateTypeDescription:
          type: string
        VOSTags:
          type: array
          items:
            $ref: '#/components/schemas/VOSTagView'
    Query:
      type: object
      additionalProperties: false
      properties:
        ByPassCountQuery:
          type: boolean
        CurrentPage:
          type: integer
          format: int32
        CycleDate:
          type: string
          format: date-time
          nullable: true
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfFileLoaderHistoryView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/FileLoaderHistoryView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfProviderDRGRateView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ProviderDRGRateView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfProviderSpecificRateView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ProviderSpecificRateView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfProviderUCCRateView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ProviderUCCRateView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryParameterEnumerationsSearchByDateType:
      type: string
      enum:
        - None
        - EffectiveDate
        - EndDate
        - RateStartDate
        - RateEndDate
    QueryParameterEnumerationsSearchByFileUploadDateType:
      type: string
      enum:
        - None
        - DateUploaded
        - DateProcessed
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortEnumerationsProviderDRGRateSortFieldType:
      type: string
      enum:
        - Default
        - ProviderBillingId
        - DRGCode
        - RateType
        - BaseRate
        - CostChargeRatio
        - EffectiveDate
        - EndDate
        - RateStartDate
        - RateEndDate
        - Active
    SortEnumerationsProviderSpecificRateSortFieldType:
      type: string
      enum:
        - Default
        - ProviderBillingId
        - RateType
        - DispensingType
        - DrugType
        - BillingCode
        - RateAmount
        - RatePercent
        - EffectiveDate
        - EndDate
        - LevelOfCareCode
        - RateStartDate
        - RateEndDate
        - ProviderSpecialtyCode
        - EncounterType
        - Ingredient
        - Active
    SortEnumerationsProviderUCCRateSortFieldType:
      type: string
      enum:
        - Default
        - ProviderBillingId
        - ProcedureCode
        - Rate
        - RateType
        - EffectiveDate
        - EndDate
        - RateStartDate
        - RateEndDate
        - Modifier
        - Active
    SortEnumerationsSortDirectionType:
      type: string
      enum:
        - ASC
        - DESC
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
    VOSTagView:
      type: object
      additionalProperties: false
      properties:
        EntityId:
          type: string
          format: uuid
        EntityType:
          type: string
        IsValid:
          type: boolean
        LastModified:
          type: string
          format: date-time
        TagCode:
          type: string
        TagTypeCode:
          type: string
        VOSEffectiveDate:
          type: string
          format: date-time
        VOSEndDate:
          type: string
          format: date-time
        VOSTagId:
          type: string
          format: uuid
```

### B.7 `related-information.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Related Information API (legacy operationIds)
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/related-information/exception-information/search:
    post:
      operationId: SearchExceptionInformation
      summary: 'Legacy: IRelatedInformationQueryService.SearchExceptionInformation'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExceptionInformationQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExceptionInformationQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/exception-information/{exceptionInformationId}:
    get:
      operationId: GetExceptionInformation
      summary: 'Legacy: IRelatedInformationQueryService.GetExceptionInformation'
      parameters:
        - name: exceptionInformationId
          in: path
          required: true
          schema: { type: string, format: uuid }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetExceptionInformationQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/exception-information/restrictions/get:
    post:
      operationId: GetExceptionInformationRestrictions
      summary: 'Legacy: IRelatedInformationQueryService.GetExceptionInformationRestrictions'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExceptionInformationRestrictionQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExceptionInformationRestrictionQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/related-information/exception-errors/search:
    post:
      operationId: SearchExceptionErrors
      summary: 'Legacy: IRelatedInformationQueryService.SearchExceptionErrors'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExceptionErrorQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExceptionErrorQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/exception-errors/{exceptionErrorId}:
    get:
      operationId: GetExceptionError
      summary: 'Legacy: IRelatedInformationQueryService.GetExceptionError'
      parameters:
        - name: exceptionErrorId
          in: path
          required: true
          schema: { type: string, format: uuid }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetExceptionErrorQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/exception-errors/restrictions/get:
    post:
      operationId: GetExceptionErrorRestrictions
      summary: 'Legacy: IRelatedInformationQueryService.GetExceptionErrorRestrictions'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExceptionErrorRestrictionQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExceptionErrorRestrictionQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/related-information/eob-codes/search:
    post:
      operationId: SearchExplanationOfBenefitCodes
      summary: 'Legacy: IRelatedInformationQueryService.SearchExplanationOfBenefitCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExplanationOfBenefitCodeQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExplanationOfBenefitCodeQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/related-information/eobs/search:
    post:
      operationId: SearchExplanationOfBenefits
      summary: 'Legacy: IRelatedInformationQueryService.SearchExplanationOfBenefits'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExplanationOfBenefitQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExplanationOfBenefitQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/eobs/{eobId}:
    get:
      operationId: GetExplanationOfBenefits
      summary: 'Legacy: IRelatedInformationQueryService.GetExplanationOfBenefits'
      parameters:
        - name: eobId
          in: path
          required: true
          schema: { type: string, format: uuid }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/GetExplanationOfBenefitQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/eobs/restrictions/get:
    post:
      operationId: GetExplanationOfBenefitRestrictions
      summary: 'Legacy: IRelatedInformationQueryService.GetExplanationOfBenefitRestrictions'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExplanationOfBenefitRestrictionQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExplanationOfBenefitRestrictionQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/related-information/mue/search:
    post:
      operationId: SearchMedicallyUnlikelyEdit
      summary: 'Legacy: IRelatedInformationQueryService.SearchMedicallyUnlikelyEdit'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/MedicallyUnlikelyEditQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/MedicallyUnlikelyEditQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/ncci/search:
    post:
      operationId: SearchNationalCorrectCodingInitiative
      summary: 'Legacy: IRelatedInformationQueryService.SearchNationalCorrectCodingInitiative'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/NationalCorrectCodingInitiativeQueryRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/NationalCorrectCodingInitiativeQueryResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/related-information/explanation-code/events:
    post:
      operationId: GetExplanationCodeEvents
      summary: 'Legacy: IRelatedInformationQueryService.GetExplanationCodeEvents'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExplanationCodeEventQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExplanationCodeEventQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/related-information/explanation-code/aggregate-delta:
    post:
      operationId: GetExplanationCodeAggregateDelta
      summary: 'Legacy: IRelatedInformationQueryService.GetExplanationCodeAggregateDelta'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/ExplanationCodeAggregateDeltaQuery' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/ExplanationCodeAggregateDeltaQuery' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/related-information/batch/upload-eob-codes:
    post:
      operationId: UploadEOBCodes
      summary: 'Legacy batch: IBatchRelatedInformationService.UploadEOBCodes'
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportRequest' }
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportCreatedResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    AuditEnumerationsEventAuditSortFieldType:
      type: string
      enum:
        - Default
        - EventStampDate
        - EventType
        - UserId
        - SourceOfChange
    AuditEventModel:
      type: object
      additionalProperties: false
      properties:
        AuditEvent:
          type: string
        AuditId:
          type: string
        CommitId:
          type: string
          format: uuid
        CommitTimestamp:
          type: string
          format: date-time
        EventTypeName:
          type: string
        SourceOfChange:
          type: string
        UserId:
          type: string
    AuditKeyModel:
      type: object
      additionalProperties: false
      properties:
        KeyFullName:
          type: string
        KeyName:
          type: string
        KeyValue:
          type: string
        PropertyDisplayDataListName:
          type: string
        PropertyDisplayName:
          type: string
    AuditObjectDifferenceModel:
      type: object
      additionalProperties: false
      properties:
        DisplayAfterValue:
          type: string
        DisplayBeforeValue:
          type: string
        IsAuditKey:
          type: boolean
        PropertyDisplayDatalistName:
          type: string
        PropertyDisplayName:
          type: string
        PropertyFullName:
          type: string
        PropertyName:
          type: string
    AuditObjectModel:
      type: object
      additionalProperties: false
      properties:
        AggregatePath:
          type: string
        AuditKeys:
          type: array
          items:
            $ref: '#/components/schemas/AuditKeyModel'
        Differences:
          type: array
          items:
            $ref: '#/components/schemas/AuditObjectDifferenceModel'
        ObjectFullName:
          type: string
        ObjectName:
          type: string
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    CoreEnumerationsMessagingSearchModeType:
      type: string
      enum:
        - EqualTo
        - NotEqualTo
        - Contains
        - StartsWith
        - EndsWith
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
    CoreEnumerationsMessagingSortDirectionType:
      type: string
      enum:
        - Ascending
        - Descending
    EventQueryParams:
      type: object
      additionalProperties: false
      properties:
        EventStampDate:
          type: string
          format: date-time
          nullable: true
        EventStampDateSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        EventType:
          type: string
        EventTypeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        SourceOfChange:
          type: string
        SourceOfChangeSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
        UserId:
          type: string
        UserIdSearchMode:
          type: string
          enum:
            - EqualTo
            - NotEqualTo
            - Contains
            - StartsWith
            - EndsWith
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    ExceptionErrorFilter:
      allOf:
        -
          $ref: '#/components/schemas/FilterCriteriaOfSortEnumerationsExceptionErrorFieldTypeeLCRr80x'
        -
          type: object
          additionalProperties: false
          properties: {}
    ExceptionErrorQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExceptionErrorResultView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExceptionErrorQueryParms'
    ExceptionErrorQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ExceptionErrorQuery' }

    ExceptionErrorQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ExceptionErrorResultView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ExceptionErrorQueryParms:
      type: object
      additionalProperties: false
      properties:
        AdvancedCode:
          type: string
        AdvancedDescription:
          type: string
        Code:
          type: string
        ExceptionErrorCodeId:
          type: string
        ExceptionErrorFilters:
          type: array
          items:
            $ref: '#/components/schemas/ExceptionErrorFilter'
        FromDate:
          type: string
          format: date-time
          nullable: true
        IsValid:
          type: boolean
        ModuleName:
          type: string
        SearchDateType:
          type: string
        ToDate:
          type: string
          format: date-time
          nullable: true
    ExceptionErrorRestrictionQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExceptionErrorRestrictionView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExceptionErrorRestrictionQueryParms'
    ExceptionErrorRestrictionQueryParms:
      type: object
      additionalProperties: false
      properties:
        ExceptionErrorCodeId:
          type: string
        IsValid:
          type: boolean
    ExceptionErrorRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AssignmentCode:
          type: string
        DispositionCode:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionErrorCodeId:
          type: string
          format: uuid
        ExceptionErrorCodeRestrictionId:
          type: string
          format: uuid
        ExplanationOfBenefitCode:
          type: string
        FormattedContents:
          type: array
          items:
            $ref: '#/components/schemas/FormattedContentView'
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsOverride:
          type: boolean
        IsValid:
          type: boolean
        ModuleName:
          type: string
        OverrideDispositionCode:
          type: string
        OverrideDispositionGroupId:
          type: string
          format: uuid
          nullable: true
        OverrideDispositionGroupName:
          type: string
        OverrideTypeCode:
          type: string
        Ranking:
          type: object
          additionalProperties: true
          nullable: true
        SeverityCode:
          type: string
    ExceptionErrorResultView:
      type: object
      additionalProperties: false
      properties:
        AssignmentCode:
          type: string
        Code:
          type: string
        Description:
          type: string
        DispositionCode:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionErrorCodeId:
          type: string
          format: uuid
        ExplanationOfBenefitCode:
          type: string
        IsOverride:
          type: boolean
        IsValid:
          type: boolean
        ModuleName:
          type: string
        Ranking:
          type: object
          additionalProperties: true
          nullable: true
        SeverityCode:
          type: string
    ExceptionErrorView:
      type: object
      additionalProperties: false
      properties:
        Code:
          type: string
        DataListItemPeriodId:
          type: string
        Description:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionErrorCodeId:
          type: string
          format: uuid
        ExceptionErrorRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/ExceptionErrorRestrictionView'
        IsValid:
          type: boolean
        LongDescription:
          type: string
    ExceptionInformationFilter:
      allOf:
        -
          $ref: '#/components/schemas/FilterCriteriaOfSortEnumerationsExceptionInformationFieldTypeeLCRr80x'
        -
          type: object
          additionalProperties: false
          properties: {}
    ExceptionInformationQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExceptionInformationResultView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExceptionInformationQueryParms'
    ExceptionInformationQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ExceptionInformationQuery' }

    ExceptionInformationQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ExceptionInformationResultView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ExceptionInformationQueryParms:
      type: object
      additionalProperties: false
      properties:
        AdvancedCode:
          type: string
        AdvancedDescription:
          type: string
        Code:
          type: string
        ExceptionInformationFilters:
          type: array
          items:
            $ref: '#/components/schemas/ExceptionInformationFilter'
        ExceptionInformationId:
          type: string
        FromDate:
          type: string
          format: date-time
          nullable: true
        IsValid:
          type: boolean
        ModuleName:
          type: string
        SearchDateType:
          type: string
        ToDate:
          type: string
          format: date-time
          nullable: true
    ExceptionInformationRestrictionQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExceptionInformationRestrictionView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExceptionInformationRestrictionQueryParms'
    ExceptionInformationRestrictionQueryParms:
      type: object
      additionalProperties: false
      properties:
        ExceptionInformationId:
          type: string
        IsValid:
          type: boolean
    ExceptionInformationRestrictionView:
      type: object
      additionalProperties: false
      properties:
        AssignmentCode:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionInformationId:
          type: string
          format: uuid
        ExceptionInformationRestrictionId:
          type: string
          format: uuid
        ExplanationOfBenefitCode:
          type: string
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
        ModuleName:
          type: string
        Ranking:
          type: object
          additionalProperties: true
          nullable: true
        TypeCode:
          type: string
    ExceptionInformationResultView:
      type: object
      additionalProperties: false
      properties:
        AssignmentCode:
          type: string
        Code:
          type: string
        Description:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionInformationId:
          type: string
          format: uuid
        ExplanationOfBenefitCode:
          type: string
        IsValid:
          type: boolean
        ModuleName:
          type: string
        Ranking:
          type: object
          additionalProperties: true
          nullable: true
        TypeCode:
          type: string
    ExceptionInformationView:
      type: object
      additionalProperties: false
      properties:
        Code:
          type: string
        DataListItemPeriodId:
          type: string
        Description:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExceptionInformationId:
          type: string
          format: uuid
        ExceptionInformationRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/ExceptionInformationRestrictionView'
        IsValid:
          type: boolean
        LongDescription:
          type: string
    ExplanationCodeAggregateDeltaQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditObjectModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExplanationCodeAggregateDeltaQueryParms'
    ExplanationCodeAggregateDeltaQueryParms:
      type: object
      additionalProperties: false
      properties:
        CommitId:
          type: string
          format: uuid
        DataListItemId:
          type: string
        ExplanationCodeType:
          type: string
    ExplanationCodeEventQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfAuditEventModel'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExplanationCodeEventQueryParms'
    ExplanationCodeEventQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AuditWhere:
              $ref: '#/components/schemas/EventQueryParams'
            DataListItemId:
              type: string
            ExplanationCodeType:
              type: string
            SortDirection:
              type: string
              enum:
                - Ascending
                - Descending
            SortField:
              type: string
              enum:
                - Default
                - EventStampDate
                - EventType
                - UserId
                - SourceOfChange
    ExplanationOfBenefitCodeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExplanationOfBenefitCodeView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExplanationOfBenefitCodeQueryParms'
    ExplanationOfBenefitCodeQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ExplanationOfBenefitCodeQuery' }

    ExplanationOfBenefitCodeQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ExplanationOfBenefitCodeView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ExplanationOfBenefitCodeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            EOBCodeDescription:
              type: string
            IsValid:
              type: boolean
              nullable: true
    ExplanationOfBenefitCodeView:
      type: object
      additionalProperties: false
      properties:
        Code:
          type: string
        Description:
          type: string
        IsValid:
          type: boolean
    ExplanationOfBenefitFilter:
      type: object
      additionalProperties: false
      properties:
        FilterParams:
          $ref: '#/components/schemas/ExplanationOfBenefitFilterParms'
        FilterValue:
          type: string
    ExplanationOfBenefitFilterParms:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
          enum:
            - Module
            - Code
            - Description
            - CARC
            - RARC
            - EffectiveDate
            - EndDate
            - IsValid
        SearchPattern:
          type: string
          enum:
            - Default
            - EqualTo
            - Contains
            - EndsWith
            - StartsWith
            - NotEqualTo
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    ExplanationOfBenefitQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExplanationOfBenefitResultView'
        -
          type: object
          additionalProperties: false
          properties:
            SortField:
              type: string
              enum:
                - Module
                - Code
                - Description
                - CARC
                - RARC
                - EffectiveDate
                - EndDate
                - IsValid
            Where:
              $ref: '#/components/schemas/ExplanationOfBenefitQueryParms'
    ExplanationOfBenefitQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/ExplanationOfBenefitQuery' }

    ExplanationOfBenefitQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/ExplanationOfBenefitResultView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    ExplanationOfBenefitQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            AdvancedCode:
              type: string
            AdvancedDescription:
              type: string
            CARCCode:
              type: string
            Code:
              type: string
            ExplanationOfBenefitFilters:
              type: array
              items:
                $ref: '#/components/schemas/ExplanationOfBenefitFilter'
            ExplanationOfBenefitId:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            IsValid:
              type: boolean
            ModuleName:
              type: string
            RARCCode:
              type: string
            SearchDateType:
              type: string
            ToDate:
              type: string
              format: date-time
              nullable: true
    ExplanationOfBenefitRestrictionQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExplanationOfBenefitRestrictionView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/ExplanationOfBenefitRestrictionQueryParms'
    ExplanationOfBenefitRestrictionQueryParms:
      type: object
      additionalProperties: false
      properties:
        ExplanationOfBenefitId:
          type: string
        IsValid:
          type: boolean
    ExplanationOfBenefitRestrictionView:
      type: object
      additionalProperties: false
      properties:
        CARCCode:
          type: string
        CategoryCode:
          type: string
        ClaimStatusCode:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        EntityIdentifierCode:
          type: string
        ExplanationOfBenefitId:
          type: string
          format: uuid
        ExplanationOfBenefitRestrictionId:
          type: string
          format: uuid
        IsEditable:
          type: boolean
        IsEndDated:
          type: boolean
        IsValid:
          type: boolean
        ModuleId:
          type: string
          format: uuid
        ModuleName:
          type: string
        RARCCode:
          type: string
    ExplanationOfBenefitResultView:
      type: object
      additionalProperties: false
      properties:
        CARC:
          type: string
        Code:
          type: string
        Description:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExplanationOfBenefitId:
          type: string
          format: uuid
        IsValid:
          type: boolean
        ModuleId:
          type: string
          format: uuid
        ModuleName:
          type: string
        RARC:
          type: string
    ExplanationOfBenefitView:
      type: object
      additionalProperties: false
      properties:
        Code:
          type: string
        DataListItemPeriodId:
          type: string
        Description:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        ExplanationOfBenefitId:
          type: string
          format: uuid
        ExplanationOfBenefitRestrictions:
          type: array
          items:
            $ref: '#/components/schemas/ExplanationOfBenefitRestrictionView'
        IsValid:
          type: boolean
        LongDescription:
          type: string
    FilterCriteriaOfSortEnumerationsExceptionErrorFieldTypeeLCRr80x:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
          enum:
            - Module
            - Code
            - Description
            - Ranking
            - Severity
            - Assignment
            - Override
            - Disposition
            - EOB
            - EffectiveDate
            - EndDate
            - IsValid
        FilterValue:
          type: object
          additionalProperties: true
        SearchPattern:
          type: string
          enum:
            - Default
            - EqualTo
            - Contains
            - EndsWith
            - StartsWith
            - NotEqualTo
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    FilterCriteriaOfSortEnumerationsExceptionInformationFieldTypeeLCRr80x:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
          enum:
            - Module
            - Code
            - Description
            - Type
            - Ranking
            - Assignment
            - EOB
            - EffectiveDate
            - EndDate
            - IsValid
        FilterValue:
          type: object
          additionalProperties: true
        SearchPattern:
          type: string
          enum:
            - Default
            - EqualTo
            - Contains
            - EndsWith
            - StartsWith
            - NotEqualTo
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    FormattedContentView:
      type: object
      additionalProperties: false
      properties:
        ContentDescription:
          type: string
        ContentEffectiveDate:
          type: string
          format: date-time
        ContentEndDate:
          type: string
          format: date-time
        ContentEntityId:
          type: string
          format: uuid
        ContentEntityType:
          type: string
        ContentFormattedText:
          type: string
        ContentLocaleId:
          type: string
        FormattedContentId:
          type: string
          format: uuid
        IsValid:
          type: boolean
    GetExceptionErrorQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExceptionErrorView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GetExceptionErrorQueryParms'
    GetExceptionErrorQueryParms:
      type: object
      additionalProperties: false
      properties:
        ExceptionErrorCodeId:
          type: string
    GetExceptionInformationQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExceptionInformationView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GetExceptionInformationQueryParms'
    GetExceptionInformationQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ExceptionInformationId:
              type: string
    GetExplanationOfBenefitQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfExplanationOfBenefitView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/GetExplanationOfBenefitQueryParms'
    GetExplanationOfBenefitQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            ExplanationOfBenefitId:
              type: string
    MUEFilter:
      type: object
      additionalProperties: false
      properties:
        FilterCriteria:
          $ref: '#/components/schemas/MUEFilterParms'
        FilterValue:
          type: object
          additionalProperties: true
    MUEFilterParms:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
          enum:
            - Code
            - EffectiveDate
            - EndDate
            - MUEValue
            - Default
            - MUEType
            - CLEID
            - Publication
            - IsOverride
            - Source
            - IsValid
        SearchPattern:
          type: string
          enum:
            - Default
            - EqualTo
            - Contains
            - EndsWith
            - StartsWith
            - NotEqualTo
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    MedicallyUnlikelyEditQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfMedicallyUnlikelyEditView'
        -
          type: object
          additionalProperties: false
          properties:
            SortField:
              type: string
              enum:
                - Code
                - EffectiveDate
                - EndDate
                - MUEValue
                - Default
                - MUEType
                - CLEID
                - Publication
                - IsOverride
                - Source
                - IsValid
            Where:
              $ref: '#/components/schemas/MedicallyUnlikelyEditQueryParms'
    MedicallyUnlikelyEditQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/MedicallyUnlikelyEditQuery' }

    MedicallyUnlikelyEditQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/MedicallyUnlikelyEditView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    MedicallyUnlikelyEditQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            Code:
              type: string
            FromDate:
              type: string
              format: date-time
              nullable: true
            IsValid:
              type: boolean
            MUEFilters:
              type: array
              items:
                $ref: '#/components/schemas/MUEFilter'
            MUEType:
              type: string
            MedicallyUnlikelyEditId:
              type: string
            SearchBy:
              type: string
            SearchDateType:
              type: string
            SourceCode:
              type: string
            ToDate:
              type: string
              format: date-time
              nullable: true
    MedicallyUnlikelyEditView:
      type: object
      additionalProperties: false
      properties:
        CLEId:
          type: string
        Code:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        IsOverride:
          type: boolean
        IsValid:
          type: boolean
        MUEType:
          type: string
        MUEValue:
          type: integer
          format: int64
        MedicallyUnlikelyEditId:
          type: string
          format: uuid
        PublicationIndicator:
          type: string
        SourceCode:
          type: string
    NCCIFilter:
      type: object
      additionalProperties: false
      properties:
        FilterParams:
          $ref: '#/components/schemas/NCCIFilterParms'
        FilterValue:
          type: object
          additionalProperties: true
    NCCIFilterParms:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
          enum:
            - GreaterCode
            - LesserCode
            - EffectiveDate
            - EndDate
            - FromDate
            - CLEId
            - CodeType
            - ModifierIndicator
            - IsOverride
            - Source
            - ToDate
            - IsValid
        SearchPattern:
          type: string
          enum:
            - Default
            - EqualTo
            - Contains
            - EndsWith
            - StartsWith
            - NotEqualTo
            - GreaterThanOrEqualTo
            - LessThanOrEqualTo
    NationalCorrectCodingInitiativeQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfNationalCorrectCodingInitiativeView'
        -
          type: object
          additionalProperties: false
          properties:
            SortField:
              type: string
              enum:
                - GreaterCode
                - LesserCode
                - EffectiveDate
                - EndDate
                - FromDate
                - CLEId
                - CodeType
                - ModifierIndicator
                - IsOverride
                - Source
                - ToDate
                - IsValid
            Where:
              $ref: '#/components/schemas/NationalCorrectCodingInitiativeQueryParms'
    NationalCorrectCodingInitiativeQueryRequest:
      allOf:
        - { $ref: '#/components/schemas/NationalCorrectCodingInitiativeQuery' }

    NationalCorrectCodingInitiativeQueryResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/NationalCorrectCodingInitiativeView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }

    NationalCorrectCodingInitiativeQueryParms:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            FromDate:
              type: string
              format: date-time
              nullable: true
            GreaterCode:
              type: string
            IsValid:
              type: boolean
            LesserCode:
              type: string
            NCCIFilters:
              type: array
              items:
                $ref: '#/components/schemas/NCCIFilter'
            NCCIType:
              type: string
            NationalCorrectCodingInitiativeId:
              type: string
            SearchBy:
              type: string
            SearchDateType:
              type: string
            Source:
              type: string
            ToDate:
              type: string
              format: date-time
              nullable: true
    NationalCorrectCodingInitiativeView:
      type: object
      additionalProperties: false
      properties:
        CLEId:
          type: string
        CodeType:
          type: string
        CreatedDate:
          type: string
          format: date-time
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        GreaterCode:
          type: string
        IsOverride:
          type: boolean
        IsValid:
          type: boolean
        LastModifiedDate:
          type: string
          format: date-time
        LesserCode:
          type: string
        ModifierIndicator:
          type: string
        NCCIType:
          type: string
        NationalCorrectCodingInitiativeId:
          type: string
          format: uuid
        SourceCode:
          type: string
    Query:
      type: object
      additionalProperties: false
      properties:
        ByPassCountQuery:
          type: boolean
        CurrentPage:
          type: integer
          format: int32
        CycleDate:
          type: string
          format: date-time
          nullable: true
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfAuditEventModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditEventModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfAuditObjectModel:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/AuditObjectModel'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExceptionErrorRestrictionView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExceptionErrorRestrictionView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExceptionErrorResultView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExceptionErrorResultView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExceptionErrorView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExceptionErrorView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExceptionInformationRestrictionView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExceptionInformationRestrictionView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExceptionInformationResultView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExceptionInformationResultView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExceptionInformationView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExceptionInformationView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExplanationOfBenefitCodeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExplanationOfBenefitCodeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExplanationOfBenefitRestrictionView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExplanationOfBenefitRestrictionView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExplanationOfBenefitResultView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExplanationOfBenefitResultView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfExplanationOfBenefitView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/ExplanationOfBenefitView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfMedicallyUnlikelyEditView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/MedicallyUnlikelyEditView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    QueryOfNationalCorrectCodingInitiativeView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/NationalCorrectCodingInitiativeView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    SearchFieldsSearchPattern:
      type: string
      enum:
        - Default
        - EqualTo
        - Contains
        - EndsWith
        - StartsWith
        - NotEqualTo
        - GreaterThanOrEqualTo
        - LessThanOrEqualTo
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortEnumerationsExceptionErrorFieldType:
      type: string
      enum:
        - Module
        - Code
        - Description
        - Ranking
        - Severity
        - Assignment
        - Override
        - Disposition
        - EOB
        - EffectiveDate
        - EndDate
        - IsValid
    SortEnumerationsExceptionInformationFieldType:
      type: string
      enum:
        - Module
        - Code
        - Description
        - Type
        - Ranking
        - Assignment
        - EOB
        - EffectiveDate
        - EndDate
        - IsValid
    SortEnumerationsExplanationOfBenefitFieldType:
      type: string
      enum:
        - Module
        - Code
        - Description
        - CARC
        - RARC
        - EffectiveDate
        - EndDate
        - IsValid
    SortEnumerationsMUEFieldType:
      type: string
      enum:
        - Code
        - EffectiveDate
        - EndDate
        - MUEValue
        - Default
        - MUEType
        - CLEID
        - Publication
        - IsOverride
        - Source
        - IsValid
    SortEnumerationsNCCIFieldType:
      type: string
      enum:
        - GreaterCode
        - LesserCode
        - EffectiveDate
        - EndDate
        - FromDate
        - CLEId
        - CodeType
        - ModifierIndicator
        - IsOverride
        - Source
        - ToDate
        - IsValid
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
```

### B.8 `cycle-schedule.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Cycle Schedule API
  version: 0.1.0
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/cycle-schedule/search:
    post:
      operationId: SearchCycleScheduleDetails
      summary: Search cycle schedules
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CycleScheduleSearchRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CycleScheduleSearchResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/cycle-schedule:
    post:
      operationId: AddCycle
      summary: Create cycle schedule (draft)
      parameters:
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CycleScheduleCreateRequest' }
      responses:
        '201':
          description: Created
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CycleSchedule' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/cycle-schedule/{cycleScheduleId}:
    get:
      operationId: GetCycleScheduleDetails
      summary: Get cycle schedule
      parameters:
        - name: cycleScheduleId
          in: path
          required: true
          schema: { type: string, format: uuid }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CycleSchedule' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
    patch:
      operationId: UpdateCycle
      summary: Edit cycle schedule (draft)
      parameters:
        - name: cycleScheduleId
          in: path
          required: true
          schema: { type: string, format: uuid }
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CycleSchedulePatchRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CycleSchedule' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/cycle-schedule/batch-details:
    post:
      operationId: GetCycleScheduleBatchDetails
      summary: Get cycle schedule details for batch
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CycleScheduleBatchDetailsRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CycleScheduleBatchDetailsResponse' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }

  /v1/cycle-schedule/edit-from-batch:
    post:
      operationId: EditCycleDetailsFromBatch
      summary: Edit cycle schedule details from batch
      parameters:
        - name: X-Idempotency-Key
          in: header
          required: true
          schema: { type: string, minLength: 1, maxLength: 200 }
      requestBody:
        required: true
        content:
          application/json:
            schema: { $ref: '#/components/schemas/CycleScheduleEditFromBatchRequest' }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: '#/components/schemas/CycleSchedule' }
        '400': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '401': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '403': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    AddCycleCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            CycleNameId:
              type: string
            Description:
              type: string
            EffectiveDate:
              type: string
              format: date-time
            EndDate:
              type: string
              format: date-time
            FrequencyCode:
              type: string
            ModuleNameId:
              type: string
            ParameterEndDate:
              type: string
              format: date-time
            ParameterStartDate:
              type: string
              format: date-time
            TenantModuleId:
              type: string
    BaseModel:
      type: object
      additionalProperties: false
      properties: {}
    Command:
      type: object
      additionalProperties: false
      properties:
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        ViewTimeStamp:
          type: string
          format: date-time
    CoreEnumerationsMessagingIdentifierIdType:
      type: string
      enum:
        - User
        - System
    CycleAdded:
      allOf:
        -
          $ref: '#/components/schemas/CycleEvents'
        -
          type: object
          additionalProperties: false
          properties:
            CycleNameId:
              type: string
            Description:
              type: string
            EffectiveDate:
              type: string
              format: date-time
            EndDate:
              type: string
              format: date-time
            FrequencyCode:
              type: string
            ModuleNameId:
              type: string
            ParameterEndDate:
              type: string
              format: date-time
            ParameterStartDate:
              type: string
              format: date-time
            TenantModuleId:
              type: string
    CycleEvents:
      allOf:
        -
          $ref: '#/components/schemas/Event'
        -
          type: object
          additionalProperties: false
          properties:
            ScheduleId:
              type: string
    CycleSchedule:
      $ref: '#/components/schemas/CycleAdded'
    CycleScheduleBatchDetailsRequest:
      $ref: '#/components/schemas/CycleScheduleBatchQuery'
    CycleScheduleBatchDetailsResponse:
      $ref: '#/components/schemas/CycleScheduleBatchQuery'
    CycleScheduleBatchQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfCycleScheduleView'
        -
          type: object
          additionalProperties: false
          properties:
            Where:
              $ref: '#/components/schemas/CycleScheduleBatchQueryParams'
    CycleScheduleBatchQueryParams:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            CycleNameCode:
              type: string
            FrequencyCode:
              type: string
            ModuleNameCode:
              type: string
    CycleScheduleCreateRequest:
      $ref: '#/components/schemas/AddCycleCommand'
    CycleScheduleEditFromBatchRequest:
      $ref: '#/components/schemas/UpdateCycleBatchCommand'
    CycleSchedulePatchRequest:
      $ref: '#/components/schemas/UpdateCycleCommand'
    CycleScheduleQueryParams:
      allOf:
        -
          $ref: '#/components/schemas/SerializableBase'
        -
          type: object
          additionalProperties: false
          properties:
            CycleNameCode:
              type: string
            CycleScheduleId:
              type: string
              format: uuid
            Description:
              type: string
            DescriptionFilterMode:
              type: string
            EffectiveDate:
              type: string
              format: date-time
              nullable: true
            EffectiveDateFilterMode:
              type: string
            EndDate:
              type: string
              format: date-time
              nullable: true
            EndDateFilterMode:
              type: string
            Frequency:
              type: array
              items:
                type: string
            FrequencyCode:
              type: string
            FrequencyFilterMode:
              type: string
            ModuleNameCode:
              type: string
            ParameterEndDate:
              type: string
              format: date-time
              nullable: true
            ParameterEndDateFilterMode:
              type: string
            ParameterStartDate:
              type: string
              format: date-time
              nullable: true
            ParameterStartDateFilterMode:
              type: string
    CycleScheduleSearchRequest:
      type: object
      additionalProperties: false
      description: Same paging and casing convention as the other search requests (CurrentPage, PageSize, SortField, Where).
      properties:
        CurrentPage: { type: integer, minimum: 1 }
        PageSize: { type: integer, minimum: 1, maximum: 500 }
        SortField:
          $ref: '#/components/schemas/SortEnumerationsCycleScheduleFieldType'
        Where:
          $ref: '#/components/schemas/CycleScheduleQueryParams'
    CycleScheduleSearchResponse:
      type: object
      additionalProperties: false
      required: [items, page]
      properties:
        items:
          type: array
          items: { $ref: '#/components/schemas/CycleScheduleView' }
        page: { $ref: 'common.openapi.yaml#/components/schemas/SearchPage' }
    CycleScheduleView:
      type: object
      additionalProperties: false
      properties:
        CycleNameId:
          type: string
        CycleScheduleId:
          type: string
          format: uuid
        Description:
          type: string
        EffectiveDate:
          type: string
          format: date-time
        EndDate:
          type: string
          format: date-time
        FrequencyCode:
          type: string
        ModuleNameId:
          type: string
        ParameterEndDate:
          type: string
          format: date-time
        ParameterStartDate:
          type: string
          format: date-time
        TenantModuleId:
          type: string
    Event:
      type: object
      additionalProperties: false
      properties:
        ApplicationName:
          type: string
        CommitId:
          type: string
          format: uuid
          nullable: true
        CorrelationId:
          type: string
        EventID:
          type: string
        ModelID:
          type: string
        ModelType:
          type: string
        Timestamp:
          type: string
          format: date-time
          nullable: true
        UserID:
          type: string
        UserIp:
          type: string
    Query:
      type: object
      additionalProperties: false
      properties:
        ByPassCountQuery:
          type: boolean
        CurrentPage:
          type: integer
          format: int32
        PageSize:
          type: integer
          format: int32
        Requestor:
          $ref: '#/components/schemas/RequestorModel'
        RowCount:
          type: integer
          format: int32
        ViewTimeStamp:
          type: string
          format: date-time
    QueryOfCycleScheduleView:
      allOf:
        -
          $ref: '#/components/schemas/Query'
        -
          type: object
          additionalProperties: false
          properties:
            Results:
              type: array
              items:
                $ref: '#/components/schemas/CycleScheduleView'
            SortCriteria:
              type: array
              items:
                $ref: '#/components/schemas/SortCriteria'
    RequestorModel:
      allOf:
        -
          $ref: '#/components/schemas/BaseModel'
        -
          type: object
          additionalProperties: false
          properties:
            ApplicationName:
              type: string
            BrowserInfo:
              type: string
            CorrelationId:
              type: string
            IdentifierId:
              type: string
            IdentifierIdType:
              type: string
              enum:
                - User
                - System
            IpAddress:
              type: string
            LocaleCode:
              type: string
            RequestDate:
              type: string
              format: date-time
            TenantId:
              type: string
    SearchCycleScheduleQuery:
      allOf:
        -
          $ref: '#/components/schemas/QueryOfCycleScheduleView'
        -
          type: object
          additionalProperties: false
          properties:
            SortField:
              type: string
              enum:
                - Module
                - Cycle
                - Description
                - PSD
                - PED
                - EffectiveDate
                - EndDate
                - Frequency
            Where:
              $ref: '#/components/schemas/CycleScheduleQueryParams'
    SerializableBase:
      type: object
      additionalProperties: false
      properties: {}
    SortCriteria:
      type: object
      additionalProperties: false
      properties:
        FieldName:
          type: string
        Order:
          type: string
          enum:
            - Asc
            - Desc
    SortEnumerationsCycleScheduleFieldType:
      type: string
      enum:
        - Module
        - Cycle
        - Description
        - PSD
        - PED
        - EffectiveDate
        - EndDate
        - Frequency
    SortOrder:
      type: string
      enum:
        - Asc
        - Desc
    UpdateCycleBatchCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            ParameterEndDate:
              type: string
              format: date-time
            ParameterStartDate:
              type: string
              format: date-time
            ScheduleId:
              type: string
              format: uuid
    UpdateCycleCommand:
      allOf:
        -
          $ref: '#/components/schemas/Command'
        -
          type: object
          additionalProperties: false
          properties:
            CycleNameId:
              type: string
            Description:
              type: string
            EffectiveDate:
              type: string
              format: date-time
            EndDate:
              type: string
              format: date-time
            FrequencyCode:
              type: string
            ModuleNameId:
              type: string
            ParameterEndDate:
              type: string
              format: date-time
            ParameterStartDate:
              type: string
              format: date-time
            ScheduleId:
              type: string
```

### B.9 `platform-status.openapi.yaml`

```yaml
openapi: 3.0.3
info:
  title: Plan Management - Platform Status API
  version: 0.2.0
  description: >-
    Publication status of outbox events and import job status. These are platform endpoints
    with no legacy business equivalent (Appendix M.2). Served by the Rate Setting Service.
servers:
  - url: /
security:
  - bearerAuth: []
paths:
  /v1/rate-setting/publication-status:
    get:
      operationId: GetPublicationStatus
      summary: Publication status per change (pm_publication_status)
      parameters:
        - name: aggregateId
          in: query
          required: true
          schema: { type: string, format: uuid }
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema:
                type: array
                items: { $ref: '#/components/schemas/PublicationStatus' }
  /v1/rate-setting/publication-status/{eventId}:retry:
    parameters:
      - name: eventId
        in: path
        required: true
        schema: { type: string, format: uuid }
    post:
      operationId: RetryPublication
      summary: Retry a failed publication (BR-025)
      responses:
        '202':
          description: Accepted
          content:
            application/json:
              schema: { $ref: '#/components/schemas/PublicationStatus' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
        '409': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
  /v1/{area}/imports/{importId}:
    parameters:
      - name: area
        in: path
        required: true
        schema:
          type: string
          enum: [ndc, code-information, grouping, fee-schedule, rate-setting, related-information]
      - name: importId
        in: path
        required: true
        schema: { type: string, format: uuid }
    get:
      operationId: GetImportStatus
      summary: Import job status, statistics and error file reference
      responses:
        '200':
          description: OK
          content:
            application/json:
              schema: { $ref: 'common.openapi.yaml#/components/schemas/ImportStatusResponse' }
        '404': { $ref: 'common.openapi.yaml#/components/responses/Problem' }
components:
  securitySchemes:
    bearerAuth:
      $ref: 'common.openapi.yaml#/components/securitySchemes/bearerAuth'
  schemas:
    PublicationStatus:
      type: object
      required: [eventId, aggregateType, aggregateId, versionNumber, status, attempts]
      properties:
        eventId: { type: string, format: uuid }
        aggregateType: { type: string }
        aggregateId: { type: string, format: uuid }
        versionNumber: { type: integer }
        status:
          type: string
          enum: [Pending, Published, Failed]
        attempts: { type: integer }
        lastError: { type: string, nullable: true }
        publishedAt: { type: string, format: date-time, nullable: true }
```

## Appendix C — BFF Contracts

This appendix defines the composed (aggregated/orchestrated) contracts exposed by the shared NestJS 10 BFF for the Plan Management module.

- Base path: /api/plan-management
- Purpose: UI-facing, screen-optimized view models and orchestration
- Non-goals: The BFF does not own business rules and has no DB access.

Note: Appendix B defines the domain API contracts (/v1/...). §5.2 lists wildcard pass-through routes; those are not repeated here.

---

### C.1 Common Conventions

#### C.1.1 Authentication & Authorization

- Authorization header: Authorization: Bearer <JWT> required.
- Tenant/user identity derived from JWT (tenant_id, sub, roles/scopes).

#### C.1.2 Correlation, Tracing, Idempotency

- X-Correlation-Id optional inbound; always returned.
- X-Idempotency-Key required on every mutating orchestration endpoint (Appendix A.1.3).

#### C.1.3 Error Model (ProblemDetails)

- All errors are application/problem+json.
- Standard statuses: 400, 401, 403, 404, 409, 429, 502, 503, 504. Validation failures are `400` with field errors in `errors` (Appendix A.1.4).

---

### C.2 Composed Endpoints

#### C.2.1 Import Upload URL

POST /api/plan-management/imports/upload-url

- Returns a pre-signed S3 URL.

#### C.2.2 Import Initiate

POST /api/plan-management/imports

- Starts an import job after upload; returns `importId`.

#### C.2.3 Import Summary

GET /api/plan-management/imports/{importId}

- Combines import status, record statistics (processed, errored, total) and the error-file download link (legacy File Upload page, SPG p.107).

#### C.2.4 Exports

POST /api/plan-management/exports

- Exports the current search result to Excel or PDF, or to the upload template (legacy Export, UG p.3); produces the grouping PDF report (legacy `GroupingReportService`).

#### C.2.5 Lookups / DataLists

GET /api/plan-management/lookups/{datalist}

- Cached DataList values from Configuration Management for dropdowns and typeaheads, including the maintenance level of code sets (BR-019).

---

## Appendix D — Database Schema

### D.1 Conventions

- Aurora PostgreSQL, database-per-tenant (§9.1, AS-01). Every table is in schema `plan` of the state's operational database `pp_{tenant}`, except the shared national code-set tables (`pm_code`, `pm_ndc`, `pm_manufacturer`, `pm_drug_classification`, `pm_labeler`, `pm_hcpcs_ndc_association`, `pm_ndc_status`), which are in schema `plan` of `db_shared`.
- Each shared table is preceded by the comment `-- db: db_shared  schema: plan`. A table without that comment is in `pp_{tenant}`, schema `plan`.
- Foreign keys exist only between tables in the same database.
- References from tenant tables to `db_shared` tables are logical (no cross-database foreign keys) and are checked by the service.
- Table names use the `pm_` prefix.
- Primary keys: `uuid` (`gen_random_uuid()`).
- Effective dating:
  - `effective_date date not null`
  - `end_date date null` (null = open-ended)
- Audit:
  - `created_at`, `created_by`, `updated_at`, `updated_by`
- Where business keys must not overlap over time: `daterange` + exclusion constraint.
- Wide legacy “restriction”/criteria models are represented as:
  - dedicated tables when they are query-critical, otherwise
  - JSON (`*_json jsonb`).

### D.2 Platform Tables

```sql
create extension if not exists pgcrypto;

create table if not exists pm_outbox_event (
  event_id uuid primary key,
  event_type text not null,
  occurred_at timestamptz not null,
  aggregate_type text not null,
  aggregate_id uuid not null,
  version_number int not null,
  correlation_id text null,
  payload_json jsonb not null,
  published_at timestamptz null
);

create index if not exists ix_pm_outbox_unpublished
  on pm_outbox_event (occurred_at)
  where published_at is null;

create table if not exists pm_import_job (
  import_id uuid primary key,
  domain text not null,
  source text not null,
  status text not null,
  submitted_at timestamptz not null,
  started_at timestamptz null,
  completed_at timestamptz null,
  summary_json jsonb null
);
```

### D.3 Domain Tables

#### D.3.1 Grouping

```sql
create table if not exists pm_grouping (
  grouping_id uuid primary key default gen_random_uuid(),
  module_name text not null,
  group_name text not null,
  source_content_id text not null,
  is_valid boolean not null default true,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create index if not exists ix_pm_grouping_name
  on pm_grouping (module_name, group_name);

create table if not exists pm_grouping_item (
  grouping_item_id uuid primary key default gen_random_uuid(),
  grouping_id uuid not null references pm_grouping(grouping_id) on delete cascade,
  group_from text not null,
  group_to text not null,
  group_type text null,
  is_valid boolean not null default true,
  effective_date date not null,
  end_date date null
);
```

#### D.3.2 Cycle schedule

```sql
create table if not exists pm_cycle_schedule (
  cycle_schedule_id uuid primary key default gen_random_uuid(),
  module_id text not null,
  application_id text not null,
  tenant_module_id text not null,
  cycle_effective_date date not null,
  cycle_end_date date not null,
  filter_start_date date not null,
  filter_end_date date not null,
  frequency_code text null,
  description text null,
  is_valid boolean not null default true,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);
```

#### D.3.3 Code information (normalized target)

```sql
-- db: db_shared  schema: plan
create table if not exists pm_code (
  code_id uuid primary key default gen_random_uuid(),
  code_system text not null,            -- HCPCS, ICD9_DIAG, ICD9_PROC, ICD10_DIAG, ICD10_PROC, DRG, REVENUE, DENTAL, MODIFIER
  code text not null,
  description text null,
  effective_date date not null,
  end_date date null,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create index if not exists ix_pm_code_lookup
  on pm_code (code_system, code, effective_date desc);

-- db: pp_{tenant}  schema: plan
-- State additions and edits of national codes (§2.1.3). The same pattern is used for
-- pm_ndc_state, pm_manufacturer_state, pm_drug_classification_state, pm_labeler_state,
-- pm_ndc_status_state and pm_hcpcs_ndc_association_state: identical business columns
-- to the national table, plus base_id, change_request_code and source.
create table if not exists pm_code_state (
  code_state_id uuid primary key default gen_random_uuid(),
  base_id uuid null,                     -- logical reference to db_shared.plan.pm_code; null = state-only code
  code_system text not null,
  code text not null,
  description text null,
  long_description text null,
  effective_date date not null,
  end_date date null,
  is_valid boolean not null default true,
  change_request_code text not null,     -- BR-012
  source text not null check (source in ('Online','Upload','ClientEvent')),
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create index if not exists ix_pm_code_state_lookup
  on pm_code_state (code_system, code, effective_date desc);

-- db: pp_{tenant}  schema: plan
create table if not exists pm_code_restriction (
  restriction_id uuid primary key default gen_random_uuid(),
  code_id uuid not null,                 -- logical reference to db_shared.plan.pm_code or pm_code_state (no cross-database FK)
  restriction_type text not null,        -- code system of the restriction: HCPCS, DENTAL, DRG, ICD9_DIAG, ICD9_PROC, ICD10_DIAG, ICD10_PROC, REVENUE
  restriction_json jsonb not null,
  effective_date date not null,
  end_date date null
);

create index if not exists ix_pm_code_restriction_code
  on pm_code_restriction (code_id, restriction_type, effective_date desc);
```

One `pm_code_restriction` row replaces one legacy parent restriction row (`HCPCS_RESTRICT`, `DENTAL_RESTRICT`, `DRG_RESTRICT`, `ICD*_RESTRICT`, `REV_RESTRICT`). The legacy child tables (`*_RESTRICT_MOD`, `*_SVCPLC`, `*_ICD*_DIAG`, `*_ICD*_PROC`, `*_HCPCS`, `*_QUAD`, `*_TOOTH_NUM`, `*_TOOTH_SURF`, `REV_RESTRICT_BILL_TYPE`) become arrays inside `restriction_json`. JSON keys are the property names of the matching `*RestrictionView` schema in Appendix B.3, in camel case. Synthetic example:

```json
{
  "gender": "F",
  "ageMinimum": 18,
  "ageMaximum": 64,
  "modifierType": "Include",
  "modifiers": ["AA", "BB"],
  "placeOfServiceType": "Include",
  "placeOfServiceCodes": ["11", "22"],
  "icd10DiagnosisType": "Group",
  "icd10DiagnosisGroupId": "00000000-0000-0000-0000-0000000000a1",
  "icd10DiagnosisCodes": [],
  "isAssistantSurgeon": false,
  "medicareCoverage": "C"
}
```

#### D.3.4 NDC reference + rates

```sql
-- db: db_shared  schema: plan
create table if not exists pm_manufacturer (
  manufacturer_id uuid primary key default gen_random_uuid(),
  manufacturer_name text not null,
  status text not null,
  version_number int not null,
  effective_date date not null,
  end_date date null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

-- db: db_shared  schema: plan
create table if not exists pm_drug_classification (
  drug_classification_id uuid primary key default gen_random_uuid(),
  classification_code text not null,
  classification_name text not null,
  status text not null,
  version_number int not null,
  effective_date date not null,
  end_date date null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

-- db: db_shared  schema: plan
create table if not exists pm_ndc (
  ndc_id uuid primary key default gen_random_uuid(),
  ndc11 text not null,
  label_name text null,
  dosage_form text null,
  strength text null,
  manufacturer_id uuid null references pm_manufacturer(manufacturer_id),
  drug_classification_id uuid null references pm_drug_classification(drug_classification_id),
  effective_date date not null,
  end_date date null,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create index if not exists ix_pm_ndc_lookup
  on pm_ndc (ndc11, effective_date desc);

-- db: pp_{tenant}  schema: plan
create table if not exists pm_ndc_rate (
  ndc_rate_id uuid primary key default gen_random_uuid(),
  ndc11 text not null,
  rate_type text not null,
  pricing_method text not null,
  rate_value numeric(18,6) not null,
  dispensing_fee numeric(18,6) null,
  effective_date date not null,
  end_date date null,
  status text not null,
  version_number int not null
);

create index if not exists ix_pm_ndc_rate_lookup
  on pm_ndc_rate (ndc11, rate_type, effective_date desc);

-- Legacy NATIONAL_DRUG_CODE_REBATE (B.2 NationalDrugCodeRebateView); rebates are state-specific
create table if not exists pm_ndc_rebate (
  ndc_rebate_id uuid primary key default gen_random_uuid(),
  ndc11 text not null,                    -- logical reference to db_shared.plan.pm_ndc
  rebate_indicator boolean not null,
  effective_date date not null,
  end_date date null,
  is_valid boolean not null default true,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create index if not exists ix_pm_ndc_rebate_lookup
  on pm_ndc_rebate (ndc11, effective_date desc);

-- db: db_shared  schema: plan
-- Legacy LABELER (UG p.68–71): labeler code and name; rebate programs in pm_labeler_rebate_program
create table if not exists pm_labeler (
  labeler_id uuid primary key default gen_random_uuid(),
  labeler_code text not null,             -- first segment of the NDC
  labeler_name text not null,
  manufacturer_id uuid null references pm_manufacturer(manufacturer_id),
  effective_date date not null,
  end_date date null,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create unique index if not exists ux_pm_labeler_code
  on pm_labeler (labeler_code, effective_date);

-- NDC packages (UG p.64, 67); FDB-supplied, editable by state users
create table if not exists pm_ndc_package (
  ndc_package_id uuid primary key default gen_random_uuid(),
  ndc11 text not null,                    -- logical reference to pm_ndc / pm_ndc_state
  package_code text not null,             -- DataList NDCPackage
  package_size numeric(18,6) null,
  effective_date date not null,
  end_date date null,
  is_valid boolean not null default true,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

-- Legacy LABELER_PROGRAM_TYPE: labeler rebate programs (UG p.68–71). Q-28 answered.
create table if not exists pm_labeler_rebate_program (
  labeler_rebate_program_id uuid primary key default gen_random_uuid(),
  labeler_code text not null,             -- logical reference to pm_labeler / pm_labeler_state
  rebate_program_code text not null,      -- DataList InvoiceType (e.g. AA, MA, MM)
  effective_date date not null,
  end_date date null,
  is_valid boolean not null default true,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

-- db: db_shared  schema: plan
-- Legacy CMS_STATUS (status_source = 'CMS') and NATIONAL_DRUG_CODE_COD (status_source = 'COD'); placement per AS-12
create table if not exists pm_ndc_status (
  ndc_status_id uuid primary key default gen_random_uuid(),
  ndc_id uuid not null references pm_ndc(ndc_id),
  status_source text not null check (status_source in ('CMS','COD')),
  status_code text null,                  -- COD status; null for CMS rows
  source_code text null,
  added_date date null,
  effective_date date null,
  end_date date null,
  inactivated_date date null,
  termination_date date null,
  date_term_reported date null,
  last_updated_date date null,
  is_valid boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- db: db_shared  schema: plan
-- Legacy HCPCS_NDC_ASSCN (B.3 HCPCSNDCASSCNView); placement per AS-12
create table if not exists pm_hcpcs_ndc_association (
  hcpcs_ndc_association_id uuid primary key default gen_random_uuid(),
  hcpcs_code_id uuid not null references pm_code(code_id),
  ndc_id uuid not null references pm_ndc(ndc_id),
  gsn text null,
  conversion_factor numeric(18,6) null,
  is_ndc_required boolean not null default false,
  source text null,
  date_added date null,
  date_updated date null,
  date_inactivated date null,
  effective_date date not null,
  end_date date null,
  is_valid boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
```

Overlap protection pattern:

```sql
create extension if not exists btree_gist;

alter table pm_ndc_rate
  add column if not exists effective_range daterange
  generated always as (daterange(effective_date, coalesce(end_date, 'infinity'::date), '[]')) stored;

-- PostgreSQL has no ADD CONSTRAINT IF NOT EXISTS; the Alembic revision adds the constraint once.
alter table pm_ndc_rate
  add constraint ex_pm_ndc_rate_no_overlap
  exclude using gist (ndc11 with =, rate_type with =, effective_range with &&);
```

#### D.3.5 Fee schedule (field-driven)

```sql
create table if not exists pm_fee_schedule (
  fee_schedule_id uuid primary key default gen_random_uuid(),
  schedule_id text not null,
  schedule_name text not null,
  schedule_rules text null,
  release_status text not null check (release_status in ('Pending','Test','Release','Delete')),  -- BR-015
  change_request_code text not null,      -- BR-012
  is_locked boolean not null default false,  -- set while a batch upload runs
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create index if not exists ix_pm_fee_schedule_schedule_id
  on pm_fee_schedule (schedule_id);

create table if not exists pm_fee_schedule_field (
  fee_schedule_field_id uuid primary key default gen_random_uuid(),
  fee_schedule_id uuid not null references pm_fee_schedule(fee_schedule_id) on delete cascade,
  field_code text not null,
  is_required boolean not null,
  is_business_identifier boolean not null,
  order_index int not null,
  check (not is_business_identifier or is_required)   -- BR-016
);

create table if not exists pm_fee_schedule_line (
  fee_schedule_line_id uuid primary key default gen_random_uuid(),
  fee_schedule_id uuid not null references pm_fee_schedule(fee_schedule_id) on delete cascade,
  effective_date date not null,
  end_date date null,
  is_valid boolean not null default true,
  processing_start_date date null,        -- BR-009
  processing_end_date date null,
  rate_amount numeric(18,6) null,
  rate_percent numeric(18,6) null,
  adjustment_factor numeric(18,6) null,
  units numeric(18,6) null,
  criteria_json jsonb not null default '{}'::jsonb,       -- values of the chosen fields; identifiers form the key (BR-016)
  optional_fields_json jsonb not null default '[]'::jsonb,
  version_number int not null default 1,
  check (rate_amount is not null or rate_percent is not null)  -- BR-007
);

-- Legacy FEE_SCHED_FIELD_DEF (B.5 FeeScheduleFieldDefinitionView); used by SearchFieldDefinition
create table if not exists pm_fee_schedule_field_definition (
  fee_schedule_field_definition_id uuid primary key default gen_random_uuid(),
  field_code text not null,
  label_content_id text null,
  data_type text not null,
  data_restriction_type text null,
  datalist_content_id text null,          -- DataList that supplies the values
  min_length int null,
  max_length int null,
  min_value numeric(18,6) null,
  max_value numeric(18,6) null,
  is_valid boolean not null default true,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create unique index if not exists ux_pm_fee_schedule_field_definition
  on pm_fee_schedule_field_definition (field_code);
```

#### D.3.6 Rate setting (provider reference and provider-specific rates)

```sql
-- Local reference copy: migration load (legacy Initial Provider Loader), then CMS-PM provider.* events.
create table if not exists pm_provider (
  provider_id uuid primary key,           -- legacy ProviderId
  provider_external_id text not null,     -- CMS-PM provider id
  provider_billing_id text not null,      -- legacy ProviderBillingId
  enrollment_type_code text not null,     -- legacy EnrollmentTypeCD (F, IG)
  business_name text null,
  first_name text null,                   -- PII: never logged
  last_name text null,                    -- PII: never logged
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  created_by text not null default 'migration',
  updated_at timestamptz not null default now(),
  updated_by text not null default 'migration'
);

create unique index if not exists ux_pm_provider_external
  on pm_provider (provider_external_id);

-- Legacy PROVIDER_SPECIFIC_RATE: Nursing Facility, Encounter, Dispensing Fee, Inpatient, Outpatient (UG p.111–128)
create table if not exists pm_provider_specific_rate (
  provider_specific_rate_id uuid primary key default gen_random_uuid(),
  provider_service_location_id uuid not null,   -- BR-003; references pm_provider_service_location (D.3.6a)
  rate_type text not null check (rate_type in ('NursingFacility','Encounter','DispensingFee','Inpatient','Outpatient')),
  code_type text null,                    -- Revenue, Level of Care, ... (DataList)
  billing_code text null,
  rate_category text null,                -- DataList RateCategory
  encounter_type text null,
  level_of_care_code text null,
  provider_specialty_code text null,      -- Dispensing Fee
  drug_type text null,                    -- Dispensing Fee; null = ALL (BR-018)
  dispensing_type text null,              -- Dispensing Fee; null = ALL (BR-018)
  ingredient_from numeric(18,6) null,
  ingredient_to numeric(18,6) null,
  rate_amount numeric(18,6) null,
  rate_percent numeric(18,6) null,        -- Outpatient Rate Factor
  rate_adjustment text null,              -- DataList RateAdjIndicator
  effective_date date not null,
  end_date date not null default '9999-12-31',
  rate_start_date date null,              -- Processing Start Date (BR-009)
  rate_end_date date null,                -- Processing End Date (BR-009)
  change_request_code text not null,      -- BR-012
  is_valid boolean not null default true, -- BR-014
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null,
  check (rate_amount is not null or rate_percent is not null),   -- BR-007
  check (end_date >= effective_date)                              -- BR-008
);

create index if not exists ix_pm_psr_lookup
  on pm_provider_specific_rate (provider_service_location_id, rate_type, effective_date desc);
-- BR-010 overlap uses the per-type key in §2.2.1 and is checked in the domain layer.
```

#### D.3.6a Rate setting (other legacy rate families and provider reference)

These tables keep their legacy maintenance behaviour (legacy maintenance operations, §2.3.1). Columns come from the Appendix B.6 views. `version_number` supports optimistic concurrency.

```sql
-- Local copy (legacy PROVIDER_SERVICE_LOCATION; Initial Provider Loader fields, SPG p.98–103)
create table if not exists pm_provider_service_location (
  provider_service_location_id uuid primary key,   -- legacy ServiceLocationId
  provider_id uuid not null references pm_provider(provider_id),
  location_id text not null,              -- CMS-PM location id
  provider_billing_id text null,
  location_name text null,                -- for IG providers "LastName, FirstName"
  first_name text null,                   -- PII: never logged
  last_name text null,                    -- PII: never logged
  enrollment_type_code text null,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists ux_pm_provider_service_location
  on pm_provider_service_location (provider_id, location_id);

-- Legacy PROVIDER_UCC_RATE (B.6 ProviderUCCRateView)
create table if not exists pm_provider_ucc_rate (
  provider_ucc_rate_id uuid primary key default gen_random_uuid(),
  provider_service_location_id uuid not null references pm_provider_service_location(provider_service_location_id),  -- BR-003
  procedure_code text not null,
  code_type text null,
  modifier1 text null,
  modifier2 text null,
  modifier3 text null,
  modifier4 text null,
  rate_type text not null,                -- DataList value
  rate_category text not null,            -- DataList RateCategory
  rate_amount numeric(18,6) not null,
  rate_adjustment text null,
  rate_start_date date null,              -- Processing Start Date (BR-009)
  rate_end_date date null,                -- Processing End Date (BR-009)
  effective_date date not null,
  end_date date not null default '9999-12-31',
  change_request_code text not null,      -- BR-012
  is_valid boolean not null default true,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

-- Legacy PROVIDER_DRG_RATE (B.6 ProviderDRGRateView)
create table if not exists pm_provider_drg_rate (
  provider_drg_rate_id uuid primary key default gen_random_uuid(),
  provider_service_location_id uuid not null references pm_provider_service_location(provider_service_location_id),  -- BR-003
  drg_code text not null,
  code_type text null,
  severity_of_illness_code text null,
  rate_type text not null,                -- DataList value
  rate_category text not null,            -- DataList RateCategory
  rate_amount numeric(18,6) not null,
  rate_adjustment text null,
  base_rate numeric(18,6) not null,
  cost_charge_ratio numeric(18,6) not null,
  capital_amount numeric(18,6) null,
  capital_percentage numeric(18,6) null,
  cost_outlier_trim_point numeric(18,6) null,
  cost_percentage numeric(18,6) null,
  day_outlier int null,
  day_outlier_percentage numeric(18,6) null,
  disproportionate_percentage numeric(18,6) null,
  educational_amount numeric(18,6) null,
  educational_percentage numeric(18,6) null,
  paid_percentage numeric(18,6) null,
  rate_start_date date null,              -- Processing Start Date (BR-009)
  rate_end_date date null,                -- Processing End Date (BR-009)
  effective_date date not null,
  end_date date not null default '9999-12-31',
  change_request_code text not null,      -- BR-012
  is_valid boolean not null default true,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

-- Legacy PROVIDER_DRG_CUSTOM (B.6 ProviderDRGCustomView)
create table if not exists pm_provider_drg_custom (
  provider_drg_custom_id uuid primary key default gen_random_uuid(),
  provider_drg_rate_id uuid not null references pm_provider_drg_rate(provider_drg_rate_id) on delete cascade,
  custom_drg_type text not null,
  custom_amount numeric(18,6) null,
  custom_percentage numeric(18,6) null,
  is_valid boolean not null default true,
  updated_at timestamptz not null default now()
);

-- Legacy VOS_TAG (VOSTagView)
create table if not exists pm_vos_tag (
  vos_tag_id uuid primary key default gen_random_uuid(),
  entity_type text not null,              -- e.g. ProviderSpecificRate, HCPCSRestriction
  entity_id uuid not null,
  tag_type_code text not null,
  tag_code text not null,
  vos_effective_date date not null,
  vos_end_date date null,
  is_valid boolean not null default true,
  updated_at timestamptz not null default now()
);

create index if not exists ix_pm_vos_tag_entity
  on pm_vos_tag (entity_type, entity_id);

-- Legacy LOADER_HISTORY (B.6 FileLoaderHistoryView); file bodies are in S3, not in the table
create table if not exists pm_file_loader_history (
  file_loader_history_id uuid primary key default gen_random_uuid(),
  import_id uuid null references pm_import_job(import_id),
  file_upload_code text null,
  type_code text null,
  type_code_id text null,
  source_code text null,
  file_name text not null,
  file_s3_key text not null,
  error_file_name text null,
  error_s3_key text null,
  record_count int null,
  status text not null,
  change_request_code text null,
  upload_date timestamptz not null,
  processed_date timestamptz null,
  created_by text not null
);
```

```sql
-- Member reference copy (legacy MEMBER); stored fields to be confirmed (Q-11, AS-04)
create table if not exists pm_member (
  member_id uuid primary key default gen_random_uuid(),
  member_external_id text not null,       -- Member module id
  member_display_name text null,          -- PII: never logged
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create unique index if not exists ux_pm_member_external on pm_member (member_external_id);

-- Legacy MEMBER_RATE: member-specific rates (UG p.131–133)
create table if not exists pm_member_rate (
  member_rate_id uuid primary key default gen_random_uuid(),
  member_id uuid not null references pm_member(member_id),           -- BR-004
  provider_service_location_id uuid null references pm_provider_service_location(provider_service_location_id),
  code_type text not null,                -- e.g. Level of Care (CRG p.44)
  code text not null,
  rate_amount numeric(18,6) not null,
  effective_date date not null,
  end_date date not null default '9999-12-31',
  rate_start_date date null,              -- Processing Start Date
  rate_end_date date null,                -- Processing End Date
  change_request_code text not null,      -- BR-012
  is_valid boolean not null default true,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);
```

#### D.3.7 Related information (exceptions/EOB/MUE/NCCI/formatted content)

```sql
create table if not exists pm_exception_information (
  exception_information_id uuid primary key default gen_random_uuid(),
  exception_key text not null,
  description text not null,
  external_source_key text null,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create table if not exists pm_exception_information_restriction (
  restriction_id uuid primary key default gen_random_uuid(),
  exception_information_id uuid not null references pm_exception_information(exception_information_id) on delete cascade,
  restriction_json jsonb not null,
  effective_date date not null,
  end_date date null
);

create table if not exists pm_exception_error_code (
  exception_error_code_id uuid primary key default gen_random_uuid(),
  error_code text not null,
  description text not null,
  status text not null,
  version_number int not null,
  effective_date date not null,
  end_date date null
);

create table if not exists pm_exception_error_code_restriction (
  restriction_id uuid primary key default gen_random_uuid(),
  exception_error_code_id uuid not null references pm_exception_error_code(exception_error_code_id) on delete cascade,
  restriction_json jsonb not null,
  effective_date date not null,
  end_date date null
);

create table if not exists pm_explanation_of_benefit (
  explanation_of_benefit_id uuid primary key default gen_random_uuid(),
  eob_code text not null,
  description text not null,
  status text not null,
  version_number int not null,
  effective_date date not null,
  end_date date null
);

create table if not exists pm_explanation_of_benefit_restriction (
  restriction_id uuid primary key default gen_random_uuid(),
  explanation_of_benefit_id uuid not null references pm_explanation_of_benefit(explanation_of_benefit_id) on delete cascade,
  restriction_json jsonb not null,
  effective_date date not null,
  end_date date null
);

create table if not exists pm_formatted_content (
  formatted_content_id uuid primary key default gen_random_uuid(),
  content_type text not null,
  content_text text not null,
  status text not null,
  version_number int not null,
  created_at timestamptz not null default now(),
  created_by text not null,
  updated_at timestamptz not null default now(),
  updated_by text not null
);

create table if not exists pm_edit_rule (
  edit_rule_id uuid primary key default gen_random_uuid(),
  edit_type text not null,               -- MUE or NCCI
  rule_key text not null,                -- business key (composite encoded)
  rule_json jsonb not null,
  effective_date date not null,
  end_date date null,
  status text not null,
  version_number int not null
);
```

### D.4 Legacy → Target Table Mapping

Legacy tables (`UA3_PLAN_MGMT`) and their target tables. Target tables without DDL in D.3 or D.5 mirror the legacy entity columns, using the conventions of D.1. Appendix K.1 lists the disposition of all 80 legacy tables and is authoritative where it differs from D.4.x.

#### D.4.1 Grouping (legacy -> target)

| Legacy table | Legacy entity | Target table |
|---|---|---|
| `GROUPING` | `Grouping` | `pm_grouping` |
| `GROUPING_ITEM` | `GroupingItem` | `pm_grouping_item` |

#### D.4.2 Cycle schedule (legacy -> target)

| Legacy table | Legacy entity | Target table |
|---|---|---|
| `CYCLE_SCHED` | `CycleSchedule` | `pm_cycle_schedule` |

#### D.4.3 Fee schedule (legacy -> target)

| Legacy table | Legacy entity | Target table |
|---|---|---|
| `FEE_SCHED` | `FeeSchedule` | `pm_fee_schedule` |
| `FEE_SCHED_FIELD` | `FeeScheduleField` | `pm_fee_schedule_field` |
| `FEE_SCHED_LINE` | `FeeScheduleLine` | `pm_fee_schedule_line` |
| `FEE_SCHED_OPT_FIELD` | `FeeScheduleLineOptionalField` | `pm_fee_schedule_line.optional_fields_json` |
| `FEE_SCHED_FIELD_DEF` | `FeeScheduleFieldDefinition` | `pm_fee_schedule_field_definition` |

#### D.4.4 Rate setting / provider rates (legacy -> target)

Legacy includes multiple rate families. The target keeps parity: one table per legacy rate family (legacy behaviour preserved).

| Legacy table | Legacy entity | Target table |
|---|---|---|
| `PROVIDER` | `Provider` | `pm_provider` |
| `PROVIDER_SERVICE_LOCATION` | `ProviderServiceLocation` | `pm_provider_service_location` |
| `PROVIDER_SPECIFIC_RATE` | `ProviderSpecificRate` | `pm_provider_specific_rate` |
| `PROVIDER_UCC_RATE` | `ProviderUCCRate` | `pm_provider_ucc_rate` |
| `PROVIDER_DRG_RATE` | `ProviderDRGRate` | `pm_provider_drg_rate` |
| `PROVIDER_DRG_CUSTOM` | `ProviderDRGCustom` | `pm_provider_drg_custom` |
| `MEMBER` | `Member` | `pm_member` |
| `MEMBER_RATE` | `MemberRate` | `pm_member_rate` |
| `LOADER_HISTORY` | `FileLoaderHistory` | `pm_file_loader_history` |
| `VOS_TAG` | `VosTag` | `pm_vos_tag` |

#### D.4.5 Code information + restrictions (legacy -> target)

Legacy has one table per code system and multiple restriction tables. Target uses `pm_code` and `pm_code_restriction` as a normalization layer.

| Legacy table | Target mapping |
|---|---|
| `HCPCS_CODE`, `ICD9_DIAGNOSIS_CODE`, `ICD9_PROCEDURE_CODE`, `ICD10_DIAGNOSIS_CODE`, `ICD10_PROCEDURE_CODE`, `DRG_CODE`, `REV_CODE`, `DENTAL_CODE` | `pm_code` (with `code_system` discriminator) |
| `HCPCS_RESTRICT*`, `ICD9_DIAGNOSIS_RESTRICT`, `ICD9_PROCEDURE_RESTRICT`, `ICD10_DIAGNOSIS_RESTRICT`, `ICD10_PROCEDURE_RESTRICT`, `DRG_RESTRICT`, `REV_RESTRICT*`, `DENTAL_RESTRICT*` | `pm_code_restriction`: one row per parent restriction (`restriction_type` = code system); child tables become arrays in `restriction_json` (D.3.3) |

Also in legacy CodeInformation:
- `HCPCS_NDC_ASSCN` maps to a dedicated association table `pm_hcpcs_ndc_association` in `db_shared` (AS-12).
- Modifier codes (loaded by `ModifierLoader`) are stored in `pm_code` with `code_system = 'MODIFIER'`.

#### D.4.6 NDC reference (legacy -> target)

Legacy NDC tables exist under the CodeInformation domain.

| Legacy table | Target table |
|---|---|
| `NATIONAL_DRUG_CODE` | `pm_ndc` |
| `NATIONAL_DRUG_CODE_RATE` | `pm_ndc_rate` |
| `MANUFACTURER` | `pm_manufacturer` |
| `DRUG_CLASSIFICATION` | `pm_drug_classification` |
| `CMS_STATUS`, `NATIONAL_DRUG_CODE_COD` | `pm_ndc_status` (`status_source` = `CMS` or `COD`) + `pm_ndc_status_state` |
| `NATIONAL_DRUG_CODE_REBATE` | `pm_ndc_rebate` |
| `LABELER` | `pm_labeler` (`db_shared`) + `pm_labeler_state` |
| `LABELER_PROGRAM_TYPE` | `pm_labeler_rebate_program` |

#### D.4.7 Related information (legacy -> target)

| Legacy table | Legacy entity | Target table |
|---|---|---|
| `EXCP_INFO` | `ExceptionInformation` | `pm_exception_information` |
| `EXCP_INFO_RESTRICT` | `ExceptionInformationRestriction` | `pm_exception_information_restriction` |
| `EXCP_ERROR` | `ExceptionErrorCode` | `pm_exception_error_code` |
| `EXCP_ERROR_RESTRICT` | `ExceptionErrorCodeRestriction` | `pm_exception_error_code_restriction` |
| `EXPLN_BENEFIT` | `ExplanationOfBenefit` | `pm_explanation_of_benefit` |
| `EXPLN_BENEFIT_RESTRICT` | `ExplanationOfBenefitRestriction` | `pm_explanation_of_benefit_restriction` |
| `FORMATTED_CONTENT` | `FormattedContent` | `pm_formatted_content` |
| `BUNDLE_MUE`, `BUNDLE_NCCI` | `MedicallyUnlikelyEdit`, `NationalCorrectCodingInitiative` | `pm_edit_rule` (with `edit_type = MUE|NCCI`) |

### D.5 Audit and Publication Tables

```sql
-- Audit of every add and update (BR-023); also serves the legacy /events and /aggregate-delta queries
create table if not exists pm_version_history (
  history_id uuid primary key default gen_random_uuid(),
  aggregate_type text not null,
  aggregate_id uuid not null,
  version_number int not null,
  action text not null,                    -- Added, Updated, Copied, Inserted, Invalidated, Released
  actor text not null,
  source_of_change text not null,          -- Online, Upload, ClientEvent
  change_request_code text null,
  before_json jsonb null,
  after_json jsonb null,
  occurred_at timestamptz not null default now(),
  event_id uuid not null
);

create index if not exists ix_pm_version_history_aggregate
  on pm_version_history (aggregate_type, aggregate_id, occurred_at);

create table if not exists pm_publication_status (
  event_id uuid primary key references pm_outbox_event(event_id),
  aggregate_type text not null,
  aggregate_id uuid not null,
  version_number int not null,
  status text not null,                   -- Pending, Published, Failed
  attempts int not null default 0,
  last_error text null,
  published_at timestamptz null
);
```

DataLists are not stored in Plan Management; they are owned by Configuration Management and read through the shared DataList endpoint (Q-25 answered). The v6 tables `pm_contract_participation`, `pm_fee_schedule_assignment`, `pm_retro_correction`, `pm_provider_eligibility`, `pm_datalist*`, `pm_mco` and `pm_mco_plan` are removed (Appendix M.1).

Legacy audit archive: schema `plan_audit_archive`, read-only, loaded once from legacy `COMMITS`, `SNAPSHOTS` and `EVENT_AUDIT`.

## Appendix E — Event Contracts

Status: Partial — this appendix currently contains an event catalog; AsyncAPI file path TBD.

### E.1 Envelope

| **Field** | **Type** | **Required** | **Rule** |
| --- | --- | --- | --- |
| `tenant_id` | UUID | Yes | From the JWT; never from the payload |
| `event_name` | string | Yes | `<domain>.<stream>.<action>.<version>` |
| `event_version` | string | Yes | `v1`, `v2`, ... |
| `event_id` | UUID | Yes | Generated by the producer; consumers deduplicate on it |
| `occurred_at` | timestamptz | Yes | Business time (UTC) |
| `correlation_id` | UUID | Yes | From the originating request |
| `trace_id` | string | Yes | W3C trace id |
| `producer` | string | Yes | `<service>:<version>`, e.g. `cm-pl-rate-setting-service:1.0.0` |
| `payload` | object | Yes | Includes `aggregate_type`, `aggregate_id`, `version_number` and the changed business fields; no PII |
| `metadata` | object | No | `causation_id`, `user_id`, `environment`, `replay_flag` |

```json
{
  "tenant_id": "00000000-0000-0000-0000-000000000001",
  "event_name": "plan.rate_setting.updated.v1",
  "event_version": "v1",
  "event_id": "7cbd9c74-7c56-4a77-b62c-41e57b8f2b61",
  "occurred_at": "2026-11-02T14:30:00Z",
  "correlation_id": "550e8400-e29b-41d4-a716-446655440000",
  "trace_id": "4bf92f3577b34da6a3ce929d0e0e4736",
  "producer": "cm-pl-rate-setting-service:1.0.0",
  "payload": {
    "aggregate_type": "ProviderSpecificRate",
    "aggregate_id": "2a9a39f5-96a6-4b15-9d9b-7b8b58f4a6c1",
    "version_number": 3,
    "action": "Updated",
    "rate_type": "NursingFacility",
    "effective_date": "2026-01-01",
    "end_date": "9999-12-31",
    "change_request_code": "CR-0001"
  },
  "metadata": { "causation_id": null, "environment": "dev", "replay_flag": false }
}
```

### E.2 Published Events (topic `pp.plan.events`)

Legacy distributed changes through the event store and BizTalk ESB (`EventStoreConnectionString`, CRG p.88). The target publishes the same changes through the Event Adapter. **Open (Q-27):** final payload schemas.

| **Event** | **Producer** | **Raised when** |
| --- | --- | --- |
| `plan.rate_setting.updated.v1` | Rate Setting | A provider-specific, UCC or DRG rate is added, edited, copied, inserted or invalidated (incl. uploads) |
| `plan.member_rate.updated.v1` | Rate Setting | A member-specific rate is added, edited or invalidated |
| `plan.fee_schedule.updated.v1` | Rate Setting | A fee schedule header or line is added, updated, locked or unlocked |
| `fee_schedule.published.v1` | Rate Setting | A fee schedule's Release Status changes to Release |
| `plan.code_information.updated.v1` | Code Information | A code or code restriction is added or changed (national load or state edit) |
| `clinical_code.restriction.changed.v1` | Code Information | A clinical code restriction changes |
| `plan.ndc.reference.updated.v1` | Code Information | NDC, package, manufacturer, labeler or drug classification data changes |
| `plan.ndc.rate.updated.v1` | Code Information | An NDC rate or rebate changes |
| `drug_code.updated.v1` | Code Information | Drug reference data changes (for drug formulary and Drug Rebate consumers) |
| `plan.grouping.updated.v1` | Grouping | A grouping is added, updated, validated or invalidated |
| `plan.related_information.updated.v1` | Related Information | EOB, EEC, EIC, MUE, NCCI or formatted content changes |
| `plan.cycle_schedule.updated.v1` | Related Information | A cycle is added or updated |
| `plan.import.completed.v1` | Batch (Glue) | An import job finishes; payload has `importId`, `domain`, counts |
| `plan.import.failed.v1` | Batch (Glue) | An import job fails; payload has `importId`, `domain`, error summary |

Batch imports publish one domain event per upserted record and one `plan.import.completed.v1` or `plan.import.failed.v1` per import.

### E.3 Consumed Events (topics `pp.provider.events`, `pp.integration.events`)

| **Event** | **Producer** | **Plan Management action** |
| --- | --- | --- |
| `provider.registered.v1` | Provider Management | Upsert `pm_provider` and `pm_provider_service_location` |
| `provider.updated.v1` | Provider Management | Upsert the reference copy, including active flags |
| `provider.terminated.v1` | Provider Management | Set the reference copy inactive; rates are not changed (Q-30) |
| `integration.plan.*.changed.v1` (9 events, §8.1) | CMS-INX | Upsert the matching `*_state` table for level-80 data; no audit record (BR-023) |

### E.4 Legacy Event Names

Legacy event names (e.g. `GroupingAdded`, `FeeScheduleProcessed`, `CycleAdded`, `AttachmentAdded`, `FileUploadCanceled`) are carried in `payload.legacy_event_type` where an operation in Appendix B returns a legacy event shape.

### E.5 Outbox Relay

```mermaid
sequenceDiagram
  autonumber
  participant API as Domain API
  participant DB as Tenant DB (schema plan)
  participant REL as Outbox Relay
  participant EA as Event Adapter
  participant T as SNS/SQS or MSK

  API->>DB: BEGIN
  API->>DB: Write business rows
  API->>DB: Insert pm_outbox_event and pm_publication_status (Pending)
  API->>DB: COMMIT
  REL->>DB: Claim unpublished rows, oldest first (FOR UPDATE SKIP LOCKED)
  REL->>EA: Publish(envelope)
  EA->>T: Deliver on configured transport
  REL->>DB: Set published_at, mark pm_publication_status Published
  Note over REL,DB: On failure, mark Failed and increment attempts
```

## Appendix F — External Interface Specifications

Status: Partial — payload contracts for CMS-PM (Q-07) and CMS-INX (Q-27) events pending.

| Interface | Direction | Mechanism | Contract | Authentication | Timeout / retry / failure | Owner |
|---|---|---|---|---|---|---|
| IRM broker | Out (sign-in, JWKS) | OIDC, FAPI 2.0 | ADR-014 | — | JWKS cached; fail closed | Platform |
| Tenant Registry API | Out (sync) | REST via `hpp_tenant_registry_client` | CM-CORE contract | IAM SigV4 + JWT | Redis 5 min; circuit breaker; fail closed `503` | CM-CORE |
| Configuration Management DataLists | In (values) | Open (Q-32) | TBD | TBD | TBD | Configuration Management |
| CMS-PM provider events | In (async) | Event Backbone `pp.provider.events` | Appendix E.3; CMS-PM schema in Glue Schema Registry (Q-07) | Event Adapter, IAM | Idempotent on `event_id`; DLQ after 3 attempts | CMS-PM |
| CMS-INX client-sourced events | In (async) | Event Backbone `pp.integration.events` | `integration.plan.*.changed.v1` (§8.1; Q-27) | Event Adapter, IAM | Idempotent; DLQ | Integration |
| Plan Management events | Out (async) | Event Backbone `pp.plan.events` | Appendix E.2 | Event Adapter, IAM | Outbox retry; `Failed` visible (BR-025) | CM-PL |
| Vendor files (CMS, FDB, Noridian) | In (batch) | S3 + MWAA + Glue | Appendix I | IAM, tenant S3 prefix | Glue retries; error files | CM-PL |
| Data warehouse / Gainwell Genius | Out (batch) | Tenant-scoped S3 datasets | TBD (Q-12) | IAM | — | Data |
| External file consumers | Out (batch) | S3 + MoveIt | ADR-003 | MoveIt | Per MoveIt | Integration |

## Appendix G — Authorization Matrix

Scopes are issued by IRM broker in the JWT and checked by the BFF and by every service.

Scopes:
- `cmpl.planmanagement.read` → read/search/query/export
- `cmpl.planmanagement.write` → add, edit, copy, insert, invalidate, validate, release, lock/unlock
- `cmpl.planmanagement.batch` → batch imports / file-driven ingestion
- `cmpl.planmanagement.admin` → all of the above

Roles (legacy security roles, CRG p.82–83):
- `pm.rate-viewer` (PLProvRateUser) → `read`
- `pm.rate-analyst` (PLProvRateAnalyst) → `read`, `write` for the seven provider-specific rate types, member-specific rates and fee schedules
- `pm.rate-loader` (PLProvRateLoader) → `read`, `batch` for rate uploads
- `pm.manager` (PLManager) → `read`, `write`, `batch` for reference data
- `pm.admin` (PlanManagement Administrator, SystemAdministrators) → `admin`
- DataList roles (PLDatalist*) belong to Configuration Management.

Maintenance-level rules (BR-019) and the DrugLabelerSource setting (BR-021) further restrict `write` for code sets, NDC data and labelers.

| Area | Method | Path | operationId (legacy) | Scope | Summary |
|---|---|---|---|---|---|
| code-information | POST | `/v1/code-information/aggregate-delta` | `GetCodeInformationAggregateDelta` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetCodeInformationAggregateDelta |
| code-information | GET | `/v1/code-information/dental/{code}` | `GetDentalCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetDentalCode / OData GetDentalCode |
| code-information | GET | `/v1/code-information/drg/{code}` | `GetDRGCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetDRGCode / OData GetDRGCode |
| code-information | POST | `/v1/code-information/events` | `GetCodeInformationEvents` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetCodeInformationEvents |
| code-information | POST | `/v1/code-information/hcpcs-ndc-association/aggregate-delta` | `GetHCPCSNDCAssociationAggregateDelta` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetHCPCSNDCAssociationAggregateDelta |
| code-information | POST | `/v1/code-information/hcpcs-ndc-association/events` | `GetHCPCSNDCAssociationEvents` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetHCPCSNDCAssociationEvents |
| code-information | POST | `/v1/code-information/hcpcs-ndc-association/search` | `SearchHCPCSNDCASSCN` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.SearchHCPCSNDCASSCN |
| code-information | GET | `/v1/code-information/hcpcs/{code}` | `GetHCPCSCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetHCPCSCode / OData GetHCPCSCode |
| code-information | GET | `/v1/code-information/icd10-diagnosis/{code}` | `GetICD10DiagnosisCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetICD10DiagnosisCode / OData GetICD10DiagnosisCode |
| code-information | GET | `/v1/code-information/icd10-procedure/{code}` | `GetICD10ProcedureCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetICD10ProcedureCode / OData GetICD10ProcedureCode |
| code-information | GET | `/v1/code-information/icd9-diagnosis/{code}` | `GetICD9DiagnosisCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetICD9DiagnosisCode / OData GetICD9DiagnosisCode |
| code-information | GET | `/v1/code-information/icd9-procedure/{code}` | `GetICD9ProcedureCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetICD9ProcedureCode / OData GetICD9ProcedureCode |
| code-information | POST | `/v1/code-information/imports/dental` | `UploadDentalCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadDentalCodes |
| code-information | POST | `/v1/code-information/imports/drg` | `UploadDRGCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadDRGCodes |
| code-information | POST | `/v1/code-information/imports/hcpcs` | `UploadHCPCSCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadHCPCSCodes |
| code-information | POST | `/v1/code-information/imports/hcpcs-ndc-association` | `UploadHCPCSNDCASSCNs` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadHCPCSNDCASSCNs |
| code-information | POST | `/v1/code-information/imports/icd10-diagnosis` | `UploadICD10DiagnosisCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadICD10DiagnosisCodes |
| code-information | POST | `/v1/code-information/imports/icd10-procedure` | `UploadICD10ProcedureCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadICD10ProcedureCodes |
| code-information | POST | `/v1/code-information/imports/icd9-diagnosis` | `UploadICD9DiagnosisCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadICD9DiagnosisCodes |
| code-information | POST | `/v1/code-information/imports/icd9-procedure` | `UploadICD9ProcedureCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadICD9ProcedureCodes |
| code-information | POST | `/v1/code-information/imports/revenue` | `UploadRevenueCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchCodeInformationService.UploadRevenueCodes |
| code-information | GET | `/v1/code-information/revenue/{code}` | `GetRevenueCode` | `cmpl.planmanagement.read` | Legacy: ICodeInformationQueryService.GetRevenueCode / OData GetRevenueCode |
| cycle-schedule | POST | `/v1/cycle-schedule` | `AddCycle` | `cmpl.planmanagement.write` | Create cycle schedule (draft) |
| cycle-schedule | POST | `/v1/cycle-schedule/batch-details` | `GetCycleScheduleBatchDetails` | `cmpl.planmanagement.read` | Get cycle schedule details for batch |
| cycle-schedule | POST | `/v1/cycle-schedule/edit-from-batch` | `EditCycleDetailsFromBatch` | `cmpl.planmanagement.write` | Edit cycle schedule details from batch |
| cycle-schedule | POST | `/v1/cycle-schedule/search` | `SearchCycleScheduleDetails` | `cmpl.planmanagement.read` | Search cycle schedules |
| cycle-schedule | GET | `/v1/cycle-schedule/{cycleScheduleId}` | `GetCycleScheduleDetails` | `cmpl.planmanagement.read` | Get cycle schedule |
| cycle-schedule | PATCH | `/v1/cycle-schedule/{cycleScheduleId}` | `UpdateCycle` | `cmpl.planmanagement.write` | Edit cycle schedule (draft) |
| fee-schedule | POST | `/v1/fee-schedule` | `AddFeeSchedule` | `cmpl.planmanagement.write` | Legacy: IFeeScheduleService.AddFeeSchedule |
| fee-schedule | POST | `/v1/fee-schedule/aggregate-delta` | `GetFeeScheduleAggregateDelta` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.GetFeeScheduleAggregateDelta |
| fee-schedule | POST | `/v1/fee-schedule/batch/get` | `GetFeeScheduleBatch` | `cmpl.planmanagement.batch` | Legacy: IFeeScheduleQueryService.GetFeeScheduleBatch |
| fee-schedule | POST | `/v1/fee-schedule/batch/lock` | `LockFeeSchedule` | `cmpl.planmanagement.batch` | Legacy batch: IBatchFeeScheduleService.LockFeeSchedule |
| fee-schedule | POST | `/v1/fee-schedule/batch/unlock` | `UnlockFeeSchedule` | `cmpl.planmanagement.batch` | Legacy batch: IBatchFeeScheduleService.UnlockFeeSchedule |
| fee-schedule | POST | `/v1/fee-schedule/batch/upload` | `UploadFeeSchedule` | `cmpl.planmanagement.batch` | Legacy batch: IBatchFeeScheduleService.UploadFeeSchedule |
| fee-schedule | POST | `/v1/fee-schedule/events` | `GetFeeScheduleEvents` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.GetFeeScheduleEvents |
| fee-schedule | POST | `/v1/fee-schedule/field-definition/search` | `SearchFieldDefinition` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.SearchFieldDefinition |
| fee-schedule | POST | `/v1/fee-schedule/line-aggregate-delta` | `GetFeeScheduleLineAggregateDelta` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.GetFeeScheduleLineAggregateDelta |
| fee-schedule | POST | `/v1/fee-schedule/line-events` | `GetFeeScheduleLineEvents` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.GetFeeScheduleLineEvents |
| fee-schedule | POST | `/v1/fee-schedule/partial/search` | `SearchFeeSchedulePartial` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.SearchFeeSchedulePartial |
| fee-schedule | POST | `/v1/fee-schedule/schedule-id/predictive-search` | `SearchScheduleIdPredictive` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.SearchScheduleIdPredictive |
| fee-schedule | GET | `/v1/fee-schedule/{feeScheduleId}` | `GetFeeSchedule` | `cmpl.planmanagement.read` | Legacy: IFeeScheduleQueryService.GetFeeSchedule |
| fee-schedule | PATCH | `/v1/fee-schedule/{feeScheduleId}` | `UpdateFeeSchedule` | `cmpl.planmanagement.write` | Legacy: IFeeScheduleService.UpdateFeeSchedule |
| fee-schedule | POST | `/v1/fee-schedule/{feeScheduleId}/lines/add` | `AddFeeScheduleLine` | `cmpl.planmanagement.write` | Legacy: IFeeScheduleService.AddFeeScheduleLine |
| fee-schedule | POST | `/v1/fee-schedule/{feeScheduleId}/lines/update` | `UpdateFeeScheduleLine` | `cmpl.planmanagement.write` | Legacy: IFeeScheduleService.UpdateFeeScheduleLine |
| grouping | POST | `/v1/grouping` | `AddGroup` | `cmpl.planmanagement.write` | Legacy: IGroupingService.AddGroup |
| grouping | POST | `/v1/grouping/aggregate-delta` | `GetGroupingAggregateDelta` | `cmpl.planmanagement.read` | Legacy: IGroupingQueryService.GetGroupingAggregateDelta |
| grouping | POST | `/v1/grouping/batch/upload` | `UploadGrouping` | `cmpl.planmanagement.batch` | Legacy batch: IBatchGroupingService.UploadGrouping |
| grouping | POST | `/v1/grouping/code-exists` | `CodeExistsWithinGrouping` | `cmpl.planmanagement.read` | Legacy OData function: CodeExistsWithinGrouping |
| grouping | POST | `/v1/grouping/events` | `GetGroupingEvents` | `cmpl.planmanagement.read` | Legacy: IGroupingQueryService.GetGroupingEvents |
| grouping | POST | `/v1/grouping/items/search` | `SearchGroupingItems` | `cmpl.planmanagement.read` | Legacy: IGroupingQueryService.SearchGroupingItems |
| grouping | POST | `/v1/grouping/name/search` | `SearchGroupingName` | `cmpl.planmanagement.read` | Legacy: IGroupingQueryService.SearchGroupingName |
| grouping | POST | `/v1/grouping/search` | `SearchGroupings` | `cmpl.planmanagement.read` | Legacy: IGroupingQueryService.SearchGroupings / OData SearchGroupings |
| grouping | PATCH | `/v1/grouping/{groupId}` | `UpdateGroup` | `cmpl.planmanagement.write` | Legacy: IGroupingService.UpdateGroup |
| grouping | POST | `/v1/grouping/{groupId}:invalidate` | `InvalidateGroup` | `cmpl.planmanagement.write` | Legacy: IGroupingService.InvalidateGroup |
| grouping | POST | `/v1/grouping/{groupId}:validate` | `ValidateGroup` | `cmpl.planmanagement.write` | Legacy: IGroupingService.ValidateGroup |
| ndc | POST | `/v1/ndc/imports/drug-classification` | `UploadDrugClassification` | `cmpl.planmanagement.batch` | Legacy batch: IBatchNDCInformationService.UploadDrugClassification |
| ndc | POST | `/v1/ndc/imports/manufacturer` | `UploadManufacturer` | `cmpl.planmanagement.batch` | Legacy batch: IBatchNDCInformationService.UploadManufacturer |
| ndc | POST | `/v1/ndc/imports/national-drug-code-rates` | `UploadNationalDrugCodeRates` | `cmpl.planmanagement.batch` | Legacy batch: IBatchNDCInformationService.UploadNationalDrugCodeRates |
| ndc | POST | `/v1/ndc/imports/national-drug-codes` | `UploadNationalDrugCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchNDCInformationService.UploadNationalDrugCodes |
| ndc | POST | `/v1/ndc/search` | `SearchNationalDrugCode` | `cmpl.planmanagement.read` | Legacy: INDCInformationQueryService.SearchNationalDrugCode |
| ndc | POST | `/v1/ndc/search-rates` | `SearchNationalDrugCodeRates` | `cmpl.planmanagement.read` | Legacy: INDCInformationQueryService.SearchNationalDrugCodeRates |
| ndc | GET | `/v1/ndc/{ndc11}` | `GetNationalDrugCode` | `cmpl.planmanagement.read` | Legacy OData function: GetNationalDrugCode |
| rate-setting | POST | `/v1/rate-setting/attachments/add` | `AddAttachmentAndUpdateLoaderHistory` | `cmpl.planmanagement.write` | Legacy: IRateSettingFileUploadService.AddAttachmentAndUpdateLoaderHistory |
| rate-setting | POST | `/v1/rate-setting/batch/upload/provider-drg` | `UploadProviderDRGRates` | `cmpl.planmanagement.batch` | Legacy batch: IBatchProviderRateService.UploadProviderDRGRates |
| rate-setting | POST | `/v1/rate-setting/batch/upload/provider-specific` | `UploadProviderSpecificRates` | `cmpl.planmanagement.batch` | Legacy batch: IBatchProviderRateService.UploadProviderSpecificRates |
| rate-setting | POST | `/v1/rate-setting/batch/upload/provider-ucc` | `UploadProviderUCCRates` | `cmpl.planmanagement.batch` | Legacy batch: IBatchProviderRateService.UploadProviderUCCRates |
| rate-setting | POST | `/v1/rate-setting/file-loader-history/cancel` | `CancelFileLoaderHistory` | `cmpl.planmanagement.write` | Legacy: IRateSettingFileUploadService.CancelFileLoaderHistory |
| rate-setting | POST | `/v1/rate-setting/file-loader-history/search` | `SearchFileLoaderHistories` | `cmpl.planmanagement.read` | Legacy: IRateSettingQueryService.SearchFileLoaderHistories |
| rate-setting | POST | `/v1/rate-setting/provider-drg/search` | `SearchProviderDRGRates` | `cmpl.planmanagement.read` | Legacy: IRateSettingQueryService.SearchProviderDRGRates |
| rate-setting | POST | `/v1/rate-setting/provider-specific/search` | `SearchProviderSpecificRates` | `cmpl.planmanagement.read` | Legacy: IRateSettingQueryService.SearchProviderSpecificRates |
| rate-setting | POST | `/v1/rate-setting/provider-ucc/search` | `SearchProviderUCCRates` | `cmpl.planmanagement.read` | Legacy: IRateSettingQueryService.SearchProviderUCCRates |
| related-information | POST | `/v1/related-information/batch/upload-eob-codes` | `UploadEOBCodes` | `cmpl.planmanagement.batch` | Legacy batch: IBatchRelatedInformationService.UploadEOBCodes |
| related-information | POST | `/v1/related-information/eob-codes/search` | `SearchExplanationOfBenefitCodes` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.SearchExplanationOfBenefitCodes |
| related-information | POST | `/v1/related-information/eobs/restrictions/get` | `GetExplanationOfBenefitRestrictions` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExplanationOfBenefitRestrictions |
| related-information | POST | `/v1/related-information/eobs/search` | `SearchExplanationOfBenefits` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.SearchExplanationOfBenefits |
| related-information | GET | `/v1/related-information/eobs/{eobId}` | `GetExplanationOfBenefits` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExplanationOfBenefits |
| related-information | POST | `/v1/related-information/exception-errors/restrictions/get` | `GetExceptionErrorRestrictions` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExceptionErrorRestrictions |
| related-information | POST | `/v1/related-information/exception-errors/search` | `SearchExceptionErrors` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.SearchExceptionErrors |
| related-information | GET | `/v1/related-information/exception-errors/{exceptionErrorId}` | `GetExceptionError` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExceptionError |
| related-information | POST | `/v1/related-information/exception-information/restrictions/get` | `GetExceptionInformationRestrictions` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExceptionInformationRestrictions |
| related-information | POST | `/v1/related-information/exception-information/search` | `SearchExceptionInformation` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.SearchExceptionInformation |
| related-information | GET | `/v1/related-information/exception-information/{exceptionInformationId}` | `GetExceptionInformation` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExceptionInformation |
| related-information | POST | `/v1/related-information/explanation-code/aggregate-delta` | `GetExplanationCodeAggregateDelta` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExplanationCodeAggregateDelta |
| related-information | POST | `/v1/related-information/explanation-code/events` | `GetExplanationCodeEvents` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.GetExplanationCodeEvents |
| related-information | POST | `/v1/related-information/mue/search` | `SearchMedicallyUnlikelyEdit` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.SearchMedicallyUnlikelyEdit |
| related-information | POST | `/v1/related-information/ncci/search` | `SearchNationalCorrectCodingInitiative` | `cmpl.planmanagement.read` | Legacy: IRelatedInformationQueryService.SearchNationalCorrectCodingInitiative |

Rate maintenance and platform endpoints (Part II §6.3.1):

| Area | Method | Path | Scope |
|---|---|---|---|
| rate-setting | POST | `/v1/rate-setting/provider-ucc`, `/provider-drg`, `/provider-specific`, `/member-specific` | `cmpl.planmanagement.write` |
| rate-setting | POST | `/v1/rate-setting/member-specific/search` | `cmpl.planmanagement.read` |
| rate-setting | GET | `/v1/rate-setting/{rateFamily}/{id}`, `/v1/rate-setting/{rateFamily}/{id}/audit` | `cmpl.planmanagement.read` |
| rate-setting | PATCH | `/v1/rate-setting/{rateFamily}/{id}` | `cmpl.planmanagement.write` |
| rate-setting | POST | `/v1/rate-setting/{rateFamily}/{id}:copy`, `:insert`, `:invalidate` | `cmpl.planmanagement.write` |
| rate-setting | GET | `/v1/rate-setting/publication-status` | `cmpl.planmanagement.read` |
| rate-setting | POST | `/v1/rate-setting/publication-status/{eventId}:retry` | `cmpl.planmanagement.write` |
| all import areas | GET | `/v1/{area}/imports/{importId}` | `cmpl.planmanagement.read` |

## Appendix H — Screen Specifications and Navigation

This appendix defines the user-facing screens for the Plan Management module (MFE) and the minimum contract between UI ↔ BFF ↔ Domain APIs.

Conventions:
- Screen routes are illustrative; final route map is owned by the Next.js shell + module federation integration.
- Every screen reads data via BFF endpoints that proxy the Appendix B domain APIs.
- Every edit screen must include and submit versionNumber on every write action (Appendix A.1.5).
- Dropdowns are served by DataLists owned by Configuration Management (C.2.5) unless otherwise stated.

### H.1 Screen Inventory

| Screen | Capability area | Primary domain service | Legacy source |
|---|---|---|---|
| Code Sets: search, view, add, edit (HCPCS, Dental, Revenue, DRG, ICD-9/10) | Code information | Code Information | UG p.18–53 |
| NDC: search, view, add, edit; CMS NDC information, status dates, indicators, COD status, rebate indicators, packages, NDC rates | Pharmacy | Code Information | UG p.56–67 |
| Labeler Codes with rebate programs | Pharmacy | Code Information | UG p.68–71 |
| GSN | Pharmacy | Code Information | UG p.72–74 |
| Grouping: search, view, add, edit | Groupings | Grouping | UG p.14–17 |
| NCCI and MUE (Practitioner, OPHOS, DME) | Related data | Related Information | UG p.76–85 |
| EOB, EEC (with resolution criteria), EIC | Related data | Related Information | UG p.86–99 |
| HCPCS–NDC Crosswalk | Related data | Code Information | UG p.100–102 |
| Provider Specific Rates: search (also from Provider Management), one panel per rate type, copy, add, edit, insert, audit | Rate setting | Rate Setting | UG p.104–130 |
| Member Specific Rates | Rate setting | Rate Setting | UG p.131–133 |
| Fee Schedules: search, view, add, edit, edit fields, copy header, copy details, insert rows, Release Status | Rate setting | Rate Setting | UG p.134–143 |
| File Upload: search uploads, upload, statistics, error files | Batch ingestion | All | UG p.144–152 |
| Manage Cycles | Cycles | Related Information | UG p.153–155 |
| Publication & Integration Status | Platform | Rate Setting | New (Appendix M.2) |

### H.2 Common Screen Patterns

#### H.2.1 Search screens

- Inputs: filter panel (effective date or date type, code/value, Valid, VOS tag, Change Request ID), paging and sort.
- API contract: POST /v1/<area>/search with `{ items, page }` responses.
- Export to Excel, PDF or upload template (C.2.4).

#### H.2.2 Detail screens (read)

- API contract: GET /v1/<area>/{id}.
- Shows current, future and end-dated segments; Include Invalids shows invalid records (RN p.5).

#### H.2.3 Maintenance screens

- Add, edit, copy and insert follow §2.3; Change Request ID is required on add, copy and insert (BR-012).
- Date-based edit limits (BR-013, BR-020) disable fields that can no longer change.
- `versionNumber` is sent on every write (409 on mismatch).
- Code set and NDC screens hide add and edit when the maintenance level does not allow it (BR-019); level-80 records are view-only and have no audit panel.

### H.3 Rate Screen Rules

#### H.3.A Provider search and context

- Search by Provider ID, NPI or name against the local provider reference copy (§2.1.1); a provider service location must be selected for every provider-specific rate (BR-003).

#### H.3.B Rate type panels

- One panel per rate type with the key and value fields in §2.2.1.
- Dispensing Fee: blank Drug Type or Dispensing Type shows ALL (BR-018).
- DRG: optional values and custom DRG values on the same panel.
- Processing dates shown when the matching *RateProcessingDatesRequired setting is true (BR-009).

#### H.3.C Fee schedule header and lines

- Header: Schedule ID, name, rules, Release Status (BR-015), Change Request ID; fields grid with Required and Identifier flags (BR-016); Edit Fields only while Pending.
- Lines: the chosen fields plus Rate Amount or Rate Percent, adjustment factors, units, effective and processing dates.

#### H.3.D Audit

- Audit panels show Date/Time, Event, User Id, Source of change, and before and after values for rates (BR-023).

## Appendix I — Batch and File Formats

File formats for batch imports. Files are staged in S3 and processed by Glue jobs orchestrated by Airflow. Each job keeps the validations of the legacy loader named under "Source loader".

### I.1 Import Request

All batch imports use the shared request contract defined in:
- `ImportRequest` in Appendix B.1

Conceptually:
- Caller uploads a file to S3 (pre-signed URL from the BFF).
- Caller submits an `ImportRequest` referencing `{ bucket, key }`, plus `mode` (`upsert|replace`) and optional `importType`.
- The platform orchestration (MWAA/Airflow) starts the appropriate Glue Spark job for that `importType`.

### I.2 Excel Template Formats

#### I.2.1 EOB Codes (Excel template)

Source loader:
- `components/batch/EOBLoader/.../Common/EOBLoaderCommon.cs` (row validation + column-to-field mapping)
- `components/batch/EOBLoader/.../EOBLoader.cs` (workbook ingestion)

File type:
- Excel workbook (`.xlsx`) with a header row at row 0; data begins at row 1.

Columns (0-based index as implemented in the loader):

| Index | Field | Notes |
|---:|---|---|
| 0 | `Code` | EOB code (max length 6; rejects `;*^:~<>%`) |
| 1 | *(unused/optional)* | Present in template but not validated in `EOBLoaderCommon.ValidateRow` |
| 2 | `ShortDescription` | Required |
| 3 | `Module` | Required; alphanumeric + spaces |
| 4 | `Category` | Required; alpha + spaces |
| 5 | `ClaimStatus` | Optional; if present must be 2 digits |
| 6 | `EntityIdentifier` | Optional; if present must be 2 alphanumeric |
| 7 | `CARC` | Optional; if present must be 3 alphanumeric |
| 8 | `RARC` | Optional; if present must be 4 alphanumeric |
| 9 | `EffectiveDate` | Required; `MM/dd/yyyy`; must be within min/max range per `DateMethods` |
| 10 | `EndDate` | Optional; `MM/dd/yyyy`; must be within min/max range per `DateMethods` |

Target-state mapping:
- Use a dedicated `importType`, e.g. `related-information.eob-codes`.
- The Glue job must enforce the same validations and produce row-level error output (S3 error artifact + `pm_import_job.summary_json`).

#### I.2.2 Grouping upload (Excel template)

Source loader:
- `components/batch/GroupLoader/.../GroupLoader.cs` (`ConvertRowsToObject` assigns fields by `cell.Index`)
- `components/batch/GroupLoader/.../Common/GroupLoaderCommon.cs` (required-field and format validation)

File type:
- Excel workbook (`.xlsx`) with a header row at row 0; data begins at row 1.

Columns (0-based index):

| Index | Field | Notes |
|---:|---|---|
| 0 | `Module` | Required |
| 1 | `DataList` | Required |
| 2 | `GroupName` | Required; max length 50 |
| 3 | `GroupType` | Required; validated by `FormatHelper.GroupTypeCheck` |
| 4 | `GroupFrom` | Required |
| 5 | `GroupTo` | Optional |
| 6 | `EffectiveDate` | Required; date parsing uses `Constants.ProperDateFormat` |
| 7 | `EndDate` | Required; date parsing uses `Constants.ProperDateFormat` |
| 8 | `AddOn` | Optional; behavior gated by app setting `GroupingAddOnIncluded` |
| 9 | `Valid` | Required; validated by `FormatHelper.ConfirmIsValidCheck` |

Target-state mapping:
- Use a dedicated `importType`, e.g. `grouping.group-items`.
- The Glue job must preserve the legacy semantics: validation errors per row, duplicate detection, and effective/end-date overlap checks.

#### I.2.3 Data List Items (Excel template)

> DataList item upload is owned by Configuration Management in the target (Q-25 answered); the format is kept here for reference only.

Source loader:
- `components/batch/DataListItemLoader/.../Common/DataListItemLoaderCommon.cs` (column-to-field mapping + validation)

File type:
- Excel workbook (`.xlsx`) with a header row at row 0; data begins at row 1.

Columns (0-based index) as validated:

| Index | Field | Notes |
|---:|---|---|
| 0 | `DataList` | Required |
| 1 | `Code` | Required |
| 2 | `Description` (language 1) | Required if Long Description (col 3) present |
| 3 | `LongDescription` (language 1) | Optional |
| 4 | `SortOrder` | Optional; numeric, 0–99 enforced in association case |
| 5 | `EffectiveDate` | Required; `MM/dd/yyyy` |
| 6 | `EndDate` | Required by validation; empty may be treated as max-date by `GetDate` |
| 7 | `Valid` | Required (exact rules in `ValidateMandatoryFields` continuation) |
| 8 | `Editable` | Required; must be `0` or `1` |
| 9 | `Description` (language 2) | Optional |
| 10 | `LongDescription` (language 2) | Optional |

Target-state mapping:
- Use `importType`, e.g. `datalists.items`.

### I.3 Header-Driven and Feed Formats

#### I.3.1 Fee schedule batch upload (Excel template; header-driven)

Source loader (header row discovers columns):
- `components/batch/FeeScheduleLoader/.../FeeScheduleLoader.cs` (`SetFeeScheduleFieldInfoColumn`)
- Field names enumerated in `components/batch/FeeScheduleLoader/.../Common/FeeScheduleLoaderConstants.cs` (`FeeScheduleConstants.FeeScheduleFields`)

Format notes:
- Excel workbook (`.xlsx`) with a header row listing field names.
- The loader discovers which fields exist by matching header text against `FeeScheduleConstants.FeeScheduleFieldInfo` keys.

Minimum header set:
- `Code`, `CodeType`, `RateAmount` and/or `RatePercent`, `EffectiveDate`, `EndDate`, `IsValid`

Target-state mapping:
- Use `importType`, e.g. `fee-schedule.lines` with `mode=upsert` by default.

Fee schedule templates vary by tenant and fee-schedule configuration. The header templates used in each state are captured during migration as versioned artifacts (S3 + Object Lock), and the Glue job is pinned to those template versions.

#### I.3.2 Code set imports (ICD/HCPCS/DRG/Revenue/Dental, etc.)

Legacy loaders exist per code set under `components/batch/*Loader/`, but formats vary by source (CMS extracts, vendor feeds, etc.).

Rules:
- **One `importType` per source feed** (e.g., `codes.icd10-diagnosis.cms`, `codes.hcpcs.cms`), not per internal table.
- Keep the raw extract in S3 unchanged; parse/transform into normalized Aurora tables.
- Apply the validation rules of the legacy loader (effective date ranges, duplication rules, restricted-code purges).

### I.4 Outputs

Every import produces:
- Import job status (`pm_import_job`) with row counts and error counts.
- Row-level error artifact (CSV/JSON) in S3 (referenced from `pm_import_job.summary_json`).
- Domain events: one per upserted record plus one `plan.import.completed.v1` / `plan.import.failed.v1` summary event per import (Appendix E).

## Appendix J — Configuration Catalog

Status: Partial — settings taken from the legacy CRG; target key names and storage (Tenant Registry feature flags or service configuration) to confirm.

| Setting (legacy name) | Scope | Values / default | Used by | Source |
|---|---|---|---|---|
| `*RateProcessingDatesRequired` (one per rate type) | Tenant | true / false (default false) | BR-009 | CRG p.72–78 |
| `DrugLabelerSource` | Tenant | Plan Management / other | BR-021 | UG p.68–71 |
| MinDate, MaxDate | Tenant | MaxDate 12/31/9999 | BR-008 | CRG p.76 |
| DataList Maintenance Level (per code set) | Tenant (Configuration Management) | 01, 30, 40, 50, 60, 80, 90, 99 | BR-019 | CRG p.14 |
| `GroupingAddOnIncluded` | Tenant | true / false | Grouping upload (Appendix I) | GroupLoader |
| Provider created event setting | Tenant | — | §2.1.1 | CRG p.70 |
| `InRule.ApplicationId` | Tenant | — | Not used (§2.5) | CRG p.88 |
| Event transport | Environment | SNS/SQS or MSK | Event Adapter | ADR-002 |
| BFF cache TTL | Environment | 300 s | BFF | §5.6 |
| Idempotency key TTL | Environment | 24 h | All services | §6.4 |
| Feature flags for new capabilities | Tenant | Per capability | UI and services | ADR-011, `hpp_feature_flags_client` |

## Appendix K — Legacy Inventory and Traceability

Status: Partial — K.1 (legacy tables) is complete. Legacy endpoints are mapped in §6.3, loaders and processes in §11, File to Event processes in §8.1 and screens in Appendix H.1.

### K.1 Legacy Table Disposition

All 80 tables of legacy `UA3_PLAN_MGMT` (source: Table Classification inventory, Current-State sheet). Disposition uses the terms of §0.4: **Change** (rebuilt as a `pm_*` table), **Change (merged)** (several legacy tables into one table or column), **Change (moved to db_shared)** (national reference data), **Retire** (no target table).

| **#** | **Legacy table** | **Legacy cols** | **Disposition** | **Target** | **Store** | **Notes** |
| ---: | --- | ---: | --- | --- | --- | --- |
| 1 | `CYCLE_SCHED` | 15 | Change | `pm_cycle_schedule` | `pp_{tenant}.plan` | absorbs `UA3_TENANT.TM_CYCLE_DT` |
| 2 | `EXCP_ERROR` | 6 | Change | `pm_exception_error_code` | `pp_{tenant}.plan` |  |
| 3 | `EXCP_ERROR_RESTRICT` | 19 | Change | `pm_exception_error_code_restriction` | `pp_{tenant}.plan` | restriction as JSON |
| 4 | `EXCP_INFO` | 6 | Change | `pm_exception_information` | `pp_{tenant}.plan` |  |
| 5 | `EXCP_INFO_RESTRICT` | 14 | Change | `pm_exception_information_restriction` | `pp_{tenant}.plan` | restriction as JSON |
| 6 | `EXPLN_BENEFIT` | 6 | Change | `pm_explanation_of_benefit` | `pp_{tenant}.plan` |  |
| 7 | `EXPLN_BENEFIT_RESTRICT` | 15 | Change | `pm_explanation_of_benefit_restriction` | `pp_{tenant}.plan` | restriction as JSON |
| 8 | `FEE_SCHED` | 12 | Change | `pm_fee_schedule` | `pp_{tenant}.plan` |  |
| 9 | `FEE_SCHED_FIELD` | 10 | Change | `pm_fee_schedule_field` | `pp_{tenant}.plan` |  |
| 10 | `FEE_SCHED_FIELD_DEF` | 15 | Change | `pm_fee_schedule_field_definition` | `pp_{tenant}.plan` | new in v6 |
| 11 | `FEE_SCHED_LINE` | 9 | Change | `pm_fee_schedule_line` | `pp_{tenant}.plan` | criteria as JSON |
| 12 | `FORMATTED_CONTENT` | 12 | Change | `pm_formatted_content` | `pp_{tenant}.plan` |  |
| 13 | `GROUPING` | 8 | Change | `pm_grouping` | `pp_{tenant}.plan` |  |
| 14 | `GROUPING_ITEM` | 12 | Change | `pm_grouping_item` | `pp_{tenant}.plan` |  |
| 15 | `LABELER_PROGRAM_TYPE` | 9 | Change | `pm_labeler_rebate_program` | `pp_{tenant}.plan` | labeler rebate programs (Q-28 answered) |
| 16 | `LOADER_HISTORY` | 18 | Change | `pm_file_loader_history` | `pp_{tenant}.plan` | file bodies move to S3 |
| 17 | `MEMBER` | 8 | Change | `pm_member` | `pp_{tenant}.plan` | member reference copy (Q-11) |
| 18 | `MEMBER_RATE` | 16 | Change | `pm_member_rate` | `pp_{tenant}.plan` | member-specific rates (UG p.131–133) |
| 19 | `NATIONAL_DRUG_CODE_RATE` | 11 | Change | `pm_ndc_rate` | `pp_{tenant}.plan` |  |
| 20 | `NATIONAL_DRUG_CODE_REBATE` | 10 | Change | `pm_ndc_rebate` | `pp_{tenant}.plan` | new in v6 |
| 21 | `PROVIDER` | 7 | Change | `pm_provider` | `pp_{tenant}.plan` | local copy: migration load + CMS-PM events |
| 22 | `PROVIDER_DRG_CUSTOM` | 8 | Change | `pm_provider_drg_custom` | `pp_{tenant}.plan` |  |
| 23 | `PROVIDER_DRG_RATE` | 26 | Change | `pm_provider_drg_rate` | `pp_{tenant}.plan` |  |
| 24 | `PROVIDER_SERVICE_LOCATION` | 9 | Change | `pm_provider_service_location` | `pp_{tenant}.plan` | local copy from CMS-PM events |
| 25 | `PROVIDER_SPECIFIC_RATE` | 24 | Change | `pm_provider_specific_rate` | `pp_{tenant}.plan` | Nursing Facility, Encounter, Dispensing Fee, Inpatient, Outpatient; location required |
| 26 | `PROVIDER_UCC_RATE` | 19 | Change | `pm_provider_ucc_rate` | `pp_{tenant}.plan` | absorbs `UA3_PROVIDER.PROVIDER_UCC_RATES` |
| 27 | `VOS_TAG` | 10 | Change | `pm_vos_tag` | `pp_{tenant}.plan` |  |
| 28 | `BUNDLE_MUE` | 14 | Change (merged) | `pm_edit_rule` (`edit_type = MUE`) | `pp_{tenant}.plan` |  |
| 29 | `BUNDLE_NCCI` | 15 | Change (merged) | `pm_edit_rule` (`edit_type = NCCI`) | `pp_{tenant}.plan` |  |
| 30 | `CMS_STATUS` | 13 | Change (merged) | `pm_ndc_status` (`status_source = CMS`) | `db_shared.plan` | AS-12, Q-23; state edits in `*_state` (§2.1.3) |
| 31 | `DENTAL_RESTRICT` | 22 | Change (merged) | `pm_code_restriction` (`restriction_type = DENTAL`) | `pp_{tenant}.plan` | one row per parent restriction |
| 32 | `DENTAL_RESTRICT_QUAD` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = DENTAL`) | `pp_{tenant}.plan` | array `quadrants` in `restriction_json` |
| 33 | `DENTAL_RESTRICT_SVCPLC` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = DENTAL`) | `pp_{tenant}.plan` | array `placeOfServiceCodes` in `restriction_json` |
| 34 | `DENTAL_RESTRICT_TOOTH_NUM` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = DENTAL`) | `pp_{tenant}.plan` | array `toothNumbers` in `restriction_json` |
| 35 | `DENTAL_RESTRICT_TOOTH_SURF` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = DENTAL`) | `pp_{tenant}.plan` | array `toothSurfaces` in `restriction_json` |
| 36 | `DRG_RESTRICT` | 15 | Change (merged) | `pm_code_restriction` (`restriction_type = DRG`) | `pp_{tenant}.plan` | one row per parent restriction |
| 37 | `FEE_SCHED_OPT_FIELD` | 6 | Change (merged) | `pm_fee_schedule_line.optional_fields_json` | `pp_{tenant}.plan` |  |
| 38 | `HCPCS_RESTRICT` | 23 | Change (merged) | `pm_code_restriction` (`restriction_type = HCPCS`) | `pp_{tenant}.plan` | one row per parent restriction |
| 39 | `HCPCS_RESTRICT_ICD10_DIAG` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = HCPCS`) | `pp_{tenant}.plan` | array `icd10DiagnosisCodes` in `restriction_json` |
| 40 | `HCPCS_RESTRICT_ICD9_DIAG` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = HCPCS`) | `pp_{tenant}.plan` | array `icd9DiagnosisCodes` in `restriction_json` |
| 41 | `HCPCS_RESTRICT_MOD` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = HCPCS`) | `pp_{tenant}.plan` | array `modifiers` in `restriction_json` |
| 42 | `HCPCS_RESTRICT_SVCPLC` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = HCPCS`) | `pp_{tenant}.plan` | array `placeOfServiceCodes` in `restriction_json` |
| 43 | `ICD10_DIAGNOSIS_RESTRICT` | 18 | Change (merged) | `pm_code_restriction` (`restriction_type = ICD10_DIAG`) | `pp_{tenant}.plan` | one row per parent restriction |
| 44 | `ICD10_PROCEDURE_RESTRICT` | 16 | Change (merged) | `pm_code_restriction` (`restriction_type = ICD10_PROC`) | `pp_{tenant}.plan` | one row per parent restriction |
| 45 | `ICD9_DIAGNOSIS_RESTRICT` | 17 | Change (merged) | `pm_code_restriction` (`restriction_type = ICD9_DIAG`) | `pp_{tenant}.plan` | one row per parent restriction |
| 46 | `ICD9_PROCEDURE_RESTRICT` | 15 | Change (merged) | `pm_code_restriction` (`restriction_type = ICD9_PROC`) | `pp_{tenant}.plan` | one row per parent restriction |
| 47 | `NATIONAL_DRUG_CODE_COD` | 11 | Change (merged) | `pm_ndc_status` (`status_source = COD`) | `db_shared.plan` | AS-12, Q-23; state edits in `*_state` (§2.1.3) |
| 48 | `REV_RESTRICT` | 26 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | one row per parent restriction |
| 49 | `REV_RESTRICT_BILL_TYPE` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | array `billTypeCodes` in `restriction_json` |
| 50 | `REV_RESTRICT_HCPCS` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | array `hcpcsCodes` in `restriction_json` |
| 51 | `REV_RESTRICT_ICD10_DIAG` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | array `icd10DiagnosisCodes` in `restriction_json` |
| 52 | `REV_RESTRICT_ICD10_PROC` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | array `icd10ProcedureCodes` in `restriction_json` |
| 53 | `REV_RESTRICT_ICD9_DIAG` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | array `icd9DiagnosisCodes` in `restriction_json` |
| 54 | `REV_RESTRICT_ICD9_PROC` | 5 | Change (merged) | `pm_code_restriction` (`restriction_type = REVENUE`) | `pp_{tenant}.plan` | array `icd9ProcedureCodes` in `restriction_json` |
| 55 | `DENTAL_CODE` | 7 | Change (moved to db_shared) | `pm_code` (`code_system = DENTAL`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 56 | `DRG_CODE` | 7 | Change (moved to db_shared) | `pm_code` (`code_system = DRG`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 57 | `DRUG_CLASSIFICATION` | 16 | Change (moved to db_shared) | `pm_drug_classification` | `db_shared.plan` | AS-12, Q-23; state edits in `*_state` (§2.1.3) |
| 58 | `HCPCS_CODE` | 7 | Change (moved to db_shared) | `pm_code` (`code_system = HCPCS`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 59 | `HCPCS_NDC_ASSCN` | 16 | Change (moved to db_shared) | `pm_hcpcs_ndc_association` | `db_shared.plan` | AS-12, Q-23; state edits in `*_state` (§2.1.3) |
| 60 | `ICD10_DIAGNOSIS_CODE` | 6 | Change (moved to db_shared) | `pm_code` (`code_system = ICD10_DIAG`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 61 | `ICD10_PROCEDURE_CODE` | 6 | Change (moved to db_shared) | `pm_code` (`code_system = ICD10_PROC`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 62 | `ICD9_DIAGNOSIS_CODE` | 5 | Change (moved to db_shared) | `pm_code` (`code_system = ICD9_DIAG`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 63 | `ICD9_PROCEDURE_CODE` | 5 | Change (moved to db_shared) | `pm_code` (`code_system = ICD9_PROC`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 64 | `LABELER` | 7 | Change (moved to db_shared) | `pm_labeler` | `db_shared.plan` | AS-12, Q-23; state edits in `*_state` (§2.1.3) |
| 65 | `MANUFACTURER` | 8 | Change (moved to db_shared) | `pm_manufacturer` | `db_shared.plan` | AS-12, Q-23; state edits in `*_state` (§2.1.3) |
| 66 | `NATIONAL_DRUG_CODE` | 45 | Change (moved to db_shared) | `pm_ndc` | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 67 | `REV_CODE` | 7 | Change (moved to db_shared) | `pm_code` (`code_system = REVENUE`) | `db_shared.plan` | ADR-020; state edits in `*_state` (§2.1.3) |
| 68 | `BATCH_ERROR_MSG` | 4 | Retire | `pm_import_job.summary_json` + S3 error files | — |  |
| 69 | `BATCH_ERROR_RECORD` | 6 | Retire | S3 row-level error files | — |  |
| 70 | `COMMITS` | 13 | Retire | archived | `pp_{tenant}.plan_audit_archive` | one-time load |
| 71 | `ETL_RESULT` | 5 | Retire | `pm_import_job` + S3 error files | — |  |
| 72 | `EVENT_AUDIT` | 7 | Retire | archived; new changes in `pm_version_history` | `pp_{tenant}.plan_audit_archive` | AS-13, Q-29 |
| 73 | `EVENT_DISTRIBUTION` | 6 | Retire | `pm_outbox_event` + Outbox Relay | — |  |
| 74 | `HPP_TENANT` | 2 | Retire | Tenant Registry `tenants` | `db_shared` (CM-CORE) |  |
| 75 | `PROVIDER_ETL` | 11 | Retire | `pm_import_job` + S3 error files | — |  |
| 76 | `PURGE_RESULT` | 3 | Retire | `pm_import_job` (purge Glue job) | — |  |
| 77 | `QUERY_LOG` | 11 | Retire | none (no CQRS) | — |  |
| 78 | `QUERY_LOG_INDEX` | 6 | Retire | none (no CQRS) | — |  |
| 79 | `SNAPSHOTS` | 7 | Retire | archived | `pp_{tenant}.plan_audit_archive` | one-time load |
| 80 | `STAGING_NURSING_FACILITY` | 10 | Retire | Glue import staging in S3 | — | no documented use in legacy guides |

Totals: Change 27, Change (merged) 27, Change (moved to db_shared) 13, Retire 13 = 80.

Related legacy tables outside `UA3_PLAN_MGMT`: DataList tables in `UA3_CONFIG` and `UA3_TENANT` stay with Configuration Management (Q-25); `UA3_PROVIDER.PROVIDER_UCC_RATES` and `UA3_TENANT.TM_CYCLE_DT` are reconciled into Plan Management (§9.3); MCO tables in `UA3_PROVIDER` and `UA3_PROVIDER_ENROLL` stay with CMS-PM.

## Appendix L — Migration, Reconciliation and Cutover Detail

Status: Partial — rollback (Q-19), volumes (Q-24) and slices (Q-17) pending.

### L.1 Migration Sequence (per tenant)

| Step | Action | Evidence |
|---|---|---|
| 1 | Run Alembic to head for the tenant | `plan.alembic_version` |
| 2 | Load the `db_shared` national base (once per environment) | Loader job results |
| 3 | Load provider and member reference copies (Initial Provider Loader fields, §2.1.1) | Row counts |
| 4 | Load reference data, state edits (`*_state`), restrictions, NDC data | Row counts per table |
| 5 | Load rates, fee schedules, groupings, related data, cycles | Row counts, rate value checksums |
| 6 | Load the legacy audit archive into `plan_audit_archive` | Row counts |
| 7 | Reconcile (L.2) | Reconciliation report |
| 8 | Parallel run and parity (§15.3) | Parity report |
| 9 | Final delta load, sign-off, switch consumers, legacy read-only | Cutover checklist |

### L.2 Reconciliation Checks

| Check | Per | Pass condition |
|---|---|---|
| Row counts | Tenant × legacy table → target table (Appendix D.4, K.1) | Equal, or difference explained |
| Business keys | Tenant × table | No missing or extra keys |
| Effective-date ranges | Rate and reference tables | Same segments; no new overlaps (BR-010) |
| Rate values | Rate tables | Exact match on amounts and percents |
| Audit archive | `COMMITS`, `SNAPSHOTS`, `EVENT_AUDIT` | Counts match |

### L.3 Rollback

Open (Q-19). The signed rollback runbook is an M5 deliverable (ARB §6).

## Appendix M — Known-Difference Register

Status: Partial — differences recorded in v7 under DD-06; each needs business sign-off (ADR-029 known-difference register).

### M.1 Not adopted — no legacy equivalent (removed in v7)

| ID | v6 feature | Legacy behaviour | Evidence | Impact if raised again |
|---|---|---|---|---|
| M-01 | In-system approval workflow (Draft → Submitted → UnderReview → Approved → Scheduled → Active; Returned, Rejected, Cancelled, Expired, Terminated) and its action endpoints | Approval is a business process outside the system; records are saved directly | FN p.17–20 | New change request |
| M-02 | Approver ≠ creator and senior approval | None | CRG p.82–83 (no approver role) | New change request |
| M-03 | Pricing precedence and `applicable-rate:resolve` | Consumers select rates by date of service | FN p.8, p.10 | Claims-side requirement |
| M-04 | Contract participation and contract rates | None in Plan Management | UG ch. V | New change request |
| M-05 | Standalone fee schedule assignments with auto end-dating | Provider fields (location, NPI, Tax ID, type, specialty) are optional fields on fee schedule lines | UG p.139 | New change request |
| M-06 | Retroactive-correction workflow and correction window | Past segments are changed through the normal edit, insert and copy rules (BR-011, BR-013) | UG p.112, 140 | New change request |
| M-07 | NeedsReview on provider or location deactivation | Rates are not changed when a provider changes | UG ch. V | New change request (Q-30) |
| M-08 | Daily status-transition job | No date-driven status change | FN p.10; SPG p.4 | Not needed without M-01 |
| M-09 | MCO and MCO plan records (`pm_mco`, `pm_mco_plan`) | None in Plan Management | UG p.1 | Owned by CMS-PM / Managed Care |
| M-10 | InRule evaluation at submit and validate-only | No rule evaluation documented in Plan Management | CRG p.88 | Q-16 |
| M-11 | Plan Management-owned DataLists (`pm_datalist*`) | DataLists owned by Configuration Management | CRG p.1; UG p.7 | — |

v6 business rules BR-013 to BR-021, BR-023 (published only when approved), BR-026, BR-027, BR-029 and BR-030 were removed with these features; the v7 catalogue is in §2.1.

### M.2 Changed — legacy behaviour kept, implementation differs

| ID | Area | Legacy | Target | Reason |
|---|---|---|---|---|
| M-21 | National reference data | Full copy per state, edited online | National base in `db_shared`; state edits in `*_state` tables (§2.1.3) | ADR-012, ADR-020 |
| M-22 | Change distribution | Event store + BizTalk ESB | Transactional outbox + Event Adapter | ADR-002 |
| M-23 | File to Event | INX InboundDataProcessor from dropped JSON files | CMS-INX events (§8.1) | ADR-002 |
| M-24 | Concurrency | Event-store commit tracking | `versionNumber` with 409 on mismatch | Prevents lost updates in browser clients |
| M-25 | Loaders | Console loaders and SSIS packages | Glue jobs on MWAA | ADR-010 |
| M-26 | Publication visibility | None | Publication & Integration Status screen and retry | BR-025 |
| M-27 | DataList maintenance processes | Plan Management scheduled processes (cache refresh, extract, reset, clean-up) | Owned by Configuration Management | Q-25 |

## Appendix N — Glossary and References

Status: Complete.

### N.1 Glossary

| Term | Meaning |
|---|---|
| ADA | American Dental Association (dental codes) |
| BFF | Backend for Frontend |
| Change Request ID | Client-defined identifier of the policy change behind an add or copy (CRG p.8) |
| CMS | Centers for Medicare & Medicaid Services |
| CMS-INX | Provider Plus integration boundary (ARB: External Integration Adapter) |
| CMS-PM | Provider Management module |
| COD | Change of Drug status (NDC) |
| CPT | Current Procedural Terminology |
| DRG | Diagnosis Related Group |
| EEC | Exception Error Code |
| EIC | Exception Information Code |
| EOB | Explanation of Benefits |
| FDB | First Databank (drug data vendor) |
| GSN | Generic Sequence Number |
| HCPCS | Healthcare Common Procedure Coding System |
| HICL | Hierarchical Ingredient Code List |
| ICD-9 / ICD-10 | International Classification of Diseases, revisions 9 and 10 |
| Insert New | Adding a rate row that end-dates the existing open-ended row (BR-011) |
| Maintenance level | Per code set setting that limits online maintenance (BR-019) |
| MUE | Medically Unlikely Edit |
| NCCI | National Correct Coding Initiative |
| NDC | National Drug Code |
| OPHOS | Outpatient Hospital Services (NCCI/MUE category) |
| Release Status | Fee schedule state: Pending, Test, Release, Delete (BR-015) |
| SDD | Spec-driven development (ADR-033) |
| UCC | Usual and Customary Charges |
| VOS | VOS tags on rates and restrictions (legacy `VOS_TAG`) |
| `*_state` table | Tenant table holding a state's additions and edits of national data (DD-07) |

### N.2 References

See §0.3 Governing Inputs. Authoring rules for this template are in `target-state-review-checklist-v2.md`.
