# Target State Review Checklist

**Program:** Provider Plus Modernization
**Checklist version:** 2.1 (2026-11-01). Change from 2.0: section statuses now include **Not started** (template 2.1); §0.4 says how each status maps to a result, and S0-08 checks that statuses match the content.
**Pairs with:** `target-state-template-v2.md`. Section numbers in this checklist match the template.
**Supersedes:** `target-state-review-checklist.md` v1.1

**Purpose:** Review any Provider Plus module or sub-module target state for completeness, correctness and alignment before it is used for spec-driven development (SDD). Run it as instructions for an agent, or follow it by hand.

---

## 0. How to Use

### 0.1 Inputs

| Input | Required | Used for |
|---|---|---|
| The target state under review, plus its contract, AsyncAPI and DDL files | Yes | Everything |
| ADR log (current) | Yes | §16, Appendix P |
| ARB (current version) | Yes | §3, §7, §16, Appendix P |
| Legacy code or legacy knowledge graph (KG) | Recommended | §2, §6.3, §9, §15, Appendix K |
| Parent target state (for sub-modules) | If applicable | Inherited sections |
| Neighbouring modules' target states and event catalogs | Recommended | §1.3, §7 |
| Reference screens or UX designs | Optional | §4, Appendix H |

### 0.2 Two ways to run it

- **Agent mode:** give the agent this file and the inputs. The agent follows the procedure in Section 1, marks every item, runs the automated checks (Section Y), and writes the report (Section 3) as `<module>-target-state-review.md`.
- **Manual mode:** follow the same procedure. Use the editor search patterns given in Section Y if scripts are not available.

### 0.3 Item types

| Type | Meaning |
|---|---|
| **R (Required content)** | Checks that something is **present** with its minimum content. R items form the gate |
| **Q (Quality)** | Checks that what is present is correct, specific and consistent |

### 0.4 Results

| Result | Meaning |
|---|---|
| **Pass** | Present, specific enough to generate from, consistent with the ADRs, the ARB and the rest of the document |
| **Partial** | Present but incomplete, vague, or depends on unstated assumptions |
| **Fail** | Missing, or contradicts an ADR, the ARB or another section |
| **N/A** | Does not apply to this module; the document says why |
| **Inherited** | Covered by the parent document, which is cited and has been checked |

Every Partial and Fail needs **evidence** (section and quote or line) and a **recommended fix**.

**Section status in the document vs result in the review.** The document's own status line is a claim; the review result comes from the content.

| Document says | Review treats it as |
|---|---|
| Complete | Check normally. If the section fails its items, record a finding under S0-08 as well |
| Partial | Check normally. If the section is in fact empty (only "TBD" or a pointer to an empty appendix), its Type R items **Fail** and S0-08 records the mislabel |
| Not started | Its Type R items **Fail** (missing); its Type Q items are not assessed |
| N/A | Accept only if the reason says why the section does not apply to this module; otherwise its Type R items **Fail** and S0-08 records the misuse |
| Inherited | Check the cited parent section instead |

### 0.5 Severity (if the item fails)

| Severity | Meaning |
|---|---|
| **Blocker** | Generated code would break a ratified decision, or the agent would have to invent core behaviour |
| **Major** | The agent would guess, and the guess will probably differ from what was intended |
| **Minor** | Consistency or hygiene problem |

### 0.6 Applicability

Some items apply only when the module has the feature (workflow, batch, legacy predecessor, public users, frontend). "N/A" is acceptable for those **only if the document states the reason**. An item with no stated reason that is missing is a Fail.

### 0.7 Rules for the reviewer

1. Check against the current ADR log and ARB, not memory. Appendix P records the baseline values and the date they were last confirmed.
2. Read the whole document, including the appendices and linked contract files.
3. Quote evidence. Count, don't estimate, for contract and DDL checks.
4. Don't edit the document during the review. Fixes go into a separate correction plan.
5. Record good practice as well as gaps, so other teams can reuse it.
6. For documents not in the template v2 format, use the crosswalk in Appendix R to find the content, and report missing template sections as findings.

---

## 1. Procedure

1. **Map the document:** headings, appendices, linked files, size. Note any other copies of the document. If it is not in template v2 format, map it with Appendix R.
2. **Confirm the baselines:** check Appendix P against the current ADR log and ARB. If anything changed, update Appendix P first and record the date.
3. **Read** Part I, then Part II, then the appendices and linked files.
4. **Work through Sections 0 to 20 and Appendices A to N.** Mark every item.
5. **Run the automated checks** (Section Y).
6. **Build the inventories** for the report: artifact inventory, event inventory, external interaction inventory, ADR alignment table.
7. **Apply the gate** and **score** (Section 2).
8. **Write the report** (Section 3).

---

## Checklist

Columns: **ID**, **Type** (R / Q), **Check**, **How to verify**, **Sev**, **Common failure** (seen in earlier reviews).

### Section 0 — Document Control

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S0-01 | R | Document information is complete, including module type and parent document | Read 0.1 | Minor | Version inside the file differs from the file name |
| S0-02 | R | Revision history exists and is current | Read 0.2 | Minor | No change log |
| S0-03 | R | Governing inputs are listed with versions: ARB, ADR log, legacy repositories and commit, KG build, KT outputs, parent document | Read 0.3 | Major | Inputs not versioned, so drift can't be detected |
| S0-04 | R | Source precedence is stated for every concern (behaviour, interfaces, contracts, events, tables, platform standards) | Read 0.4 | Blocker | Agent resolves conflicts differently each time |
| S0-05 | Q | The document says what applies where it is silent | Read 0.4 | Major | |
| S0-06 | Q | Decision, Assumption, Proposal and Open labels are used, and every label has a matching row in §16 or §18 | Search for the labels; compare with §16 and §18 | Major | Unresolved choices written as facts |
| S0-07 | R | Decision status and target-state summary are filled in, and their counts match §16 and §18 | Compare 0.5 and 0.6 with §16 and §18 | Minor | |
| S0-08 | R | Every section has a status line using one of the five statuses (Complete, Partial, Not started, N/A, Inherited); Partial names the gap; Not started names an owner or question; N/A says why the section does not apply; Inherited cites a parent section; each status matches the content | Read 0.7 and each section; compare each status with the section's content (§0.4 table) | Major | Sections silently omitted; empty sections marked Partial; N/A used for "not written yet"; "migrated from vN" as the only reason |
| S0-09 | Q | There is one source file; other copies are retired or marked superseded | List the folder or repository | Minor | Two drafts drifting apart |
| S0-10 | Q | Change management covers legacy changes (Current State Delta Log, ADR-034) | Read 0.4 | Minor | |

### Section 1 — Business Scope and Capabilities

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S1-01 | R | Purpose is stated in business terms | Read 1.1 | Major | |
| S1-02 | R | Capabilities are listed with a disposition (Preserve / Change / New / Retire) | Read 1.2 | Major | No disposition, so new behaviour is not visible |
| S1-03 | R | Ownership boundary with each neighbouring module is drawn (who writes what), with a boundary diagram | Read 1.3 | Blocker | Two modules both writing the same data |
| S1-04 | R | Out of scope is listed | Read 1.4 | Major | |
| S1-05 | R | Actors and roles are listed, including public users and machine callers if any | Read 1.5 | Major | Users of the module not identified |
| S1-06 | R | Business objects are listed with their system of record, and a relationship diagram exists | Read 1.6 | Major | Only a one-line relationship chain |
| S1-07 | Q | Scope matches the ARB's description of the module, or differences are explained | Compare with the ARB module inventory | Major | |
| S1-08 | Q | No out-of-scope data or capability appears in tables, endpoints or events | Compare 1.4 with §9 and the contracts | Blocker | Legacy tables for out-of-scope data carried over |
| S1-09 | Q | For a sub-module: the boundary with the parent is clear, and inherited sections are really identical | Compare with the parent document | Major | |

### Section 2 — Business Logic

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S2-01 | R | A rules catalogue exists with stable IDs | Read 2.1 | Blocker | |
| S2-02 | Q | Each rule has one owning component, source evidence, a disposition, and the outcome when violated (status, error type, field) | Read each row | Major | Outcome not stated |
| S2-03 | Q | Rules are testable: no undefined terms or parameters (windows, calendars, "today", thresholds) | Read each rule | Major | "Plan year" or "today" undefined; no time zone |
| S2-04 | R | Every calculation, precedence or matching algorithm is complete for every branch or level, names its data source for each, and has worked examples including boundaries | Read 2.2; walk each branch | Blocker | A precedence level with no data source; free-form matching criteria |
| S2-05 | R | If the module has workflow: status table, transition table (trigger, actor, guard, side effects) and state diagram, all agreeing | Read 2.3; compare diagram and tables | Blocker | |
| S2-06 | Q | Every transition has a trigger: user action, event, or time | Check each arrow | Blocker | Automatic transitions with no owner |
| S2-07 | Q | Actors are unambiguous ("System / Approver"); segregation of duties stated; return paths keep prior state where it matters; the governed-records list matches the endpoints | Read 2.3 | Major | |
| S2-08 | R | Time-based behaviour (if any): owner component, schedule, time zone source, catch-up, events, monitoring | Read 2.4 | Blocker | Missing entirely |
| S2-09 | Q | Bulk behaviour is defined (imports creating many workflow records; bulk actions) | Read 2.3 and §11 | Major | Thousands of drafts with no bulk submit |
| S2-10 | R | Rules engine integration: rule sets, input facts, outputs, timeout, fail mode, caching and invalidation; or "not used" with a reason | Read 2.5 | Blocker | Rules engine named with no contract |
| S2-11 | R | Validation table exists with enforcement layer | Read 2.6 | Major | |
| S2-12 | R | Audit, history and versioning are defined | Read 2.7 | Major | |
| S2-13 | R | Tenant-variable behaviour is listed with configuration keys; no tenant-specific code | Read 2.8; compare with Appendix J | Major | Legacy app settings not mapped |
| S2-14 | R | Notifications are defined (trigger, recipient, channel, mechanism) | Read 2.9 | Major | Reviewers have no way to learn of new work |
| S2-15 | R | Acceptance criteria (Given/When/Then) exist for every workflow and for rule edge cases | Read 2.10 | Major | None |
| S2-16 | R | Parity approach is stated; every Change and New item is in the known-difference register | Read 2.11; compare with Appendix M | Major | New behaviour counted as parity failures |

### Section 3 — Architecture Overview

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S3-01 | R | Architecture classification and patterns are stated, each with its ADR | Read 3.1 | Major | Pattern chosen without citing the ADR |
| S3-02 | R | System context (C1) diagram with every actor, external system, shared service and other module; edges labelled with content and sync or async; plus a table | Read 3.2 | Blocker | |
| S3-03 | R | Container and component (C2) diagram with every deployable and store, edges labelled with protocol; plus a container table | Read 3.3 | Blocker | |
| S3-04 | R | Technology stack per layer with versions and a decision reference per row | Read 3.4 | Blocker | No ADR citations |
| S3-05 | R | End-to-end request flow diagram showing API Gateway and where authentication, tenant resolution and authorization happen at each hop | Read 3.5 | Blocker | Gateway missing from the path |
| S3-06 | R | Component interaction matrix covers every C2 edge | Compare 3.6 with the C2 edges | Major | |
| S3-07 | R | Deployment and runtime view diagram | Read 3.7 | Major | |
| S3-08 | R | Sequence diagrams exist for every applicable key flow listed in 3.8 | Read 3.8 | Major | Only one or two flows shown |
| S3-09 | Q | Diagrams are in a text format and render | Section Y-19 | Minor | |
| S3-10 | Q | Diagrams and tables agree: same components, same edges, same names as contracts | Compare node lists, tables, contracts | Major | A store linked to one component in the diagram but used by others in the text |
| S3-11 | Q | The request path matches the ARB (browser → API Gateway → BFF → domain API) | Compare with Appendix P | Blocker | |
| S3-12 | Q | Runtime per component (API, BFF, consumers, batch) matches the ADRs, or an exception is recorded | Compare with Appendix P and §16.3 | Blocker | |

### Section 4 — Frontend

*N/A only if the module has no user interface; say so.*

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S4-01 | R | Architecture overview with composition diagram (shell, micro frontend, BFF) and per-tenant versioning approach | Read 4.1 | Major | "One deployment for all tenants" against the ADR |
| S4-02 | R | Frontend technology stack | Read 4.2 | Major | |
| S4-03 | R | Screen inventory with disposition, roles and backing BFF endpoints | Read 4.3 | Major | |
| S4-04 | R | A screen spec card (Appendix H) exists for every in-scope screen | Compare 4.3 with Appendix H | Blocker | Screens listed by name only |
| S4-05 | R | Navigation map and shell integration (events sent and received) | Read 4.4 | Major | |
| S4-06 | Q | Tenant customization is configuration-driven; nothing is forked per tenant | Read 4.5 | Major | Tenant-specific code chunks |
| S4-07 | R | API communication: entry point, headers, token or session, CSRF, error handling | Read 4.6 | Major | |
| S4-08 | R | Hosting, security headers, telemetry, PII handling, accessibility standard and CI gates | Read 4.7 | Major | Security headers missing |
| S4-09 | R | Public or anonymous flows (if any): token type, allowed operations, save and resume | Read 4.8 | Major | |

### Section 5 — BFF

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S5-01 | R | Responsibilities listed, including what the BFF must not own | Read 5.1 | Major | |
| S5-02 | R | Every route listed and marked pass-through or composed | Read 5.2 | Major | Wildcard routes only |
| S5-03 | R | Every composed endpoint has a contract in Appendix C | Compare 5.2 with Appendix C | Blocker | BFF given aggregation duties with no contract |
| S5-04 | Q | Each composed endpoint states call order, partial-failure handling, and cache key and TTL | Read 5.3 | Major | |
| S5-05 | R | Session and token model is defined and fits API Gateway JWT validation | Read 5.4; compare with §10.2 | Major | Cookie session that the gateway's JWT check can't validate |
| S5-06 | R | Contract governance stated | Read 5.5 | Major | |
| S5-07 | R | Technology (with decision reference) and resilience settings | Read 5.6 | Minor | |

### Section 6 — Domain Services

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S6-01 | R | Service pattern and boundaries, with ADR | Read 6.1 | Major | |
| S6-02 | R | A service catalog card for every service | Read 6.2 | Blocker | |
| S6-03 | R | If legacy exists: every legacy surface (WCF, SOAP, Web API, OData, internal) is mapped with a disposition and its legacy consumers | Read 6.3; compare with the KG and Appendix K | Blocker | Consumers not listed |
| S6-04 | R | API design standards summarized and detailed in Appendix A | Read 6.4 | Major | |
| S6-05 | R | Synchronous calls listed with protocol, auth, timeout, retry | Read 6.5 | Major | |
| S6-06 | Q | No synchronous cross-domain calls without an approved exception | Check 6.5 and the C2 edges | Major | |
| S6-07 | R | Persistence pattern, transaction boundaries, concurrency control and tenant routing | Read 6.6 | Major | |
| S6-08 | R | Resiliency patterns | Read 6.7 | Major | |
| S6-09 | Q | Every endpoint named in the text exists in a contract, and the reverse | Section Y-23 | Major | |

### Section 7 — Eventing

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S7-01 | R | Event Backbone strategy with ADR references | Read 7.1 | Major | |
| S7-02 | R | Event Backbone diagram: producers, relay, adapter, topics, consumers (including other modules), DLQs | Read 7.1 | Blocker | |
| S7-03 | R | Published event catalog: name, version, type, producer, trigger, topic, named consumers, ordering key, schema | Read 7.3 | Blocker | |
| S7-04 | R | Consumed event catalog with handler spec: checks (version, tenant, duplicate, stale), tables written, events emitted, failure path | Read 7.4 | Blocker | Handler actions given, failure path missing |
| S7-05 | R | Every event classified by type (7.2) | Read 7.3 and 7.4 | Major | Not classified |
| S7-06 | R | Producer–consumer matrix | Read 7.5 | Major | |
| S7-07 | R | Canonical envelope matches the ADR exactly | Compare with Appendix P | Blocker | |
| S7-08 | R | Payload schema and example for every published and consumed event (Appendix E) | Compare the catalogs with Appendix E | Blocker | Only the envelope defined |
| S7-09 | R | Topics and channels with transport names, ordering keys, retention and DLQs | Read 7.6 | Major | Retention not stated |
| S7-10 | R | Delivery guarantees: outbox, multi-tenant relay, idempotency and deduplication, ordering and stale-event rule, retry, replay, DLQ redrive | Read 7.7 | Major | Relay doesn't say how it covers every tenant database |
| S7-11 | R | Schema versioning, compatibility and registry | Read 7.8 | Major | |
| S7-12 | Q | Every published event names a consumer or gives a reason for having none | Read 7.3 | Major | |
| S7-13 | Q | Consumed events and their producers agree with the producing module's catalog and the ARB event map | Compare with neighbouring target states and the ARB | Major | Consumed events differ from what the producer publishes |
| S7-14 | Q | `tenant_id` source is correct for each producer (request context, not "the JWT", for jobs and consumers); no PII in payloads | Read 7.1, 7.3 and Appendix E | Major | |
| S7-15 | Q | Events raised by batch jobs, scheduled jobs and consumers are included | Compare producers in 7.3 with §2.4 and §11 | Major | |
| S7-16 | Q | The outbox table can build every envelope field | Compare outbox columns (Appendix D) with the envelope | Major | Trace ID, producer or version not stored |
| S7-17 | Q | Event names follow the naming convention | Section Y-17 | Minor | |

### Section 8 — External Interactions and Shared Services

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S8-01 | R | Inventory of every external system, shared platform service and other module, with direction, sync or async, owner and contract status | Read 8.1 | Blocker | |
| S8-02 | R | External interaction view diagram | Read 8.1 | Blocker | |
| S8-03 | R | An interface spec (Appendix F) for every inventory entry, with the minimum content in template 8.2 | Compare 8.1 with Appendix F | Blocker | Rules engine or integration adapter with no spec |
| S8-04 | R | Inbound access statement: allowed external callers and scopes, or "None" | Read 8.3 | Major | |
| S8-05 | R | Shared platform service usage table filled in (used or not, for every row) | Read 8.4 | Major | Notifications or reporting silently skipped |
| S8-06 | Q | The same systems appear in C1, C2, the external view, the inventory and Appendix F | Section Y-22 | Blocker | |
| S8-07 | Q | Endpoints and credentials are configuration (Secrets Manager, Tenant Registry), never code | Read Appendix F | Major | |
| S8-08 | Q | Every external call has timeout, retry and failure behaviour that fit the NFRs; contract owner and status known | Compare Appendix F with §13 | Major | |
| S8-09 | R | Legacy reports are catalogued with their replacements (if the module had reports) | Read 8.5 | Major | No report catalog |
| S8-10 | Q | Outbound files use the platform delivery pattern | Read 8.4 | Minor | |
| S8-11 | Q | The integration boundary component is named as in the ARB, or a query records the difference | Compare with Appendix P and Q | Major | |

### Section 9 — Data Architecture and Persistence

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S9-01 | R | Data architecture overview with diagram | Read 9.1 | Major | |
| S9-02 | R | Data model with ERD | Read 9.2 | Major | No ERD |
| S9-03 | R | Data ownership: writing component(s) for every store, schema and table | Read 9.3 | Major | Two tables for one concept with different keys |
| S9-04 | R | Database and schema design: tenancy, schema ownership, shared reference data, connection routing | Read 9.4 | Blocker | |
| S9-05 | R | DDL (Appendix D) for every table, or a pointer to a named legacy entity | Section Y-16 | Blocker | Many tables "mirror legacy" with no pointer |
| S9-06 | R | Legacy-to-target data mapping at table and column level (Appendix L) | Read 9.5 and Appendix L | Major | Table level only |
| S9-07 | R | Data classification per column | Read 9.6 | Major | No classification |
| S9-08 | R | Lifecycle and retention | Read 9.7 | Major | |
| S9-09 | R | Data migration and reconciliation with tolerances | Read 9.8 | Major | Checks named, no tolerances |
| S9-10 | R | Schema migration tool and per-tenant process | Read 9.9 | Major | |
| S9-11 | R | Legacy history and archive handling | Read 9.10 | Major | |
| S9-12 | R | Data volumes | Read 9.11 | Minor | |
| S9-13 | Q | Tenancy model matches the ADR | Compare with Appendix P | Blocker | Database per module instead of per tenant |
| S9-14 | Q | Shared versus tenant placement matches the ADR; no foreign keys across databases | Read 9.4 and Appendix D | Major | |
| S9-15 | Q | No data outside the platform classification (provider PII only; no PHI or beneficiary data) | Compare 9.6 with tables, payloads and logs | Blocker | Member-level legacy tables carried over |

### Section 10 — Security, Identity and Tenancy

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S10-01 | R | Trust boundary and token flow diagram (users, public, machine callers, service-to-service; WAF; secrets) | Read 10.1 | Blocker | |
| S10-02 | R | Identity flows match the ADR (identity broker, protocols, token contents) | Compare 10.2 with Appendix P | Blocker | Superseded identity provider named |
| S10-03 | R | Authorization model with enforcement points; matrix in Appendix G | Read 10.3 | Major | |
| S10-04 | Q | Tenant and user come only from the token, never from request data | Read 10.4 and Appendix A | Blocker | |
| S10-05 | R | Every isolation boundary in the ADR is listed with its negative test | Compare 10.4 with Appendix P | Blocker | |
| S10-06 | R | Service identity and secrets | Read 10.2 and 10.5 | Major | |
| S10-07 | R | Data protection: encryption, KMS key per tenant, TLS version, PII masking, PII never in errors, query strings or headers | Read 10.5 | Major | |
| S10-08 | R | WAF placement, frontend security headers, penetration test | Read 10.1, 10.6 and 4.7 | Major | |
| S10-09 | R | Audit and security monitoring | Read 10.6 | Major | |
| S10-10 | Q | No tenant-specific code branches anywhere (UI, BFF, services, jobs) | Search "if tenant", "state-specific", tenant codes | Major | |

### Section 11 — Batch and File Processing

*N/A only if the module has no batch or files; say so.*

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S11-01 | R | Jobs and feeds table with schedule, component, outputs, SLA | Read §11 | Major | |
| S11-02 | R | Every legacy loader, SSIS package or scheduled job mapped or retired | Compare with Appendix K | Major | |
| S11-03 | R | Import flow: upload, start, status, row-level errors, idempotency | Read §11 | Major | |
| S11-04 | R | Formats in Appendix I | Read Appendix I | Major | |
| S11-05 | Q | Orchestration and SLA match the ADR | Compare with Appendix P | Major | |
| S11-06 | Q | How imported records enter workflows, including bulk actions | Read §11 and 2.3 | Major | |

### Section 12 — Infrastructure, Delivery and Operations

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S12-01 | R | Compute and scaling per component | Read 12.1 | Major | |
| S12-02 | R | Network and ingress (API Gateway, private networking, network policies) | Read 12.2 | Major | Internet-facing load balancer instead of the gateway |
| S12-03 | R | Delivery tooling per component type with decision references; gaps in the ADRs flagged | Read 12.3 | Major | Tooling the ADR excludes, with no exception |
| S12-04 | R | Full CI gate list | Compare 12.4 with Appendix P | Minor | Partial list |
| S12-05 | R | Observability: tracing, logs, metrics, dashboards | Read 12.5 | Major | |
| S12-06 | R | Alerts with thresholds | Read 12.5 | Major | |
| S12-07 | R | Runbooks | Read 12.6 | Minor | |
| S12-08 | R | DR for every runtime used | Read 12.7 | Minor | DR covers one runtime only |

### Section 13 — Non-Functional Requirements

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S13-01 | R | Each NFR has metric, target, workload, scope and measurement method | Read §13 | Major | Targets with no measurement method |
| S13-02 | Q | Values match the program baseline, or stricter values are justified | Compare with Appendix P | Major | |
| S13-03 | Q | Module-specific NFRs added where needed (heavy operations, imports, rule evaluation) | Read §13 | Minor | |
| S13-04 | Q | Volumes in 9.11 support the NFRs | Compare §13 with 9.11 | Minor | |

### Section 14 — Testing and Quality

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S14-01 | R | Test levels table with tooling, gates and owners | Read 14.1 | Major | No test strategy |
| S14-02 | R | Golden data sets | Read 14.2 | Major | |
| S14-03 | R | Review of generated test artifacts (ADR-028) | Read 14.3 | Major | |
| S14-04 | Q | Contract tests cover APIs and events; tenant isolation suite is a merge gate | Read 14.1 | Major | |
| S14-05 | Q | Parity testing and thresholds (ADR-029) | Read 14.1 and 2.11 | Major | "No material variance" with no numbers |
| S14-06 | R | Traceability matrix: rule → endpoint or event → screen → test | Read 14.4 | Major | Only a test-naming rule |

### Section 15 — Legacy Transition and Retirement

*N/A only for modules with no legacy predecessor; say so.*

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S15-01 | R | Strangler fig pattern and granularity (by tenant or by capability) stated, citing ADR-022 | Read 15.1 | Blocker | Not stated |
| S15-02 | Q | Granularity is consistent with the migration approach (by capability needs a data sync design) | Compare 15.1 with 9.8 | Blocker | One-time load and "no dual-write" while implying per-operation switch-over |
| S15-03 | R | Coexistence diagram | Read 15.2 | Major | |
| S15-04 | R | Phases with system of record, legacy endpoint state and exit criteria tied to ADR-029 thresholds | Read 15.3 | Major | |
| S15-05 | R | Every legacy endpoint has its consumers and switch method | Read 15.4; compare with 6.3 and Appendix K | Blocker | Legacy endpoint "retired" with callers unchecked |
| S15-06 | R | Temporary compatibility components named with owner and removal date (if needed) | Read 15.4 | Major | |
| S15-07 | R | Rollback window and data handling | Read 15.5 | Major | |
| S15-08 | R | Measurable retirement criteria per endpoint | Read 15.6 | Major | |
| S15-09 | R | Handling of legacy changes during transition | Read 15.7 | Minor | |

### Section 16 — Architecture Decisions

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S16-01 | R | Decision register cites enterprise ADRs by ID | Read 16.1; Section Y-02 | Major | No ADR cited anywhere |
| S16-02 | R | Alignment table has a row for **every** ADR in the log | Compare 16.3 with the ADR log | Blocker | |
| S16-03 | Q | No superseded technology or names (Appendix Q) | Section Y-03 | Blocker | |
| S16-04 | Q | Every deviation has an exception with owner and approval path, a proposed ADR, or an open question | Compare 16.3 with §18.3 | Blocker | Deviations written as settled design |
| S16-05 | R | Domain decisions have full detail (context, alternatives, rationale, consequences, owner) | Read 16.2 | Major | |
| S16-06 | Q | Conflicts within the ADR log or ARB that affect the module are flagged | Read 16.3 and §18.3 | Major | Module follows one of two conflicting ADRs without saying which |
| S16-07 | Q | Enterprise ADR text is cited, not copied | Read §16 | Minor | |

### Section 17 — Anti-Pattern Analysis

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S17-01 | R | Findings with evidence for each category in the template (or N/A for net-new modules) | Read §17 | Major | |
| S17-02 | Q | Each finding maps to a target remediation and a verification (test or gate) | Read §17 | Major | |

### Section 18 — Risks, Assumptions and Open Questions

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S18-01 | R | Risk register with owners and mitigations | Read 18.1 | Major | |
| S18-02 | R | Assumptions with owners and confirm-by dates | Read 18.2 | Major | |
| S18-03 | R | Open questions with ID, owner, due date, severity and status | Read 18.3 | Major | No open-questions section |
| S18-04 | Q | Every in-text marker (TBD, TODO, Open, Assumption, Proposal) has a row | Section Y-18 | Minor | |
| S18-05 | Q | The document isn't presented as final or approved while Blocker questions are open | Compare 0.1 status with 18.3 | Major | Reads as final with open conflicts |

### Section 19 — Repository Structure and Build Plan

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S19-01 | R | Repository layout | Read 19.1 | Major | |
| S19-02 | R | Module and service internal structure | Read 19.2 | Major | |
| S19-03 | R | Legacy capability to layout mapping | Read 19.3 | Major | |
| S19-04 | R | Slice catalog with rules, endpoints, events, tables, screens, jobs and legacy sources | Read 19.4 | Major | No slices |
| S19-05 | R | Build order with dependencies | Read 19.4 | Major | |
| S19-06 | R | Definition of done per slice | Read 19.4 | Minor | |

### Section 20 — Readiness

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| S20-01 | R | Readiness table with evidence for every row | Read §20 | Major | |
| S20-02 | Q | Readiness claims are supported by this review's results | Compare §20 with the review findings | Major | "Ready" claimed with open Blockers |

### Appendices — Low-Level Design

#### Appendix A — API Standards

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AA-01 | R | Covers versioning, auth and tenant context, correlation, idempotency, error model, concurrency, workflow actions, paging, JSON naming, scopes, breaking-change policy | Read Appendix A | Major | |
| AA-02 | Q | Every standard is applied in the contracts | Section Y-05 to Y-13 | Major | Concurrency promised but absent from contracts |

#### Appendix B — Domain OpenAPI Contracts

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AB-01 | R | One OpenAPI 3.x contract per service or area, listed with base route and version | Read Appendix B | Blocker | |
| AB-02 | Q | The file list matches the files present | Compare the list with the files | Minor | List and files differ |
| AB-03 | Q | Every file parses; every `$ref` resolves | Section Y-04 | Major | |
| AB-04 | Q | No operation returns its request schema as its response | Section Y-05 | Major | Legacy query objects returned as results |
| AB-05 | Q | Schema names are readable and stable (no generator hashes, no legacy base classes) | Section Y-06 | Major | |
| AB-06 | Q | One JSON naming policy | Section Y-07 | Major | Mixed PascalCase and camelCase |
| AB-07 | Q | Every update, validate, lock or other change of an existing record requires the version field and declares `409` | Section Y-08 | Major | |
| AB-08 | Q | Every state-changing operation requires the idempotency header | Section Y-09 | Major | |
| AB-09 | Q | Request, response and error examples for every operation, with synthetic values | Section Y-10 | Major | No examples |
| AB-10 | Q | Scopes declared per operation in the contract | Section Y-11 | Major | Scopes only in a separate table |
| AB-11 | Q | No tenant or user fields accepted in request bodies (or marked read-only and deprecated) | Section Y-12 | Minor | |
| AB-12 | Q | Paths follow the stated style, or exceptions are explained | Section Y-13 | Minor | Verb segments such as `/add`, `/get` |
| AB-13 | Q | Paging is consistent | Read search operations | Minor | |
| AB-14 | Q | Legacy operation names kept for traceability where a legacy equivalent exists | Read operationIds or `x-legacy-*` | Major | |

#### Appendix C — BFF Contracts

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AC-01 | R | OpenAPI for every composed BFF endpoint, and a routing table for pass-through routes | Read Appendix C | Blocker | Missing |
| AC-02 | Q | Every screen action maps to a BFF operation | Section Y-23 | Major | |
| AC-03 | Q | BFF contracts meet the same quality checks as Appendix B (AB-03 to AB-13) | Section Y | Major | |

#### Appendix D — Database Schema

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AD-01 | R | ERD and DDL for every table, or a named legacy pointer | Section Y-16 | Blocker | |
| AD-02 | Q | All DDL runs on an empty database of the target engine version | Section Y-15 | Major | Unsupported syntax |
| AD-03 | Q | Tables follow the stated conventions (audit, workflow and effective-date columns present where the text says) | Compare each table with the conventions | Major | Columns promised in text missing from DDL |
| AD-04 | Q | Overlap and uniqueness rules from §2 are enforced by written-out constraints | Map each rule to a constraint | Major | Constraint described only in a comment |
| AD-05 | Q | Status values constrained on every table that has them | Search for status check constraints | Minor | |
| AD-06 | Q | Indexes support the main lookups and searches | Compare search criteria with indexes | Minor | |
| AD-07 | Q | One table per concept | Look for duplicated entities | Major | |

#### Appendix E — Event Contracts

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AE-01 | R | AsyncAPI (or JSON Schema) with channels, envelope and one message per published and consumed event | Read Appendix E | Blocker | |
| AE-02 | Q | Parses and validates | Lint | Major | |
| AE-03 | Q | One example per message | Count examples | Major | |
| AE-04 | Q | Matches the catalogs in §7 exactly | Section Y-21 | Major | |

#### Appendix F — External Interface Specifications

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AF-01 | R | One spec per inventory entry in §8.1 | Compare with §8.1 | Blocker | |
| AF-02 | Q | Each spec has all minimum content (mechanism, contract, auth, data, volume, timeout and retry, failure mode, SLA, config key, test approach) | Read each spec | Major | |

#### Appendix G — Authorization Matrix

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AG-01 | R | Matrix of role × scope × operation | Read Appendix G | Major | |
| AG-02 | Q | Covers every domain and BFF operation, machine callers and service identities | Compare with Appendices B and C | Major | |
| AG-03 | Q | Segregation-of-duties conditions stated | Read Appendix G | Major | |

#### Appendix H — Screen Specifications

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AH-01 | R | Navigation map and one card per in-scope screen | Compare with 4.3 | Blocker | |
| AH-02 | Q | Each card complete: route, roles, criteria, columns, fields, actions by status and role, states, BFF endpoints | Read each card | Major | |
| AH-03 | Q | Reference screens or legacy views linked | Read each card | Minor | |

#### Appendix I — Batch and File Formats

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AI-01 | R | Spec per feed with the minimum content in the template | Read Appendix I | Major | |
| AI-02 | Q | Validations cite the legacy source; tenant-specific templates versioned | Read Appendix I | Minor | |

#### Appendix J — Configuration Catalog

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AJ-01 | R | Every key and flag with type, default, scope, user and owner | Read Appendix J | Major | Missing |
| AJ-02 | Q | Every tenant-variable behaviour in 2.8 has a key here | Compare with 2.8 | Major | |

#### Appendix K — Legacy Inventory

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AK-01 | R | Inventory of legacy screens, endpoints, tables, jobs, events, rules, reports and settings (or N/A for net-new) | Read Appendix K; compare with the KG | Blocker | |
| AK-02 | Q | Every item has a disposition and target reference | Read each row | Major | |
| AK-03 | Q | Every "follows legacy" statement names the legacy class, file or KG node | Search "legacy", "mirror" | Major | |

#### Appendix L — Migration and Cutover Detail

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AL-01 | R | Column-level mapping, transformation rules, load order, reconciliation tolerances, comparison cases, runbook references | Read Appendix L | Major | |

#### Appendix M — Known-Difference Register

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AM-01 | R | Register exists; every Change and New disposition has an entry with approval status | Compare with dispositions in §1, §2, §4 | Major | Missing |

#### Appendix N — Glossary and References

| ID | Type | Check | How to verify | Sev | Common failure |
|---|---|---|---|---|---|
| AN-01 | R | Glossary covers domain and program terms; references list versions and locations | Read Appendix N | Minor | |

---

## Y. Automated Checks

Run on the document and its linked files. Record counts in the report.

| ID | Check | Method | Pass condition |
|---|---|---|---|
| Y-01 | Structure | List headings with line numbers; compare with template v2 sections | Every template section present (or status given) |
| Y-02 | ADR citations | Count `ADR-\d+` | Every tech stack row and every pattern cites one |
| Y-03 | Superseded terms | Search every term in Appendix Q, case-insensitive | 0 hits, or each one explained |
| Y-04 | OpenAPI validity | Lint every contract (e.g. `redocly lint`, `spectral lint`) | 0 errors |
| Y-05 | Request echoed as response | Compare each operation's request `$ref` with its `200`/`201` response `$ref` | 0 equal |
| Y-06 | Generated schema names | Names like `\w+Of\w+` with hash suffixes, or ending in an 8-character mixed-case hash; references to legacy base classes | 0 |
| Y-07 | Property casing | Count PascalCase and camelCase property names per file | One style |
| Y-08 | Concurrency | Update-type operations without the version field or without `409` | 0 |
| Y-09 | Idempotency | State-changing operations (excluding searches) without the idempotency header | 0 |
| Y-10 | Examples | Count `example:` and `examples:` per operation and per event message | At least 1 each |
| Y-11 | Scopes in contract | OAuth2 security schemes with per-operation scopes | Present |
| Y-12 | Tenant fields | `tenantId`, `TenantId`, `Requestor` and similar in request schemas | 0, or read-only and deprecated |
| Y-13 | RPC-style paths | Path segments `/add`, `/update`, `/get`, `/delete`, `/cancel`, `/upload`, `/lock`, `/unlock`, `/edit-*` | 0, or each explained |
| Y-14 | Method mix | Count GET, POST, PATCH, PUT, DELETE | Recorded; consistent with the stated style |
| Y-15 | DDL execution | Run all DDL in order on an empty database of the target engine version | 0 errors |
| Y-16 | Tables without DDL | Table names in the text versus `create table` names | Each missing one has a legacy pointer |
| Y-17 | Event names | Every event name versus the naming convention | All match, or explained |
| Y-18 | Open markers and statuses | Count `TBD`, `TODO`, `to confirm`, `Open (`, `Assumption (`, `Proposal (`. Count status lines by value (`Status: Complete`, `Partial`, `Not started`, `N/A`, `Inherited`) and list any other value | Each marker has a row in §16 or §18; every status line uses one of the five values; the counts match 0.7 |
| Y-19 | Diagrams | Render every Mermaid block; map each to a required diagram | All render; every required diagram found |
| Y-20 | Required diagram inventory | Check the required diagrams in §1.3, 1.6, 2.3, 3.2, 3.3, 3.5, 3.7, 3.8, 4.1, 7.1, 8.1, 9.1, 9.2, 10.1, 15.2 | All present or N/A with reason |
| Y-21 | Event cross-check | Event names in §6.2, §7.3, §7.4, §7.5, Appendix E and the diagrams | 0 differences |
| Y-22 | External system cross-check | Systems in §3.2, §3.3, §8.1, the external view and Appendix F | 0 differences |
| Y-23 | Contract coverage | Screen actions → BFF operations → contract operations; endpoints in the text → contracts | 0 unmapped |
| Y-24 | Table coverage | Tables named in sequence diagrams, consumer handlers and batch specs → Appendix D | 0 missing |

**Manual equivalent:** use editor search with the same patterns. For Y-05, open the largest contracts and check the search operations by eye.

---

## 2. Gate, Scoring and Verdict

### 2.1 Gate

The gate is every item of **Type R** with severity **Blocker**. If any of them is **Fail** (missing) and not validly N/A or Inherited, the overall verdict is **Not ready**, whatever the other results.

### 2.2 Section rating

| Rating | Rule |
|---|---|
| **Strong** | No Fail; at most one Partial, and it is Minor |
| **Adequate** | No Blocker Fail; some Partials or Major Fails |
| **Weak** | One or more Blocker Fails, or most items Partial or Fail |

### 2.3 Readiness by generation layer

A layer is ready when every item listed for it is Pass, N/A or Inherited.

| Layer | Items |
|---|---|
| Domain core (rules, calculations, workflow) | S0-04, S1-03, S2-01, S2-04, S2-05, S2-06, S2-08, S2-10, S16-02 |
| Domain APIs | S3-04, S3-05, S3-11, S3-12, S6-02, S6-03, S10-02, S10-04, AB-01, AB-03 to AB-09 |
| Persistence and migrations | S9-04, S9-05, S9-13, S9-15, AD-01, AD-02 |
| Eventing | S7-02, S7-03, S7-04, S7-07, S7-08, S7-13, AE-01 |
| BFF | S5-03, S5-05, AC-01 |
| Frontend | S4-04, S4-07, AH-01, AC-01 |
| Batch and imports | S11-01 to S11-04 |
| External integrations | S8-01, S8-02, S8-03, S8-06, AF-01 |
| Platform plumbing (tenancy, isolation, security, observability) | S3-02, S3-03, S10-01, S10-05, S12-01, S12-05 |
| Legacy transition | S15-01, S15-02, S15-05, AK-01 |

### 2.4 Overall verdict

- **Not ready:** the gate fails, or the domain core or domain APIs layer is not ready.
- **Ready with conditions:** the gate passes and some layers are ready. List the layers that are not, and what blocks them.
- **Ready:** the gate passes and every layer is ready.

---

## 3. Report Template

Save as `<module>-target-state-review.md`.

```markdown
# <Module> Target State: Review

**Document reviewed:** <file, version, size; linked files>
**Reviewed against:** ADR log <date>; ARB <version>; legacy <commit / KG build>; parent document <version>
**Reviewer:** <name or agent>   **Date:** <date>   **Checklist:** v2.0

## 1. Summary
<Verdict: Ready / Ready with conditions / Not ready. Then 3 to 5 sentences on the main strengths and gaps.>

## 2. Gate result
| Item | Check | Result | Evidence |
(List every Type R Blocker item. State Pass or Fail for the gate.)

## 3. Readiness by layer
| Layer | Ready? | Blocking items |

## 4. Scorecard
| Section | Rating | Pass | Partial | Fail | N/A | Inherited |
| 0 Document Control | | | | | | |
| ... | | | | | | |
| Appendix N | | | | | | |

## 5. What the document does well
<Bullets with section references. Practices other teams should reuse.>

## 6. Findings
| ID | Item | Severity | Result | Evidence (section, quote) | Recommended fix |
(Blocker first, then Major, then Minor.)

## 7. Inventories
### 7.1 Required diagrams
| Diagram (template section) | Present? | Location |
### 7.2 Events
| Event | Type | Producer | Consumers | Topic | Schema? | Example? |
### 7.3 External interactions
| System | Direction | Mechanism | Sync / async | Auth | Spec? | Contract status |
### 7.4 ADR and ARB alignment
| ADR | Topic | Aligned / Exception / Gap / N/A | Evidence | Action |

## 8. Automated check results
| ID | Result | Count / detail |

## 9. Problems in the other inputs
<Conflicts or errors in the ADR log, ARB, KG or parent document that affect this module.>

## 10. Recommended next steps
<Ordered list.>
```

---

## Appendix P — Provider Plus Platform Baseline

The values every module must agree with, from the ADR log and ARB. **Confirm against the current ADR log and ARB before each review, and update this table and its date when they change.**

**Last confirmed:** 2026-11-01 (ADR log as of that date; ARB v2.3).

| Area | Baseline | Source |
|---|---|---|
| Entry point | Amazon API Gateway with native JWT authorizer is the single entry point; path micro frontend → API Gateway → BFF → domain API | ADR-008, ARB §3.1 |
| Identity | IRM broker (an identity broker, not the identity provider), federating to state IdPs and Gainwell IdP (Microsoft Entra ID). Users: FAPI 2.0 (Authorization Code with PKCE and PAR). Public flows: public-scope JWT with `tenant_id`, no user identity. Machine callers: OAuth 2.0 client credentials, secrets rotated every 90 days | ADR-014, ADR-036 |
| Service-to-service | IAM-signed requests; no service mesh | ADR-009 |
| API runtime | .NET 10. ADR-005: EKS Auto Mode for APIs. ARB: Lambda first, EKS as alternative (they differ; state which applies) | ADR-004, ADR-005 |
| BFF runtime | ADR-011 states .NET 10 Native AOT. **Program decision: NestJS 10, pending ADR amendment** | ADR-011; program decision |
| Event consumers | Lambda consumer functions for projectors and integration workers | ADR-005 |
| Batch | AWS Glue Spark (Python 3.12) orchestrated by Amazon MWAA; 99% of jobs within 4 hours | ADR-010 |
| Frontend | React 19 and Next.js micro frontends on S3 and CloudFront, independently deployable and versioned per tenant | ADR-011 |
| Database | Aurora PostgreSQL Multi-AZ; one database per tenant on a shared cluster; national clinical code sets in `db_shared`, read-only to services, written only by loader jobs | ADR-012, ADR-020 |
| Schema migrations | Alembic, per tenant database | ADR-007 |
| Data migration | AWS DMS plus custom scripts | ADR-013 |
| Data classification | Provider PII only; no PHI; no beneficiary data | ADR-006, ARB §4.5 |
| Cross-domain communication | Event Backbone through the Event Adapter only; no synchronous calls between domains; domains may call CM-CORE shared services synchronously | ADR-002, ARB §3.1 |
| Event envelope | `tenant_id`, `event_name`, `event_version`, `event_id`, `occurred_at`, `correlation_id`, `trace_id`, `producer` | ADR-002 |
| Topics | `pp.<domain>.<stream>`; environment-scoped, not tenant-scoped; tenant in headers | ADR-002 |
| Schema registry | AWS Glue Schema Registry | ADR-002a |
| Retention and DLQ | 90-day retention; dead-letter topic per domain; CloudWatch alarm on DLQ depth; envelope validation on every message | ADR-037 |
| Outbound files | S3 with tenant-prefixed path, then MoveIt | ADR-003 |
| Rules engine | InRule via `TenantRulesClient`; per-tenant LRU cache; binding in `tenant_integration_endpoints`; invalidation on `inrule.ruleset-deployed.v1`; no tenant if-checks | ADR-018 |
| Workflow engine | Appian via OAuth 2.0 client credentials; notified asynchronously by event | ADR-017 |
| Correspondence | Correspondence Service through CaaS; event-driven; channel by feature flag | ADR-039 |
| Reporting | SSRS replaced by the Reporting Service (on demand) or Glue jobs (batch) | ADR-019, ADR-021 |
| Legacy interfaces | Every WCF and SOAP endpoint replaced by OpenAPI REST; strangler fig: new built beside legacy, parity validated, legacy WCF retired at Gate 3; IIS decommission approved by the Operations Lead | ADR-022 |
| CQRS | **Conflict in the ADR log:** ADR-026 mandatory; ADR-040 event projectors; ADR-041 not implemented. The module must state which it follows | ADR-026, ADR-040, ADR-041 |
| Shared libraries | `hpp_tenant_context`, `hpp_auth`, `hpp_db`, `hpp_observability`, `hpp_feature_flags_client`, `hpp_contracts`, `hpp_tenant_registry_client`; published to JFrog Artifactory | ADR-025 |
| Tenant isolation | Seven boundaries, negative tests on every pull request: (1) JWT `tenant_id`; (2) database routing; (3) S3 prefix; (4) Event Backbone consumer; (5) Redis key prefix; (6) CloudWatch namespace; (7) Tenant Registry configuration | ADR-023 |
| Security | Zero trust; WAF on the ALB (containers) or as a regional web ACL on API Gateway (serverless), none at CloudFront; KMS key per tenant; TLS 1.3 (1.2 for legacy inbound only); CSP, HSTS, X-Frame-Options, Referrer-Policy, SRI on frontends; external pen test before go-live | ADR-031 |
| Observability | OpenTelemetry; JSON logs with `tenant_id`, `correlation_id`, `service_name`, `timestamp`, `severity`; PII redaction (allow-list, HMAC-SHA256); per-tenant dashboards; CloudTrail and pgAudit to S3 Object Lock, 7 years | ADR-016 |
| CI/CD | GitHub Actions, trunk-based, protected main; Terraform (S3 state, DynamoDB lock); SAM and CodeDeploy for Lambda; **no EKS release path defined (gap)** | ADR-015 |
| CI gates | Unit; consumer-driven contract; tenant isolation; SAST and SBOM; ECR image scan; PII field scanner; secrets scan; dependency review; FAPI 2.0 conformance; integration; Playwright; Terraform IAM linter; production approval in GitHub Environments | ARB §4.9, ADR-015 |
| Accessibility | WCAG 2.2 AA and Section 508; axe-core and Lighthouse on every pull request | ADR-032 |
| QE | IMAGE methodology; human review of every generated artifact before CI | ADR-028 |
| Parity | > 80% at Gate 1 and Gate 2; 95% for dress rehearsals; ≥ 98% at Gate 3; known-difference register with SA and customer approval | ADR-029 |
| SDD | AI drafts specs (OpenAPI, AsyncAPI, Terraform, Glue); SA approves before scaffolding; KT output approved first | ADR-033 |
| Legacy changes | Current State Delta Log reviewed each sprint | ADR-034 |
| NFRs | API P95 ≤ 2 s; write P95 ≤ 500 ms; page load P95 ≤ 3 s; event propagation P95 ≤ 60 s; ≥ 100 req/s per tenant; 99.99% monthly | ADR-038, ARB §5 |
| DR | us-east-1 primary, us-west-2 DR; RTO 15 min; Aurora RPO 10 min | ADR-024 |

**Known issues in the baseline** (flag when a module depends on them): ADR-014 appears twice; ADR-026, ADR-040 and ADR-041 conflict; ADR-027 says six Tenant Registry tables, ADR-007 five; ADR-030 still mentions PingOne; ADR-005 and the ARB differ on Lambda versus EKS; Alembic for .NET services has been questioned.

## Appendix Q — Superseded or Excluded Terms

Any hit is a finding unless the document explains it.

| Term | Replaced by / status | Source |
|---|---|---|
| PingOne | IRM broker | ADR-014 |
| CMS-INX | External Integration Adapter in ARB v2.3 (program still uses CMS-INX; record a query until confirmed) | ARB v2.3 |
| Argo CD, ArgoCD, blue/green | Not in the ADR target state; EKS release path is an open gap (record an exception) | ADR-015 |
| AWS CodeArtifact | JFrog Artifactory | ADR-015, ADR-025 |
| AWS X-Ray | OpenTelemetry | ADR-016 |
| SSRS, `.rdl`, ReportServiceUrl (as target) | Reporting Service or Glue jobs | ADR-019, ADR-021 |
| Amazon Athena, QuickSight | Not in target state | ADR-019 |
| Amazon ECS, Kubernetes Jobs | Not used | ADR-005, ADR-010 |
| Istio, service mesh | IAM-signed requests | ADR-009 |
| Lambda authorizer | Native JWT authorizer | ADR-008 |
| Confluent | AWS Glue Schema Registry | ADR-002a |
| AWS HealthLake | Aurora JSONB | ADR-006 |
| AWS Transfer Family, SFTP | S3 plus MoveIt | ADR-003 |
| SQL Server, Oracle, MongoDB, Vertica (as target stores) | Aurora PostgreSQL | ADR-012, ADR-019 |
| Informatica, Address Doctor | Address Validation as a Service | ARB |
| WCF, SOAP, OData (as target interfaces) | OpenAPI REST | ADR-022 |
| `workflow_callback_inbox` | Not used | ADR-017 |
| Amazon MSK as a fixed choice | Event Backbone technology left open behind the Event Adapter | ADR-002 |

## Appendix R — Crosswalk for Documents in Other Formats

Use this to find content in target states written before template v2. Anything with no match is a finding against the template section.

| Common heading in older documents | Template v2 section |
|---|---|
| About this document; rules for using this document | 0.4 |
| Purpose; capabilities in scope; ownership boundary; out of scope; business objects | 1 |
| Pricing, calculations, precedence; overlap rules | 2.2 |
| Workflow and lifecycle; statuses; transitions | 2.3 |
| Business rules; business rules catalogue | 2.1 |
| Rules engine | 2.5 |
| Provider / neighbouring module events (business behaviour) | 2.1, 7.4 |
| Reference data | 1.6, 9 |
| Architecture overview; classification; technology stack | 3.1, 3.4 |
| Request and event flow; C1; C2 | 3.2, 3.3, 3.5 |
| Frontend | 4 |
| BFF; routes; contract governance | 5 |
| Domain services; API standards; legacy interface replacement; security; resiliency | 6, 10 |
| Persistence; tenancy and schema; operational tables; data access; migrations; outbox; audit | 9, 6.6, 7.7, 2.7 |
| Data migration and cutover | 9.8, 15 |
| Eventing; event adapter; transport details; event rules | 7 |
| Batch processing | 11 |
| Infrastructure and operations; runtime; tenant isolation testing; observability | 12, 10.4 |
| Non-functional requirements | 13 |
| Repository structure | 19 |
| Appendix: API standards and batch ingestion | Appendix A, 11 |
| Appendix: database schema; legacy table mapping | Appendix D, Appendix L |
| Appendix: event catalog | 7.3, 7.4, Appendix E |
| Appendix: authorization matrix | Appendix G |
| Appendix: batch import formats | Appendix I |
| Appendix: OpenAPI contracts | Appendix B |
| *(usually missing)* Decision status, governing inputs, section status index | 0.3, 0.5, 0.7 |
| *(usually missing)* Time-based behaviour, notifications, acceptance criteria | 2.4, 2.9, 2.10 |
| *(usually missing)* Component interaction matrix, deployment view, sequence diagrams | 3.6, 3.7, 3.8 |
| *(usually missing)* External interactions and interface specs | 8, Appendix F |
| *(usually missing)* Data classification, volumes | 9.6, 9.11 |
| *(usually missing)* Test strategy, traceability | 14 |
| *(usually missing)* Legacy transition and retirement | 15 |
| *(usually missing)* ADR alignment, open questions, risks, anti-patterns | 16, 17, 18 |
| *(usually missing)* Slice catalog and build order | 19.4 |
| *(usually missing)* BFF contracts, screen specs, configuration catalog, known-difference register | Appendices C, H, J, M |
