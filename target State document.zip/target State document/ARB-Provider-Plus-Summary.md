# Provider Plus Modernization: ARB Summary

**Source:** `ARB-Provider-Plus-Modernization__20260714-v27 (3).docx` (document version 2.3, Target State, June 2026; prepared by McLaren Strategic Solutions for Gainwell Technologies)
**Summarized:** 2026-10-13

**How to read this summary**

- Everything here comes from the ARB text and its diagrams unless marked otherwise.
- **[Gap]** marks something the ARB does not specify. **[Inconsistency]** marks places where the ARB contradicts itself. **[Local notes]** marks context taken from `plan-management.txt` in this folder, not from the ARB.
- All 21 diagrams in the document have been read (ES-1, ES-2, Figures 1 to 9, 10, 10a to 10f, 11, 11a). Several facts exist only in the diagrams; those are cited by figure number.

---

## 1. The project in brief

| Item | Detail |
|---|---|
| What | Complete rewrite of the Provider Plus Medicaid provider platform as a cloud-native, multi-tenant SaaS on AWS |
| From | .NET Framework, SQL Server, one deployment per state, a shared sequential event router, perimeter and session-based security |
| To | .NET 10 APIs, React 19 Next.js micro frontends, Aurora PostgreSQL database-per-tenant, Event Backbone, zero-trust JWT security |
| Supersedes | The earlier Python/FastAPI submission (v1.0, May 2026) |
| Approach | Build the full target state in a new AWS environment to production readiness before migrating any state |
| Delivery model | Spec-driven development with AI-assisted code generation (EPIC-21) |
| Budget | $1.2M total, Jun 1, 2026 to Apr 1, 2027 |
| Team | 23 engineers plus architecture team, stable from late July 2026 |
| Technical lead / sponsor | Paddu Vedam / Mason Mabry |
| Approval status | CRB and ARB references still TBD in the document |

**Problems the rewrite addresses:** multi-tenancy antipatterns, shared runtime risk across states, weak tenant data boundaries, and a .NET Framework stack with no upgrade path.

---

## 2. Modules

### 2.1 Module inventory

| Module | Code | Type | Role |
|---|---|---|---|
| Provider Enrollment | CM-PE | Main | Public-facing enrollment application intake, eligibility rules, screening, workflow handoff |
| Provider Management | CMS-PM | Main | Provider CRUD, credentialing, network assignment, plan contracting, public provider directory |
| Provider Portal | (none) | Main | Authenticated provider self-service; reads from CMS-PM and CM-PE |
| Plan Management | CM-PL | Supporting | Plan data consumed by the main modules |
| Shared Services | CM-CORE | Supporting | Tenant Registry, feature flags, auth layer, address validation, correspondence, rules, reporting, screening |
| Integration | External Integration Adapter | Supporting | Outbound integration boundary toward state MMIS and other Service Integrators |
| Configuration Management | (none) | Supporting | Being rewritten; replaces the legacy thick-client configuration tool |

### 2.2 Tech stack per module

| Module | Frontend | Backend | Data | Other |
|---|---|---|---|---|
| CM-PE | CM-PE micro frontend (React 19, Next.js) | Command API and Query API, .NET 10 (Native AOT Lambda by default, or EKS Auto Mode) | Per-tenant Aurora PostgreSQL | InRule, Appian BPM, Glue Spark for bulk enrollment, Screening and AddressValidation from CM-CORE |
| CMS-PM | CMS-PM micro frontend | Command and Query APIs, .NET 10 | Per-tenant Aurora PostgreSQL; read models on Lambda consumers | InRule (credentialing rules), Screening, ICC Agent Desktop (NICE CXone) via M2M, S3 datasets to Gainwell Genius |
| Provider Portal | Portal micro frontend | BFF plus .NET 10 APIs | Reads through CMS-PM and CM-PE | IRM broker login (Auth Code with PKCE), Address Validation, feature flags |
| CM-PL | CM-PL micro frontend | Command and Query APIs, .NET 10 | Per-tenant Aurora PostgreSQL with read replicas | ElastiCache Redis for Tenant Registry caching |
| CM-CORE | CM-CORE Admin micro frontend and shared component library | .NET 10 services, one multi-tenant deployment | Aurora `db_shared`, ElastiCache Redis, S3 | NuGet shared libraries, Glue Spark for batch reports |
| External Integration Adapter | None | .NET 10 Lambda | None stated | Configuration-driven translation per state |
| BFF | Serves all micro frontends | .NET 10 (Native AOT) | No direct database access | Aggregates and shapes responses for the UI |
| Batch | None | AWS Glue Spark, Python 3.12 | S3 tenant-prefixed artifacts | Screening extracts, bulk enrollment, ETL; "pending final batch-engine review" |

### 2.3 Platform-wide stack

| Concern | Choice |
|---|---|
| Language and runtime | .NET 10; Native AOT by default, Lambda container packaging as fallback |
| Compute | AWS Lambda first; Amazon EKS Auto Mode as a per-service alternative |
| Frontend | React 19, Next.js micro frontends, served from S3 through CloudFront |
| API entry | AWS API Gateway with native JWT authorizer (ADR-008) |
| Identity | IRM broker (OIDC identity broker), federating to state IdPs and Gainwell IdP (Microsoft Entra ID) |
| Database | Aurora PostgreSQL, one database per tenant on a shared Multi-AZ cluster |
| Cache | ElastiCache Redis (Tenant Registry reads, 5-minute TTL, event-driven invalidation) |
| Eventing | Event Backbone (managed pub/sub) behind an Event Adapter. The text keeps it technology-agnostic; the network diagram (Figure 10f) labels it **Amazon MSK** and also shows SQS and Step Functions |
| Rules | InRule, tenant-scoped rule sets with versioned snapshots |
| Workflow | Appian BPM (external) |
| Object storage | S3, tenant-prefixed; Object Lock (WORM) for audit; Glacier after 90 days |
| Secrets and keys | Secrets Manager per tenant; KMS key per tenant (AES-256) |
| IaC | Terraform, state in S3 with DynamoDB lock |
| CI/CD | GitHub Actions, trunk-based; AWS SAM packaging; CodeDeploy canary and linear deployments |
| Packages | JFrog Artifactory: NuGet, npm, PyPI |
| Observability | OpenTelemetry SDK and an OpenTelemetry Collector, CloudWatch per-tenant dashboards, CloudTrail, pgAudit, GuardDuty, Security Hub |
| Network perimeter | Palo Alto NGFW and layer 7 egress proxy in a shared Security VPC; AWS WAF; AWS Shield; NAT and internet gateways |
| Schema migrations | Alembic **[Inconsistency]**: Alembic is a Python tool; this looks like a carry-over from the superseded Python/FastAPI design |
| UI testing | Playwright |

**Removed from the target state:** SQL Server, Oracle, Vertica, MongoDB, SSRS, Informatica (replaced by Address Validation as a Service), AWS X-Ray, Amazon MSK as a named technology, CMS-INX, PingOne as a name (now IRM broker). The network diagram still shows MSK and "Address Doctor" (see section 10).

**What is new versus changed (Figures ES-1, ES-2):**

| Status | Items |
|---|---|
| New | Per-state versioning, BFF, API Gateway, IRM broker OIDC, Event Adapter, Tenant Registry, Feature Flags, audit info sent to immutable storage |
| Changed | Identity and security (to zero-trust), data (to event-driven CQRS), observability, Tenant Registry store |
| Carried over, rebuilt | Provider Portal, micro frontends, Enrollment, Provider Management, Plan Management, Configuration Management, Event Backbone, database-per-tenant, Screening, Address Validation, Correspondence |

Figure ES-2 also shows **Internal Admin UIs** (operations and call center) as a separate experience surface.

---

## 3. Module dependencies

### 3.1 Dependency rules

1. **No synchronous calls between domains.** CM-PE, CMS-PM, and CM-PL talk to each other only through Event Backbone events.
2. **Domains may call CM-CORE shared services synchronously.** CM-CORE exposes stable contracts.
3. **The browser never calls a domain API directly.** The path is micro frontend, API Gateway, BFF, domain API.
4. **A module makes its own direct calls to external systems** where it needs a real-time answer. The External Integration Adapter is only for outbound events.
5. **Provider Portal is the exception to rule 1 in the diagrams.** Figure 4 shows it reading CMS-PM and CM-PE through API Gateway with synchronous REST.

### 3.2 Dependency map

```mermaid
flowchart LR
  subgraph UI["Presentation"]
    MFE["Micro frontends: CM-PE, CMS-PM, CM-PL, CM-CORE Admin, Portal"]
    BFF["BFF"]
  end
  APIGW["API Gateway"]
  IRM["IRM broker"]

  subgraph DOM["Domain APIs"]
    PE["CM-PE"]
    PM["CMS-PM"]
    PL["CM-PL"]
  end

  subgraph CORE["CM-CORE"]
    TR["Tenant Registry"]
    FF["Feature Flags"]
    AV["AddressValidation"]
    CORR["Correspondence"]
    SCR["Screening"]
    RPT["Reporting API"]
  end

  EB[("Event Backbone via Event Adapter")]
  EIA["External Integration Adapter"]
  INR["InRule"]
  APP["Appian BPM"]
  DB[("Aurora per tenant")]

  MFE --> APIGW
  APIGW --> BFF
  BFF --> PE
  BFF --> PM
  BFF --> PL
  IRM -.->|"JWT"| APIGW
  PE --> TR
  PM --> TR
  PL --> TR
  PE --> DB
  PM --> DB
  PL --> DB
  PE --> INR
  PM --> INR
  PE --> AV
  PE --> SCR
  PM --> AV
  PM --> SCR
  PE -.->|"enrollment.submitted.v1"| EB
  PM -.->|"provider.approved.v1"| EB
  PL -.->|"plan.updated.v1"| EB
  EB -.->|"enrollment.submitted.v1"| PM
  EB -.->|"provider.approved.v1"| PE
  EB -.->|"provider.approved.v1"| PL
  EB -.-> CORR
  EB -.-> EIA
  EB -.-> APP
  APP -->|"REST callback, client credentials"| APIGW
```

Solid lines are synchronous REST. Dashed lines are events.

### 3.3 Event contracts between modules (Figure 11)

| Module | Produces | Consumes |
|---|---|---|
| CM-PE | `enrollment.submitted.v1` | `provider.approved.v1` |
| CMS-PM | `provider.approved.v1` | `enrollment.submitted.v1`; MCO data events |
| CM-PL | `plan.updated.v1` | `provider.approved.v1` |
| CQRS read projectors | None | All domain events; project to Aurora read databases |
| Correspondence Management | None | Enrollment and provider events; generates notices |
| External Integration Adapter | Outbound integration events | Provider and enrollment events |
| Identity Provisioning (SCIM) | None | Provider approved event; provisions the user in Entra ID |

**Topics:** `pp.enrollment`, `pp.provider`, `pp.credentialing`. Convention is `pp.<domain>.<stream>`, for example `pp.enrollment.events`. Topics are scoped per environment, not per tenant.

### 3.4 CM-CORE shared services

| Service | What it provides | Consumers named in the ARB |
|---|---|---|
| Tenant Registry API | Tenant config, IdP settings, feature flags, DB routing, integration endpoints | API Gateway and every domain service |
| Feature Flag Service | Per-tenant runtime toggles without redeployment | All modules |
| IRM broker Auth Layer | OIDC at API Gateway; Auth Code with PKCE for browsers; client credentials for M2M | All modules |
| Shared Contracts Library | NuGet: `TenantContext`, `CorrelationCtx`, error model, paging model | All .NET services |
| AddressValidation | Standardizes addresses via Address Validation as a Service | CM-PE, CMS-PM, Portal |
| Correspondence Management | Notice generation, tenant templates, fulfilment through CaaS | Event-driven from enrollment and provider events |
| InRule Business Rules | Tenant-scoped rule sets, versioned snapshots per tenant | CM-PE (eligibility, enrollment), CMS-PM (credentialing) |
| Reporting API | Replaces SSRS; Glue Spark for batch reports | Not specified |
| Screening Service | Data staging and inquiry against federal registries | CM-PE, CMS-PM |

**Shared libraries:** `hpp_db` (ConnectionRouter), `hpp_auth`, Shared Contracts, a mandatory OpenTelemetry structured logging library, and an npm React component library.

### 3.5 External systems

| System | Purpose | How it is reached |
|---|---|---|
| IRM broker | OIDC identity broker (not an identity provider) | Browser and API Gateway |
| Gainwell IdP (Microsoft Entra ID) | Identity provider for Gainwell staff and external providers | Federated behind IRM broker; SCIM for provisioning |
| State IdPs | Identity provider for state users | Federated behind IRM broker |
| InRule | Business rules engine | REST |
| Appian BPM | Workflow | Consumes events; calls back by REST through API Gateway with OAuth2 client credentials |
| Federal registries | OIG, SAM, NPPES, CLIA, DEA, PECOS, LEIE, DMF | Through the Screening Service only |
| Address Validation as a Service | Address standardization | Through AddressValidation |
| CaaS | Correspondence fulfilment | Through Correspondence Management |
| CAQH | Credentialing data source | Shared services |
| TIN Matching | Taxpayer ID verification | Shared services |
| DMS / Document Validation | Document storage and verification | Shared services |
| ICC (NICE CXone) | Call center agent desktop, CTI screen pop | M2M through API Gateway into CMS-PM |
| Gabby | Virtual assistant, application status self-service | M2M through API Gateway into CM-PE |
| Service Integrators (state MMIS, MCO data) | Downstream state systems | Beyond the External Integration Adapter; out of ARB scope |
| Gainwell Genius | Analytics | Tenant-scoped S3 datasets |

---

## 4. Architecture patterns that apply to every module

### 4.1 Multi-tenancy

- **Database-per-tenant** on a shared Aurora cluster (`pp_t1`, `pp_t2`, ...), each with its own Secrets Manager credentials and KMS key.
- **Tenant Registry** is a shared service backed by Aurora `db_shared`. Tables: `tenants`, `tenant_idp_config`, `tenant_feature_flags`, `tenant_db_routing`, `tenant_integration_endpoints`. It is reached only through its API.
- **ConnectionRouter (`hpp_db`)** resolves the tenant database on every invocation.
- **`tenant_id` is never a caller-supplied parameter.** It is a signed claim in the JWT.

**Tenant context propagation (Figure 10d):**

1. IRM broker issues a JWT with `tenant_id` as a signed claim.
2. API Gateway validates the JWT and extracts `tenant_id`; requests without one are rejected.
3. The domain service holds it in an ambient `TenantContext`.
4. ConnectionRouter selects that tenant's Aurora database.
5. Published events carry `tenant_id` in the envelope.
6. Consumers and projectors re-validate `tenant_id` before writing to the tenant read model.

### 4.2 CQRS (mandatory)

- Each domain has a **Command API** and a **Query API**.
- Writes go to Aurora PostgreSQL, which is authoritative.
- Domain events are published to the Event Backbone.
- **Lambda consumer functions** (triggered by event source mapping) project read models asynchronously.
- Read models may share the write database or use a separate one.
- Idempotent upserts and idempotency keys are expected.

### 4.3 Eventing

**Canonical envelope:** `tenant_id`, `event_name`, `event_version`, `event_id`, `occurred_at`, `correlation_id`, `trace_id`, `producer`.

- Publish and consume only through the **Event Adapter**, so the broker can change (SNS or SQS are named as possibilities).
- Event schemas are versioned; the version travels in the envelope.
- One DLQ per topic.
- There is no `workflow_callback_inbox` table. Appian tracks its own workflow state.

### 4.4 API standards

- Contract-first: OpenAPI 3.0 is the governing artifact for each domain.
- URI versioning (`/v1/`, `/v2/`).
- Consumer-driven contract tests in CI for APIs and event schemas.
- API Gateway enforces JWT validation, RBAC from claims, per-tenant throttling, and OpenAPI request validation.
- Service-to-service calls are IAM-signed; there is no service mesh (ADR-009).

### 4.5 Security

| Flow | Mechanism |
|---|---|
| Public (enrollment) | Public-scope JWT with `tenant_id` and an anonymous role; no user identity |
| Authenticated users | FAPI 2.0: Authorization Code with PKCE and PAR; MFA at the IdP |
| Machine-to-machine | OAuth2 client credentials with mTLS client authentication (Figure 10); secrets rotate every 90 days |
| Service-to-service | Per-function IAM execution roles, least privilege |

**Authenticated user login (Figure 10b):**

1. The client pushes the authorization request to IRM broker over a back channel (PAR). The browser carries only a `request_uri`.
2. The browser is redirected to IRM broker, which federates to the state IdP or Entra ID.
3. The IdP asserts identity by OIDC; IRM broker returns an authorization code.
4. The client exchanges the code with its PKCE verifier and receives a signed JWT with roles and `tenant_id`.
5. API calls go through API Gateway (signature, issuer, audience, expiry, WAF) to the BFF and domain APIs.

**Machine-to-machine (Figure 10c):**

1. The calling system requests a token with client ID and secret.
2. IRM broker returns a short-lived token with a machine scope and the caller's `tenant_id`; no human identity.
3. API Gateway validates signature, issuer, audience, expiry, and scope, and rejects any token whose `tenant_id` does not match the target tenant.
4. The domain API reads and writes with per-tenant credentials and publishes events with `tenant_id` in the envelope.

**Other controls:**

- An unknown tenant at API Gateway returns **403** (Figure 10).
- Tokens and client secrets are never logged.
- TLS 1.3 everywhere; TLS 1.2 only for legacy inbound clients. HSTS on micro frontend distributions.
- No WAF at CloudFront. AWS WAF sits on the ALB (containers) and as a regional web ACL on API Gateway (serverless). GuardDuty, Shield, and the Palo Alto NGFW cover the boundary.
- PII (NPI, TIN, name, address, license number) is encrypted at rest, masked in logs, and never returned in error responses, query strings, or headers.
- The platform holds provider PII only. It does not process PHI.
- Audit: CloudTrail and pgAudit to S3 Object Lock, 7-year retention.
- **Tenant isolation test suite is a mandatory CI gate on every merge to main.** A penetration test of tenant boundaries is required before any state goes live.

### 4.6 Versioning per tenant

Each state can run a different version of UI, APIs, database schema, and event contracts. This is done with the Tenant Registry (records active versions), database-per-tenant, feature flags, URI versioning, versioned events, per-tenant micro frontend deployment, and per-tenant Terraform. There are no parallel codebases.

### 4.7 Observability

- OpenTelemetry SDK is mandatory in every component.
- Structured JSON logs must carry `tenant_id`, `correlation_id`, `service_name`, `timestamp`, `severity`.
- `tenant_id` is a first-class trace attribute.
- Dashboards are per tenant in CloudWatch.
- Pipeline (Figure 11a): instrumented components (API Gateway, CM-PE, CMS-PM, CM-PL, Event Adapter and Backbone, External Integration Adapter, Shared Services, Glue batch) send traces, metrics, and logs to an **OpenTelemetry Collector**, which routes to CloudWatch, per-tenant dashboards, S3 Object Lock for audit, and CloudWatch Alarms with GuardDuty.

### 4.8 Error handling

| Type | Handling |
|---|---|
| Transient | Retry with exponential backoff and jitter at service and consumer layers |
| Data and validation (including InRule rejection) | Reject, quarantine to DLQ or error S3 prefix, do not retry |
| Poison message | Per-topic DLQ after max retries; manual redrive after root cause is fixed |
| Infrastructure | Per-tenant failure isolation; backbone retention allows replay |

### 4.9 CI/CD gates

Unit tests, consumer-driven contract tests, tenant isolation suite, SAST and SBOM, ECR image scan, PII field scanner, secrets scanning, dependency review, a FAPI 2.0 conformance check on the IRM broker client configuration, integration tests, Playwright UI tests, Terraform IAM policy linter, then production approval through GitHub Environments and a CodeDeploy canary. Each domain has its own pipeline and deploys independently.

**[Gap] No release mechanism for EKS.** The ARB lets each .NET 10 service run on Lambda or EKS Auto Mode, but its release strategy covers Lambda only: SAM packaging, CodeDeploy canary and linear traffic shifting, and rollback by Lambda alias. CodeDeploy supports Lambda, ECS, and EC2 or on-premises servers; it has no native support for EKS. Any service placed on EKS needs a different tool for gradual release and rollback (commonly Argo Rollouts, Argo CD, Flux, or Helm), and the ARB names none. Container image scanning in ECR is the only EKS-relevant pipeline step it mentions. The CodeDeploy scope and the tool examples are from general AWS knowledge, not from the ARB.

### 4.10 Infrastructure and network layout (Figures 9, 10f)

**Layers in `us-east-1` (Figure 9):**

| Layer | Contents |
|---|---|
| Edge | CloudFront (no WAF), API Gateway (JWT, throttle, WAF), Route 53, IRM broker |
| Compute | .NET 10 AOT Lambda (domain APIs, BFF, CM-CORE APIs); Lambda event consumers (projectors, integration workers); Glue Spark (batch, analytics handoff) |
| Data | Aurora (Multi-AZ, per-tenant DBs); Event Backbone (Multi-AZ brokers, `pp.*` topic catalog); ElastiCache Redis (Multi-AZ replication); S3; S3 Glacier |

Secrets Manager holds per-tenant DB credentials, API keys, and TLS certificates.

**Network (Figure 10f):**

- AWS account: `gwt-aws-prodeng-pp-act-prd-saas` (marked TBD).
- One "GW Shared Services Deployment Zone" VPC with three subnets on `10.210.xxx.0/24` ranges:
  - **Public/external subnet:** API Gateway.
  - **Shared subnet:** Address Doctor, Screening as a Service.
  - **Private data subnet:** Aurora, labelled "Provider Data Hub".
- .NET 10 Lambdas, CloudWatch, SQS, Amazon MSK (Event Backbone), and Step Functions are drawn alongside the VPC. S3 is reached through an S3 VPC endpoint.
- Inbound traffic passes the Palo Alto firewall in the "Provider Plus + OneGainwell Networks" account, then AWS WAF, then API Gateway. All links are HTTPS on 443.
- Systems that connect in: Gainwell-hosted Provider+, CEF, interChange, and Mainframe; a non-Gainwell "External Provider Enrollment/Management Solution"; MFT, which drops files into S3.
- Outbound: "External Provider Cleansing APIs" on the public internet.
- A separate Azure zone holds the Gainwell IdP (Entra ID) and a "Screening as a Service" node.

---

## 5. Quality targets

| Metric | Target |
|---|---|
| Synchronous API response | P95 at or under 2 seconds |
| Portal page load | P95 at or under 3 seconds |
| Enrollment end to end (submit to Appian workflow created) | P95 at or under 30 seconds |
| Cross-domain event propagation | P95 at or under 60 seconds |
| Data write latency | P95 at or under 500 ms per upsert |
| Throughput | At least 100 requests per second per tenant |
| Batch | 99% within 4 hours |
| Availability | 99.99% monthly (Appian: 99.5%) |
| RTO / RPO | 15 minutes / 10 minutes for Aurora (Appian RTO: 4 hours) |

**DR:** primary `us-east-1`, DR `us-west-2`; Aurora PITR for 35 days; daily snapshots copied cross-region; S3 Cross-Region Replication.

**Failover sequence (Figure 9):** Route 53 health-check DNS switch, Aurora global database promotion, Secrets Manager update, Terraform and SAM re-deploy of Lambda and API Gateway to the DR region. Validated annually through the DR runbook. DR targets are configurable per state; the values above are the highest level currently offered.

---

## 6. Timeline

| Milestone | Date | Content |
|---|---|---|
| M1: Foundation and Provider Enrollment Complete | Aug 23, 2026 | No description in the ARB |
| M2: Provider Management Complete | Sep 20, 2026 | Provider CRUD, credentialing, network assignment, plan contracting; micro frontend live |
| M3: Full Platform Delivered, DDI Ready | Oct 1, 2026 | All 9 services and Glue jobs running end to end in DEV; plan management, integration, correspondence, portal live; isolation suite passing. Contractually significant |
| M4: Core Services Acceptance | Nov 15, 2026 | 9 services and 5 micro frontends; parity above 80%; load test SLOs met; anchor tenant migrated; pen test, DR test, incident runbook, vendor assessments due |
| M5: Parity Gate Passed | Dec 13, 2026 | 98% parity with legacy; two dress rehearsals; rollback runbook signed |

**Staffing waves:** Kickoff Jun 1; Wave A Jun 30 (4 backend engineers for Provider Enrollment, 2 DevOps, 2 frontend); Wave B Jul 12 (4 backend for Provider Management, 2 DevOps/QA, 2 frontend, 1 integration); Jul 24 (2 senior backend for credentialing, spec lead, QA lead).

**Critical path:** five Gainwell knowledge-transfer sessions (CMM, InRule, Appian, MoveIt, Event Catalog) gate service scaffolding per module. ADR-008, ADR-009, and ADR-011 are closed.

---

## 7. Top risks

| ID | Risk | Probability / Impact |
|---|---|---|
| T-001 | Rewrite scope exceeds estimates because of undocumented business rules in legacy code | H / H |
| I-001 | State MMIS translation needs state-specific code instead of configuration | H / H |
| T-002 | Cross-tenant access patterns are hard to find and remove | M / H |
| T-003 | Regressions in business logic, especially InRule rule sets and Appian workflows | M / H |
| T-004 | Native AOT build constraints force fallback to Lambda containers | M / M |
| T-005 | InRule per-tenant rule set management grows complex | M / M |
| I-002 | Appian per-tenant workflow configuration is hard to migrate | M / M |
| S-001, S-002 | PII exposure through logs or IAM; cross-tenant leakage | L / H |
| P-001 | Lambda cold start breaks P95 targets | L / M |

T-003 is mitigated by a **parallel run**: legacy and .NET 10 services side by side on production-mirrored traffic.

---

## 8. Compliance

- **CMS MITA 3.0:** modular, service-oriented, API-first, event-driven interoperability.
- **NIST SP 800-53 Rev 5, Moderate baseline:** families AC, AU, CA, CM, CP, IA, IR, RA, SC, SI, SA are mapped to the architecture.
- **ARC-AMPE Volume II** (CMS successor to MARS-E): the security architecture aligns with its architecture-relevant control families.
- **HIPAA:** administrative safeguards are applied to provider PII; the platform is not in a PHI context.
- **State-specific PII rules** (residency, retention, breach notification) are configurable per tenant in the Tenant Registry.

---

## 9. Focus section: Provider Enrollment (CM-PE) and Plan Management (CM-PL)

The ARB covers these two modules very unevenly. CM-PE has its own context diagram, process narrative, and security flow. CM-PL appears in a handful of table rows and diagram boxes.

### 9.1 CM-PE: Provider Enrollment

#### What it is

A **public-facing** workflow. Applicants need no account and do not log in. This is the reference model for all public workflows on the platform.

#### Components

| Layer | Component | Technology |
|---|---|---|
| UI | CM-PE micro frontend | React 19, Next.js, S3 and CloudFront |
| Aggregation | BFF | .NET 10 Native AOT |
| API | CM-PE Command API, CM-PE Query API | .NET 10 Native AOT Lambda, or EKS Auto Mode |
| Projection | CQRS read-model projectors | Lambda consumer functions |
| Batch | Bulk enrollment, screening extracts | Glue Spark, Python 3.12 |
| Data | Tenant database | Aurora PostgreSQL through ConnectionRouter |

#### Request flow

1. The applicant opens the CM-PE micro frontend.
2. The browser asks IRM broker for a **public-scope JWT** (anonymous role plus `tenant_id`, no user identity).
3. The browser sends the enrollment with the JWT over TLS 1.3.
4. API Gateway applies the regional WAF, validates the schema, and verifies the JWT (issuer, audience, `tenant_id`).
5. API Gateway routes to the BFF, which forwards to the **CM-PE Command API**.
6. ConnectionRouter resolves the tenant database from the Tenant Registry.
7. The application is saved with status **Submitted**.
8. CM-PE publishes **`enrollment.submitted.v1`** to the Event Backbone.
9. InRule evaluates tenant-specific eligibility and enrollment rules.
10. AddressValidation standardizes the address.
11. Appian BPM picks up the event and later calls back by REST through API Gateway with client credentials.
12. Correspondence Management generates notices, fulfilled through CaaS.

The public-scope token is limited to enrollment operations for one tenant.

#### Dependencies

| Direction | Dependency | Type | Purpose |
|---|---|---|---|
| Inbound | Provider applicants | Sync, public JWT | Submit applications |
| Inbound | Gabby virtual assistant | Sync, M2M | Application status inquiry |
| Inbound | Provider Portal | Sync through API Gateway | Application status, resume in-progress applications |
| Inbound | Appian BPM | Sync REST callback, client credentials | Workflow outcomes |
| Outbound | IRM broker | Sync | Public-scope token, signing keys |
| Outbound | Tenant Registry | Sync (cached) | Tenant DB routing, config, flags |
| Outbound | InRule | Sync REST | Eligibility and enrollment rules |
| Outbound | Screening Service | Sync | Federal registry checks (staging and inquiry) |
| Outbound | AddressValidation | Sync | Address standardization |
| Outbound | Event Backbone | Async | Publishes `enrollment.submitted.v1` and communication events |
| Downstream | CMS-PM | Async | Consumes the enrollment event and creates the provider record |
| Downstream | External Integration Adapter | Async | Receives outbound integration events |
| Downstream | Correspondence Management / CaaS | Async | Email, letters, notices |
| Downstream | Identity Provisioning (SCIM) | Async | On approval, creates the provider user in Entra ID |
| Upstream event | CMS-PM | Async | CM-PE consumes `provider.approved.v1` |

#### After approval (Figure 10e)

1. A provider-approved event is published.
2. The Identity Provisioning service consumes it and creates the user in Gainwell IdP by SCIM, with `tenant_id` and `role=provider`.
3. The provider receives a one-time activation link, sets a credential, and enrols MFA (FIDO2 or TOTP).
4. The provider then logs into the Provider Portal through IRM broker with PAR and PKCE.
5. Termination events deprovision the user the same way.

#### Targets and schedule

- Enrollment end to end: P95 at or under 30 seconds. There is no synchronous Appian call on the hot path.
- Scaling: Lambda auto-scaling, per-tenant DB routing, per-topic partitioning.
- Milestone M1 (Aug 23, 2026). Wave A assigned 4 .NET backend engineers and 2 frontend engineers.

#### Open points for CM-PE

- **[Inconsistency]** Who publishes the approval event? Figure 11 says CMS-PM produces `provider.approved.v1` and CM-PE consumes it. Figure 10e shows CM-PE emitting "ProviderApproved".
- **[Inconsistency]** Event naming differs between `enrollment.submitted.v1` (text, Figure 11) and `EnrollmentSubmitted v1` (Figure 10a).
- **[Inconsistency]** The narrative places InRule and AddressValidation after the event is published. It is unclear whether rules run synchronously before persistence or asynchronously after.
- **[Gap]** Only one CM-PE event is named. Status changes, approval, denial, and return-for-correction events are not listed.
- **[Gap]** The Appian callback endpoints and the Appian multi-tenancy model are not defined (risk I-002).
- **[Gap]** Document upload, DMS, and Document Validation are listed as external services but not wired into the enrollment flow.
- **[Gap]** Save-and-resume for an anonymous applicant is implied by the Portal ("resume in-progress apps") but not designed.
- **[Gap]** The network diagram shows AWS Step Functions and SQS next to the Lambdas. Neither appears in the text, so it is unclear whether any enrollment orchestration is meant to run there instead of Appian.
- **[Gap]** The network diagram shows MFT dropping files into S3 and an "External Provider Enrollment/Management Solution" connecting in. These look like bulk or external enrollment intake paths, but the text does not describe them beyond "bulk enrollment" on Glue Spark.

#### Machine callers into CM-PE

Gabby and Appian both use the machine-to-machine flow in section 4.5: a short-lived client-credentials token with a machine scope and `tenant_id`, validated at API Gateway. CM-PE endpoints for these callers need machine scopes separate from the public enrollment scope.

### 9.2 CM-PL: Plan Management

#### What the ARB states

| Aspect | Detail | Source |
|---|---|---|
| Classification | Supporting module consumed by the main modules | Section 3.2 |
| UI | CM-PL micro frontend, React 19 Next.js, independently deployable and versioned per tenant | ES-2, Figure 7 |
| API | CM-PL Plan Mgmt APIs, Command and Query (CQRS), .NET 10 on Lambda or EKS Auto Mode | Figure 5 |
| Events produced | `plan.updated.v1` | Figure 11 |
| Events consumed | `provider.approved.v1` | Figure 11 |
| Scale | From single-tenant per state to multi-tenant with plan volumes per enrolled state | Section 5.2.2 |
| Scaling method | Lambda auto-scaling; ElastiCache Redis for Tenant Registry caching; Aurora read replicas | Section 5.2.2 |
| API spec | OpenAPI 3.0 spec for CM-PL listed as supporting documentation | Section 10.2 |
| Schedule | Plan management live at M3 (Oct 1, 2026) | Section 6 |
| MITA | Named as an independently deployable domain service | Section 8.4 |

#### Dependencies

| Direction | Dependency | Type | Basis |
|---|---|---|---|
| Inbound | CM-PL micro frontend through API Gateway and BFF | Sync | Platform standard |
| Outbound | Tenant Registry (Redis cached) | Sync | Stated for CM-PL |
| Outbound | Per-tenant Aurora database through ConnectionRouter | Sync | Platform standard |
| Outbound | Event Backbone through Event Adapter | Async | Stated: `plan.updated.v1` |
| Upstream event | CMS-PM `provider.approved.v1` | Async | Stated |
| Outbound | Feature Flags, IRM auth layer, Shared Contracts, OpenTelemetry logging | Sync / library | Platform standard |
| Related | CMS-PM "plan contracting" and "network assignment" | Unclear | M2 description |
| Related | MCO data from Service Integrators, consumed by CMS-PM | Unclear | Figure 3 |

#### Open points for CM-PL

- **[Gap]** There is no C4 context diagram, process narrative, or security flow for CM-PL. Having now read every diagram, CM-PL appears only as a box in Figures ES-2, 5, 7, 11, and 11a.
- **[Gap]** The ARB does not say who uses CM-PL. If its users are internal staff, the authenticated login flow in section 4.5 (PAR and PKCE, roles and `tenant_id` in the JWT) applies, unlike CM-PE's public flow.
- **[Gap]** No `pp.plan` topic is listed. The named topics are `pp.enrollment`, `pp.provider`, and `pp.credentialing`. By the naming convention, `plan.updated.v1` needs a `pp.plan.<stream>` topic.
- **[Gap]** No consumer of `plan.updated.v1` is named.
- **[Gap]** The boundary between CM-PL and CMS-PM is not drawn. "Plan contracting" and "network assignment" are assigned to CMS-PM in M2.
- **[Gap]** The ARB does not say whether CM-PL uses InRule, Reporting, AddressValidation, or Correspondence. AddressValidation is labelled "Shared by CM-PE, CMS-PM" only.
- **[Gap]** No CM-PL engineers are named in the staffing waves.
- **[Gap]** How CM-PE gets plan data during enrollment is not described. Under the no-sync-calls rule it would need a local projection built from `plan.updated.v1`.
- **[Gap]** Reference data ownership (code sets, groupings) is not addressed.

#### Legacy to target for CM-PL **[Local notes]**

Your notes in `plan-management.txt` describe the legacy module. Mapped against the ARB target:

| Legacy (from your notes) | ARB target |
|---|---|
| ASP.NET MVC controllers and Razor views (`HP.HSP.UA3.PlanManagement.UX.Presentation`) | CM-PL Next.js micro frontend |
| Kendo-style grids, Gainwell/UA3 Core UX libraries | Shared React component library (npm, CM-CORE Admin) |
| UI calling `/api/PlanManagementMaint/...` Web API routes directly | Micro frontend to API Gateway to BFF to CM-PL Command/Query APIs, OpenAPI contract-first, `/v1/` |
| `TenantConfigurationManager` for service discovery and config | Tenant Registry API and Feature Flag Service |
| `DefaultConnectionString`, `PlanManagementDbContext.SchemaName` | ConnectionRouter (`hpp_db`) with per-tenant Secrets Manager credentials |
| SQL Server data access (EF `DbContext` classes) | Aurora PostgreSQL, CQRS write and read models |
| SSRS reports (`.rdl`, `ReportServiceUrl`, SSRS credentials in constants) | Reporting API in CM-CORE; Glue Spark for batch reports |
| Host portal in a separate repo (`mms-cms-pl`) | Independently deployable micro frontend; no host portal |

Your notes also record that the repo has `mfe-enrollment`, `mfe-admin`, and `shell` under `components/enrollment/ux/components/`, and no `mfe-plan-management`. The current `Pl.Ui` project is a .NET class library that renders MVC markup, which does not match the ARB's micro frontend plus BFF target (ADR-011).

### 9.3 How CM-PE and CM-PL relate

- The ARB shows **no direct link** between them. Neither produces an event the other is listed as consuming.
- Both consume `provider.approved.v1` from CMS-PM.
- Any plan data needed inside enrollment (for example plan or network selection) has to arrive through events or be shaped by the BFF. A direct CM-PE to CM-PL API call would break the cross-domain rule.

### 9.4 Worked example: a plan written in CM-PL and read in CM-PE

The ARB does not describe this scenario. This section applies its platform patterns to a plan; anything it leaves open is listed at the end. The principle: **CM-PL is the only module that writes plans.** Other modules either keep a read-only copy built from events or get plan data through the BFF.

#### Write flow: a staff user adds a plan in CM-PL

| Step | Component | What happens |
|---|---|---|
| 1 | CM-PL micro frontend | User is logged in through IRM broker; holds a JWT with roles and `tenant_id` |
| 2 | API Gateway | WAF, JWT validation, request schema validation, per-tenant throttling |
| 3 | BFF | Forwards the request to the domain API |
| 4 | CM-PL Command API | Validates business rules; holds the tenant in `TenantContext` |
| 5 | ConnectionRouter (`hpp_db`) | Resolves the tenant database from the Tenant Registry (Redis cached); gets credentials from Secrets Manager |
| 6 | Tenant Aurora database | Plan is saved to the CM-PL write model, the authoritative copy; pgAudit records the access |
| 7 | Event Adapter, Event Backbone | CM-PL publishes `plan.updated.v1` with the canonical envelope |
| 8 | Lambda consumers (projectors) | Each interested module re-validates `tenant_id` and updates its own read model |
| 9 | DLQ | A projector that cannot process the event retries, then dead-letters it |

Projectors in step 8:

- CM-PL's projector updates the CM-PL read model.
- CM-PE's projector updates a local, read-only copy of plans, if CM-PE needs them.
- CMS-PM would do the same if it needs plans.

Every step emits OpenTelemetry signals tagged with `tenant_id` and `correlation_id`.

#### Read flow inside CM-PL

CM-PL micro frontend → API Gateway → BFF → CM-PL Query API → CM-PL read model.

#### Read flow from CM-PE: two possible routes

| Route | Path | Use when |
|---|---|---|
| Local copy | CM-PE Query API or Command API reads CM-PE's own plan copy, built in step 8 | CM-PE must validate on the server that a selected plan exists and is active |
| BFF aggregation | BFF calls the CM-PL Query API and combines the result with CM-PE data | A screen only needs to list or display plans |

The rule forbids domain-to-domain calls, and the ARB gives the BFF the job of aggregating responses, so the second route appears to be allowed. The ARB never says so explicitly.

#### Consequences

- **Reads lag writes.** The cross-domain propagation target is P95 within 60 seconds. A new plan may not be visible in CM-PE for up to a minute, and CM-PE must cope with a plan it has not seen yet.
- **Copies must be idempotent and rebuildable.** Events can arrive twice or out of order, and a new consumer needs a way to load existing plans.
- **Only CM-PL changes plans.** Other modules never write to their copy except through events.

#### What the ARB leaves open

- **[Gap]** No consumer of `plan.updated.v1` and no `pp.plan` topic are named, so it is unknown whether CM-PE is meant to use the local copy or the BFF route.
- **[Gap]** Nothing says how the database save and the event publish are kept atomic. If the save succeeds and the publish fails, other modules never learn about the plan. The usual fix is a transactional outbox table; the ARB does not mention one.
- **[Gap]** Databases are per tenant, not per module, so CM-PE and CM-PL tables share a tenant database. Schema ownership per module is not defined, so nothing technically stops CM-PE from querying CM-PL tables directly, which would defeat the rule.
- **[Gap]** Only one plan event is named. Create, retire, and delete are not distinguished from update.
- **[Inconsistency]** Figure 4 shows the Provider Portal reading CMS-PM and CM-PE synchronously through API Gateway, so the ARB is not strict about the rule for reads.

### 9.5 Implementation notes: transactional outbox and projectors

These notes describe how the write and read flows in section 9.4 are typically built on this stack. The ARB mandates neither design. Table, schema, and function names are illustrative.

#### Transactional outbox

**Problem.** The Command API must save the plan to Aurora and publish `plan.updated.v1`. These are separate systems, so one can succeed while the other fails:

- Save commits, publish fails: other modules never hear about the plan.
- Publish succeeds, save fails: other modules hear about a plan that does not exist.

**Idea.** Do not publish from the request. In the same database transaction that saves the plan, insert a row into an `outbox` table describing the event. Both rows commit or neither does. A separate relay process reads the outbox and publishes to the Event Backbone.

```sql
BEGIN;
  INSERT INTO cmpl.plan (plan_id, name, status, version, ...) VALUES (...);
  INSERT INTO cmpl.outbox (event_id, event_name, event_version, tenant_id,
                           correlation_id, payload, occurred_at, published_at)
  VALUES (gen_random_uuid(), 'plan.updated', 1, 'tn', '...', '{...}', now(), NULL);
COMMIT;
```

**Relay options**

| Option | How it works |
|---|---|
| Polling | A worker selects rows where `published_at` is null, publishes them through the Event Adapter, then marks them published |
| Change data capture | A tool such as Debezium reads the PostgreSQL log and forwards new outbox rows to the broker |

**Costs**

- **Duplicates are possible.** If the relay publishes and crashes before marking the row, it publishes again. Every consumer must be idempotent.
- **Database-per-tenant makes the relay harder.** There is one outbox per tenant database, so a poller loops over tenants, and change data capture needs a connector per database.
- **Latency.** A poller adds delay against the 60-second propagation target. A common compromise is to publish right after commit and let the poller catch only the failures.

#### How subscribers receive events

The ARB text keeps the Event Backbone technology-agnostic; only the network diagram labels it Amazon MSK. The notes below assume MSK (managed Kafka).

- **A topic is a stored log, not a queue.** Reading an event does not remove it. Events stay until retention expires.
- **Each subscriber uses its own consumer group.** Kafka keeps a separate read position (offset) per group, so `cmpl-plan-projector` and `cmpe-plan-projector` each receive every event independently.
- **Two functions sharing a group name split the events** instead of each getting all of them.
- **Order is guaranteed only within a partition.** The publisher picks a key, such as tenant plus plan ID, so all events for one plan stay in order.

With SNS and SQS instead of MSK, each subscriber gets its own queue and the topic copies every event into each one.

#### How Lambda consumes a topic

A Lambda function only runs when invoked, so AWS runs the listener. An **event source mapping** connects a topic to a function:

1. Lambda's poller reads the topic continuously, using the assigned consumer group.
2. It collects events into a batch, by count or by a short time window.
3. It invokes the function once with the whole batch. Records are grouped by partition and their bodies are base64-encoded.
4. If the function returns successfully, the poller advances the offset past the batch.
5. If the function throws, the offset does not move and the same batch is sent again.

Consequences:

- A retry resends the whole batch, including events already processed.
- One permanently failing event blocks its partition until it is sent to a failure destination or DLQ.
- Throughput scales with the number of partitions.

#### What a projector does

A projector is a Lambda function whose only job is to keep one read model current. For each event in the batch:

1. **Read the envelope.** Deserialize it and check that `event_version` is supported.
2. **Re-check the tenant.** Events carry no JWT, so the check is:
   - `tenant_id` is present and is a known, active tenant in the Tenant Registry.
   - `TenantContext` is set from the envelope, never from the payload body.
   - ConnectionRouter opens that tenant's database, so a wrong tenant fails instead of writing to another state's data.
3. **Skip duplicates and apply the change in one transaction.**
4. **Handle failures.** Throw on transient errors so Lambda retries; send events that can never succeed to the DLQ.
5. **Emit telemetry.** Continue the trace using `trace_id` and `correlation_id` from the envelope.

```sql
BEGIN;
  -- returns 0 rows if this event was already processed: then stop
  INSERT INTO cmpl_read.processed_events (event_id) VALUES (:event_id)
  ON CONFLICT DO NOTHING;

  INSERT INTO cmpl_read.plan_summary
         (plan_id, name, status, effective_from, effective_to, version, updated_at)
  VALUES (:plan_id, :name, :status, :from, :to, :version, :occurred_at)
  ON CONFLICT (plan_id) DO UPDATE
     SET name = EXCLUDED.name, status = EXCLUDED.status,
         effective_from = EXCLUDED.effective_from, effective_to = EXCLUDED.effective_to,
         version = EXCLUDED.version, updated_at = EXCLUDED.updated_at
   WHERE cmpl_read.plan_summary.version < EXCLUDED.version;  -- ignore stale events
COMMIT;
```

- `processed_events` handles duplicates.
- The `version` condition handles out-of-order events. It requires the write side to put a version number on each plan.

**The read model** is a table shaped for the screens: `plan_summary` holds the columns the plan grid shows, already joined, so the Query API does a simple select. It normally lives in the same tenant database under its own schema. Projectors write to the primary; the Query API can read from a replica.

#### Decisions for the team

- **Seeing your own save.** The grid may reload before the projector has run. Usual fixes: return the saved plan from the command and show it immediately, or have the UI wait for the version it just wrote.
- **Rebuilding.** A corrupted or reshaped read model needs a rebuild path, by replaying the topic or re-reading the write model.
- **Whether CM-PL needs a projector for its own data.** The glossary says read models "may be projected asynchronously"; the body text says they are. For a simple maintenance module, a separate query path over the write tables avoids the lag.
- **Native AOT.** JSON deserialization must use source-generated serializers; reflection-based ones do not work under AOT.

### 9.6 Checklist for both modules

Every CM-PE and CM-PL service is expected to:

- [ ] Split into Command and Query APIs, with read models projected by Lambda consumers
- [ ] Target .NET 10 Native AOT; flag AOT-incompatible dependencies early (risk T-004)
- [ ] Take `tenant_id` only from `TenantContext`, never from request parameters
- [ ] Reach the database only through ConnectionRouter (`hpp_db`)
- [ ] Publish and consume only through the Event Adapter, with the full canonical envelope
- [ ] Re-validate `tenant_id` in every consumer before writing
- [ ] Make consumers and upserts idempotent
- [ ] Define the OpenAPI 3.0 spec first; version by URI
- [ ] Add consumer-driven contract tests for APIs and event schemas
- [ ] Use the shared OpenTelemetry logging library; never log NPI, TIN, name, address, or license number
- [ ] Keep PII out of query strings, headers, and error responses
- [ ] Pass the tenant isolation suite on every merge
- [ ] Expose UI only through micro frontend, API Gateway, and BFF
- [ ] Gate tenant-specific behavior with feature flags
- [ ] Meet P95 of 2 seconds for APIs and 500 ms for writes

### 9.7 Questions worth raising

1. Which module owns `provider.approved.v1`: CM-PE or CMS-PM?
2. What is the CM-PL topic name, and who consumes `plan.updated.v1`?
3. Where is the line between CM-PL and CMS-PM for plan contracting and network assignment?
4. Does CM-PE need plan data at enrollment time, and if so through which projection?
5. Does CM-PL use InRule or the Reporting API to replace its SSRS reports?
6. Is Alembic really the migration tool for a .NET codebase?
7. Is there a CM-PL micro frontend planned in the repo, given the current `Pl.Ui` MVC port?
8. What are the Appian callback contracts for CM-PE?
9. Will CM-PE or CM-PL services run on Lambda or EKS, and if EKS, how are they released and rolled back (see section 4.9)?
10. May the BFF aggregate across domains for reads, or must each module keep its own projected copy (see section 9.4)?
11. Is a transactional outbox the standard for publishing events after a database write (see section 9.5)?
12. Does each module own a schema inside the tenant database, and is cross-schema access blocked?
13. Must CM-PL project its own read model asynchronously, or may it query its write tables through a separate query path?
14. Is the Event Backbone MSK, and what are the conventions for consumer group names, partition keys, and failure destinations?

---

## 10. Other inconsistencies in the ARB

- **WAF at the edge:** the text says there is no WAF at CloudFront; the titles of Figure 5 Zone 1 and Figure 7 Layer 1 say "S3 + CloudFront + WAF".
- **BFF runtime:** described as Native AOT in some places and "Lambda or EKS Auto Mode" in others.
- **"9 services"** are referenced in M3 and M4 but never enumerated.
- **PingOne and CMS-INX** still appear in the change log, although both were renamed or removed in v2.3.
- **Version label:** the file name says v27; the document's own version table says 2.0, and the change log goes to 2.3.
- **Glue Spark** is called "the selected batch compute platform" and also "pending final batch-engine review".
- **Amazon MSK:** the change log says MSK references were generalized to "Event Backbone", but the network diagram (Figure 10f) still labels the backbone "Amazon MSK".
- **Address Doctor:** the change log says Informatica was replaced by Address Validation as a Service, but Figure 10f still shows "Address Doctor", an Informatica product.
- **Step Functions and SQS** appear in Figure 10f and nowhere in the text.
- **mTLS:** Figure 10 lists mTLS client authentication for machine-to-machine calls; the security text mentions only client credentials.
- **TLS for machine callers:** Figure 10c says "TLS 1.2 or higher" on all hops, while the text sets TLS 1.3 as the standard with 1.2 for legacy inbound only.
- **Screening as a Service** is drawn twice in Figure 10f: in the AWS shared subnet and in the Azure zone next to Entra ID.
- **API Gateway placement:** Figure 10f draws API Gateway inside a VPC subnet, which implies a private API behind the firewall and WAF; the text describes it as the public entry point.
- **Aurora naming:** Figure 10f calls the database "Provider Data Hub"; the rest of the document uses per-tenant names such as `pp_t1`.
- **EKS release path:** EKS Auto Mode is offered as a deployment target for every service, but release, canary, and rollback are described for Lambda only (see the gap note in section 4.9). The DR section likewise describes re-deploying Lambda and API Gateway, not EKS workloads.
